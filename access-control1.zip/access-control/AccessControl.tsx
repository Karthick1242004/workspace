import React from "react";
import PageHeader from "./components/PageHeader";
import TabContent from "./components/TabContent";
import ControlSidePanel from "./components/panels/ControlSidePanel";
import PersonaSidePanel from "./components/panels/PersonaSidePanel";
import SidePanelContent from "./components/panels/SidePanelContent";
import { useAccessControlStore } from "./lib/store";

const AccessControlPageContent = () => {
  const { isPanelOpen, panelType, panelItem } = useAccessControlStore();

  const renderPanelContent = () => {
    switch (panelType) {
      case "Persona":
      case "Category":
        return <PersonaSidePanel persona={panelItem as any} types={panelType} />;
      case "Permissions":
        return <SidePanelContent workspace={panelItem as any} />;
      default:
        return null;
    }
  };

  return (
    <>
      <div className="w-full max-w-[1300px] mx-auto px-4">
        <PageHeader />
        <TabContent />
      </div>
      <ControlSidePanel
        isOpen={isPanelOpen}
        title={`Manage ${panelType}`}
      >
        {renderPanelContent()}
      </ControlSidePanel>
    </>
  );
};

export default function AccessControlPage() {
  return <AccessControlPageContent />;
}