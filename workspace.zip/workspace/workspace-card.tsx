import React from "react";
import { PencilLine, Pin, UserRound } from "lucide-react";
import { Workspace } from "@/@logic/workspaceStore";
import Dot from "../../shared/dot/dot";
import { useFetchHandler } from "@/@logic/getHandlers";
import { Skeleton } from "@/components/ui/skeleton";
import FallbackLogo from "../../assets/icons/logo_unilever.svg";

interface Props {
  data: Workspace;
  isSelected: boolean;
}

export default function WorkspaceCard({ data, isSelected }: Props) {

  const { data: workspaceLogo, isLoading } = useFetchHandler(
    `/workspaces/logo/${data.id}/download`,
    `${data.id}-${data.name}`,
    true,
    true
  );
  const imgUrl = workspaceLogo
    ? URL.createObjectURL(workspaceLogo)
    : FallbackLogo;

  return (
    <div
      className={`group border rounded-xl p-3 relative transition-all duration-300 hover:border-[var(--workspace-color-highlight)] hover:shadow-[0_0_10px_rgba(96,165,250,0.5)] ${
        isSelected
          ? "border-[var(--workspace-color-highlight)] bg-[var(--workspace-color-highlight)] text-white"
          : "bg-white border-[#b5d3ff] text-gray-600"
      }`}
      style={{
        backgroundImage: 'url("/src/assets/icons/Frame-2106257085-copy.svg")',
        backgroundRepeat: "no-repeat",
        backgroundPosition: "bottom",
        backgroundBlendMode: isSelected ? "soft-light" : "normal",
        backgroundSize: "100px",
      }}
    >
      <button
        // onClick={() => navigate(`/workspace/edit/${data.id}`, { state: { workspace: data } })}
        className="absolute top-2 right-2 p-1.5 rounded-full text-xs text-[var(--workspace-color-highlight)]"
        aria-label="Edit workspace"
      >
        <span className="inline-block opacity-0 translate-x-2 transition-all duration-300 ease-out group-hover:opacity-100 group-hover:translate-x-0">
          <PencilLine size={16} />
        </span>
      </button>

      <div className="flex gap-4 items-start justify-between">
        {/* Card Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-3">
            <h2
              className={`font-unilever-medium text-base truncate ${
                isSelected
                  ? "text-white"
                  : "text-[var(--workspace-color-highlight)]"
              }`}
            >
              {data.name}
            </h2>
            <Pin
              strokeWidth={2}
              size={18}
              className={`${
                isSelected
                  ? "text-white"
                  : "text-[var(--workspace-color-highlight)]"
              } mt-1`}
            />
          </div>
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <div
              className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${
                isSelected
                  ? "bg-white/20"
                  : "bg-[var(--workspace-color-bg-light)] text-[var(--workspace-color-highlight)]"
              }`}
            >
              <UserRound size={14} />
              {data.name}
            </div>
            <div
              className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${
                isSelected
                  ? "bg-white/20"
                  : "bg-[var(--workspace-color-bg-light)] text-[var(--workspace-color-highlight)]"
              }`}
            >
              <Dot
                bgcolor={
                  isSelected
                    ? "bg-white"
                    : "bg-[var(--workspace-color-highlight)]"
                }
              />
              {data.skills?.length ?? 0} Skills
            </div>
          </div>
          <p className="text-xs font-unilever line-clamp-2">
            {data.description}
          </p>
        </div>
        {/* Logo or Skeleton */}
        <div className="flex-shrink-0 w-[80px] h-[80px] flex items-center justify-center border border-[#eaeff5] rounded-sm bg-white ml-2">
          {isLoading ? (
            <Skeleton className="w-[64px] h-[64px] rounded-sm bg-gray-200" />
          ) : (
            <img
              src={imgUrl}
              alt="Workspace Logo"
              className="w-[64px] h-[64px] p-1 object-contain rounded-sm"
              loading="lazy"
            />
          )}
        </div>
      </div>
    </div>
  );
}
