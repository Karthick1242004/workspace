import { FieldValues } from "react-hook-form";

export interface WorkspaceFormData {
  id?: string;
  name: string;
  description: string;
  category: string;
  icc: string;
  costCenter: string;
  responsible: string;
  note: string;
}

export interface SkillFormData {
  id?: string;
  name: string;
  description: string;
  category: string;
  systemPrompt: string;
  workspaceId?: string;
  publicURL?: string,
  sharePointURL?: string,
  dataSource?: 'ADLS' | 'URL' | 'SharePoint';
  link?: string;
}

export type FormField = {
  name: string;
  label: string;
  type: "input" | "textarea" | "select" | "uploader";
  required?: boolean;
  placeholder?: string;
  rows?: number;
  options?: string[];
  column?: "left" | "right";
  uploaderType?: "logo" | "files";
};

export type FormConfig<T extends FieldValues> = {
  title: string;
  defaultValues: T;
  fields: FormField[];
  apiEndpoints: {
    create: string;
    update: string;
    delete?: string;
  };
};

export type FormConfigs = {
  workspace: FormConfig<WorkspaceFormData>;
  skill: FormConfig<SkillFormData>;
};

export const formConfigs: FormConfigs = {
  workspace: {
    title: "Workspace",
    defaultValues: {
      name: "",
      description: "",
      category: "Business Group",
      icc: "ICC",
      costCenter: "Cost Center name",
      responsible: "WL3",
      note: "",
    },
    fields: [
      {
        name: "name",
        label: "Workspace Name",
        type: "input",
        required: true,
        placeholder: "Enter workspace name",
      },
      {
        name: "description",
        label: "Description",
        type: "textarea",
        required: true,
        placeholder: "Enter workspace description",
        rows: 4,
      },
      {
        name: "category",
        label: "Category",
        type: "select",
        options: ["Business Group", "Marketing", "Sales", "Operations"],
      },
      {
        name: "icc",
        label: "ICC",
        type: "input",
      },
      {
        name: "costCenter",
        label: "Cost Center",
        type: "input",
      },
      {
        name: "responsible",
        label: "Responsible WL3",
        type: "input",
      },
      {
        name: "note",
        label: "Note",
        type: "textarea",
        rows: 4,
        placeholder: "Add Note",
      },
      {
        name: "logo",
        label: "Update Logo",
        type: "uploader",
        uploaderType: "logo"
      },
      
    ],
    apiEndpoints: {
      create: "workspaces/",
      update: "workspaces/update-and-delete/",
    },
  },
  skill: {
    title: "Skill",
    defaultValues: {
      name: "",
      description: "",
      category: "File upload",
      systemPrompt: "",
    },
    fields: [
      {
        name: "name",
        label: "Skill Name",
        type: "input",
        required: true,
        placeholder: "Enter skill name",
        column: "left"
      },
      {
        name: "description",
        label: "Description",
        type: "textarea",
        required: true,
        placeholder: "Enter skill description",
        rows: 4,
        column: "left"
      },
      {
        name: "category",
        label: "Data source type",
        type: "select",
        options: ["File upload", "Sharepoint URL", "Public URL"],
        column: "right",
      },
      {
        name: "systemPrompt",
        label: "System Prompt",
        type: "textarea",
        required: true,
        rows: 4,
        column: "left",
        placeholder: "Enter system prompt"
      },
      {
        name: "files",
        label: "Upload File",
        type: "uploader",
        column: "right",
        uploaderType: "files"
      },
      
      {
        name: "logo",
        label: "Upload Logo",
        type: "uploader",
        column: "left",
        uploaderType: "logo"
      }
    ],
    apiEndpoints: {
      create: "skills/create-skill",
      update: "skills/edit-skill/",
    },
  },
};