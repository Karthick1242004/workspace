import React from "react";
import { useAccessControlStore } from "../lib/store";
import { useFetchHandler } from "@/@logic/getHandlers";
import { TAB_API_MAP, TABS_CONFIG } from "../lib/constants";
import { Skeleton } from "@/components/ui/skeleton";
import AccessControlTable from "./tables/AccessControlTable";
import PersonaTable from "./tables/PersonaTable";
import TabsWrapper from "@/components/ui/tabs-wrapper";

export default function TabContent() {
  const { activeTab, searchText, setActiveTab } = useAccessControlStore();
  const { data, isLoading } = useFetchHandler(
    TAB_API_MAP[activeTab],
    activeTab,
    !!activeTab
  );

  const filteredData = React.useMemo(() => {
    if (!data) return [];
    if (!searchText.trim()) return data;
    const search = searchText.toLowerCase();
    return (data as any[]).filter((item) =>
      JSON.stringify(item).toLowerCase().includes(search)
    );
  }, [data, searchText]);

  const currentTabConfig = TABS_CONFIG.find((t) => t.value === activeTab);

  const renderTable = () => {
    if (!currentTabConfig) return null;

    if (currentTabConfig.type === "permissions") {
      return (
        <AccessControlTable
          workspaces={filteredData as any}
          columns={currentTabConfig.columns!}
        />
      );
    }

    if (currentTabConfig.type === "persona") {
      return (
        <PersonaTable
          personas={filteredData as any}
          type={currentTabConfig.label as "Persona" | "Category"}
        />
      );
    }
    return null;
  };

  return (
    <div>
      <TabsWrapper
        tabs={TABS_CONFIG}
        value={activeTab}
        onValueChange={setActiveTab}
      />

      <div className="mt-4">
        {isLoading ? (
          <Skeleton className="w-full h-[60vh] rounded-md bg-gray-200" />
        ) : (
          renderTable()
        )}
      </div>
    </div>
  );
}
