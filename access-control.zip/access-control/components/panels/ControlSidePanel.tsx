import React from "react";
import { X } from "lucide-react";
import { useAccessControlStore } from "../../lib/store";

type Props = {
  isOpen: boolean;
  title: string;
  children: React.ReactNode;
};

export default function ControlSidePanel({ isOpen, title, children }: Props) {
  const { closePanel } = useAccessControlStore();

  return (
    <div className="font-unilever">
      {/* Overlay */}
      <div
        className={`fixed inset-0 z-40 bg-black/25 transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={closePanel}
      />

      {/* Panel */}
      <div
        className={`fixed top-0 right-0 h-full w-[500px] bg-white shadow-2xl p-6 transition-transform duration-300 ease-in-out z-50 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between pb-2">
        <h2 className="text-lg font-semibold ">{title}</h2>
          <button
            onClick={closePanel}
            className="p-1 rounded-full hover:bg-gray-100"
          >
            <X className="h-5 w-5 text-gray-600" />
          </button>
        </div>
        <div className="mt-6 h-[calc(100%-80px)] overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
}
