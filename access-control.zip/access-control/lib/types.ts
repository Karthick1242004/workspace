export interface GroupMember {
    principal_name: string;
    principal_type: "ad_group" | "user";
  }
  
  export interface WorkspacePermission {
    resource_id: number;
    resource_name: string;
    workspace_name?: string;
    owners?: GroupMember[];
    editors?: GroupMember[];
    viewers?: GroupMember[];
  }
  
  export interface Persona {
    id: number;
    name: string;
    description: string;
  }