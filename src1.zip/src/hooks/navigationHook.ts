import { useNavigate } from 'react-router-dom';

interface NavigationOptions {
  path: string;
  state?: Record<string, any>;
}
export const useNavigation = () => {
  const navigate = useNavigate();

  const navigateTo = ({ path, state }: NavigationOptions) => {
    navigate(path, {state});
  };

  return {
    navigateTo,
  };
};