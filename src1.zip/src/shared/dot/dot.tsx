import React from 'react'; 

export default function Dot({ bgcolor }: { bgcolor: string }) {
  return (
    <p className={`rounded-full w-2 h-2 ${bgcolor}`}></p>
  )
}
