import React, { useState } from 'react'
import { MoreHorizontal, PencilLine, Pin, Trash, Zap } from "lucide-react"
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarTrigger,
} from "@/components/ui/menubar"
import SearchBar from '../../searchbar';
 
export default function RecentSkills() {
  const initialSkills = [
    { icon: Zap, text: "Pipeline Review", pinned: false },
    { icon: Zap, text: "Corporate", pinned: false },
    { icon: Zap, text: "Approving CAPEX", pinned: false },
    { icon: Zap, text: "France Market", pinned: false },
  ];
 
  const [skills, setSkills] = useState(initialSkills);
  const [searchQuery, setSearchQuery] = useState('');
 
  const togglePin = (index: number) => {
    const updated = [...skills];
    updated[index].pinned = !updated[index].pinned;
    setSkills(updated);
  };
 
  const filteredSkills = skills
    .filter((item) => item.text.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => Number(b.pinned) - Number(a.pinned)); // pinned items first
 
  return (
    <div>
      <div className="px-3">
        <p className="text-[14px] text-gray-600 mb-2 ml-3">Recent Skills</p>
        <SearchBar
          onChange={(e) => setSearchQuery(e.target.value)}
          value={searchQuery}
          placeholder="Search skills..."
        />
        <div className="overflow-y-auto scrollbar-hide">
          {filteredSkills.map((item, index) => (
            <div
              key={index}
              className="group flex justify-between items-center text-[#4B4B53] gap-3 px-3  hover:bg-white rounded-md cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <span className='border-2 border-gray-600 text-gray-900 p-[1.5px] rounded-md'><Zap size={11} /></span>
                <p className="text-xs">{item.text}</p>
     
              </div>
              {item.pinned && <Pin className="h-4 w-4 mt-1 text-black ml-1" />}
              <div className="invisible group-hover:visible">
                <Menubar className="border-0">
                  <MenubarMenu>
                    <MenubarTrigger className="p-1 cursor-pointer bg-gray-50">
                      <MoreHorizontal className="h-4 w-4 text-gray-500" />
                    </MenubarTrigger>
                    <MenubarContent align="end" side="right" className="w-[160px] bg-white border-none">
                      <MenubarItem className="flex gap-2">
                        <PencilLine size={15} /> Rename
                      </MenubarItem>
                      <MenubarItem className="flex gap-2" onClick={() => togglePin(index)}>
                        <Pin size={15} /> {item.pinned ? "Unpin" : "Pin"}
                      </MenubarItem>
                      <MenubarItem className="text-red-600 flex gap-2">
                        <Trash size={15} /> Delete
                      </MenubarItem>
                    </MenubarContent>
                  </MenubarMenu>
                </Menubar>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}