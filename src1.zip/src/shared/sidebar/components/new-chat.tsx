import React from 'react'
import ChatLogo from "@/assets/icons/chat.svg";
import { Link } from 'react-router-dom';

export default function NewChatButton() {
  return (
    <div>
      <div className="flex flex-row gap-2 items-center py-4 pl-6 border-b border-gray-200">
        <img src={ChatLogo} alt="Chat Logo" className="h-[20px] w-[20px]" />
        <Link to='/chat' className="text-[14px] font-unilever">New Chat</Link>
      </div>
    </div>
  )
}
