import React, { useState } from "react";
import SearchBar from "@/shared/searchbar";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import { useQueryClient } from "@tanstack/react-query";
import { useFetchHandler } from "@/@logic/getHandlers";
import { SkeletonChatItem } from "@/shared/sidebar/components/chat/RecentChatsSkeleton";
import { SkillItem } from "./SkillItem";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { useChatSessionStore } from "@/modules/chat/store/chatSessionStore";
import { useNavigation } from "@/hooks/navigationHook";
import { useUsageLogger } from "@/utils/usageLogger";
import { usageLoggerConstants } from "@/constant/usageLogger";

export interface ApiSkill {
  id: number;
  name: string;
  is_favorited?: boolean;
  workspace_id: number;
}

export default function RecentSkills() {
  const [searchQuery, setSearchQuery] = useState("");
  const [favoriteSkillId, setFavoriteSkillId] = useState<number | null>(null);

  const {
    data: recentSkills = [],
    isLoading,
    error,
  } = useFetchHandler("skills/recent", "recent-skills");
  const queryClient = useQueryClient();

  const { navigateTo } = useNavigation();

  const { setSelectedWorkspaceId, setSelectedSkillId } = useWorkspaceStore();
  const { startNewChatSession } = useChatSessionStore();
  const usageLogger = useUsageLogger()
  
  const { mutate: favoriteMutate, isPending: isFavoriting } = useMutateHandler({
    endUrl: `skills/favorite`,
    method: HTTPMethod.POST,
    onSuccess: (_data, variables) => {
      setFavoriteSkillId(null);
      queryClient.invalidateQueries({ queryKey: ["recent-skills"] });
      const {resource_id, is_favorite} = variables as any
      usageLogger(`${is_favorite ? 'Favorited' : 'UnFavorited'} the Skill`,'skill',resource_id)
    },
  });

  const { mutate: deleteMutate, isPending: isDeleting } = useMutateHandler({
    endUrl: `skills/delete`,
    method: HTTPMethod.DELETE,
    onSuccess: (_data,variables) => {
      queryClient.invalidateQueries({ queryKey: ["recent-skills"] });
      const {id} = variables as any
      usageLogger(`${usageLoggerConstants.delete.skill} ${id}`)
    },
  });

  const handleSkillClick = (skill: ApiSkill) => {
    setSelectedWorkspaceId(skill.workspace_id);
    setSelectedSkillId(skill.id);
    startNewChatSession();
    navigateTo({ path: `/chat` });
  };

  const handleToggleFavorite = (skill: ApiSkill) => {
    setFavoriteSkillId(skill.id);
    favoriteMutate({
      resource_id: skill.id,
      resource_type: "skill",
      is_favorite: !skill.is_favorited,
    });
  };

  const handleDelete = (skill: ApiSkill) => {
    deleteMutate({ id: skill.id });
  };

  if (isLoading) {
    return (
      <div className="px-3">
        <p className="text-[12px] text-gray-600 mb-2 ml-3">Recent Skills</p>
        <div className="flex flex-col gap-1">
          <SkeletonChatItem />
          <SkeletonChatItem />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="px-3">
        <p className="text-[12px] text-gray-600 mb-2 ml-3">Recent Skills</p>
        <div className="text-[12px] flex text-red-500 justify-center items-center py-4">
          Failed to load recent skills...
        </div>
      </div>
    );
  }

  const sortedSkills = [...recentSkills].sort((a, b) => {
    return (b.is_favorited ? 1 : 0) - (a.is_favorited ? 1 : 0);
  });

  const filteredSkills = sortedSkills.filter((skill) =>
    skill.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="px-3 py-1">
      <p className="text-[12px] text-gray-600 mb-2 ml-3">Recent Skills</p>
      <SearchBar
        onChange={(e) => setSearchQuery(e.target.value)}
        value={searchQuery}
        placeholder="Search skills..."
      />
      <div>
        {filteredSkills.map((skill) => (
          <SkillItem
            key={skill.id}
            skill={skill}
            onClick={() => handleSkillClick(skill)}
            onToggleFavorite={handleToggleFavorite}
            onDelete={handleDelete}
            isFavoriting={isFavoriting}
            isDeleting={isDeleting}
            favoriteSkillId={favoriteSkillId}
          />
        ))}
        {filteredSkills && filteredSkills.length === 0 ? (
          <p className="text-[12px] text-gray-600 py-4 text-center">
            No skills found
          </p>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
}
