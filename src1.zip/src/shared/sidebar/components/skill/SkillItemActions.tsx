import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarTrigger,
} from "@/components/ui/menubar";
import { MoreHorizontal, StarOff, Star, Trash } from "lucide-react";
import { ApiSkill } from "./RecentSkills";

interface SkillItemActionsProps {
  skill: ApiSkill;
  onToggleFavorite: (e: React.MouseEvent) => void;
  onDelete: (e: React.MouseEvent) => void;
  isFavoriting?: boolean;
  isDeleting?: boolean;
}

export const SkillItemActions: React.FC<SkillItemActionsProps> = ({
  skill,
  onToggleFavorite,
  onDelete,
  isFavoriting,
  isDeleting,
}) => {
  return (
    <Menubar className="border-0 bg-transparent p-0 h-auto">
      <MenubarMenu>
        <MenubarTrigger
          className="p-1 cursor-pointer hover:bg-gray-200 rounded-full data-[state=open]:bg-gray-200"
          onClick={(e) => e.stopPropagation()}
          disabled={isFavoriting || isDeleting}
        >
          <MoreHorizontal className="h-4 w-4 text-gray-500" />
        </MenubarTrigger>
        <MenubarContent
          align="end"
          side="right"
          className="w-[170px] bg-white shadow-lg rounded-md border-gray-200 text-xs"
        >
          <MenubarItem
            className="flex items-center gap-2 py-1.5 px-2.5 cursor-pointer hover:bg-gray-100"
            disabled={isFavoriting || isDeleting}
            onClick={onToggleFavorite}
          >
            {skill.is_favorited ? (
              <>
                <StarOff size={14} className="text-gray-600" /> Unfavorite
              </>
            ) : (
              <>
                <Star size={14} className="text-gray-600" /> Favorite
              </>
            )}
          </MenubarItem>
          <MenubarItem
            className="flex items-center gap-2 py-1.5 px-2.5 text-red-600 hover:bg-red-50 cursor-pointer"
            disabled={isDeleting || isFavoriting}
            onClick={onDelete}
          >
            <Trash size={14} /> Delete
          </MenubarItem>
        </MenubarContent>
      </MenubarMenu>
    </Menubar>
  );
};
