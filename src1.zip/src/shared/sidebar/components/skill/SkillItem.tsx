import { cn } from "@/lib/utils";
import { SkillItemActions } from "./SkillItemActions";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { BrainCog, LoaderCircle, Star } from "lucide-react";
import { ApiSkill } from "./RecentSkills";

interface SkillItemProps {
  skill: ApiSkill;
  isHighlighted?: boolean;
  onClick: () => void;
  onToggleFavorite: (skill: ApiSkill) => void;
  onDelete: (skill: ApiSkill) => void;
  isFavoriting?: boolean;
  isDeleting?: boolean;
  favoriteSkillId?: number | null;
}

export const SkillItem: React.FC<SkillItemProps> = ({
  skill,
  isHighlighted = false,
  onClick,
  onToggleFavorite,
  onDelete,
  isFavoriting,
  isDeleting,
  favoriteSkillId,
}) => {
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(skill);
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(skill);
  };

  return (
    <div
      onClick={onClick}
      className={cn(
        "group flex flex-row justify-between items-center text-gray-700 px-3 py-1 my-1 rounded-md cursor-pointer transition-colors duration-150",
        isHighlighted
          ? "bg-[#EFF1FF] text-blue-700 font-semibold border-[#1f35c41f] border-[1px]"
          : "hover:bg-white"
      )}
      title={skill.name}
    >
      <div className="flex items-center gap-2.5 flex-grow min-w-0">
        <BrainCog size={18}className={cn(
            "flex-shrink-0",
            isHighlighted ? "text-blue-600" : "text-gray-500"
          )}
        />
        <p
          className={cn(
            "text-[11px] flex-grow truncate font-unilever",
            isHighlighted ? "font-semibold" : "font-normal"
          )}
        >
          {skill.name}
        </p>
      </div>

      <div className="flex items-center flex-shrink-0">
        {isFavoriting && favoriteSkillId === skill.id ? (
          <LoaderCircle
            color="var(--workspace-color-highlight)"
            className="animate-spin"
            size={14}
          />
        ) : (
          skill.is_favorited && (
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={handleFavoriteClick}
                  className="rounded-full hover:bg-yellow-100 mr-1 cursor-pointer"
                  aria-label="Unfavorite skill"
                  disabled={isFavoriting}
                >
                  <Star size={15} className="text-yellow-500 fill-yellow-500" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="top" className="text-xs">
                <p>Unfavorite</p>
              </TooltipContent>
            </Tooltip>
          )
        )}
        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
          <SkillItemActions
            skill={skill}
            onToggleFavorite={handleFavoriteClick}
            onDelete={handleDeleteClick}
            isFavoriting={isFavoriting}
            isDeleting={isDeleting}
          />
        </div>
      </div>
    </div>
  );
};
