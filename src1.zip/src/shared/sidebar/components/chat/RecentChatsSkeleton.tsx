import React from 'react';

export const SkeletonChatItem: React.FC = () => (
  <div className="flex items-center gap-3 px-3 py-2.5 my-1.5 rounded-md bg-gray-100 animate-pulse">
    <div className="w-5 h-5 bg-gray-300 rounded-full"></div>
    <div className="flex-grow h-4 bg-gray-300 rounded"></div>
  </div>
);