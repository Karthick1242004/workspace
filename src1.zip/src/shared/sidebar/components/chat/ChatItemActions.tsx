import React, { useState } from "react";
import {
  MoreHorizontal,
  PencilLine,
  Star,
  StarOff,
  Trash,
} from "lucide-react";
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarTrigger,
} from "@/components/ui/menubar";
import { Chat } from "./RecentChatsList";
import ChatSessionRename from "./ChatSessionRename";

interface ChatItemActionsProps {
  chat: Chat;
  onToggleFavorite: (e: React.MouseEvent) => void;
  onDelete: (e: React.MouseEvent) => void;
  isFavoriting?: boolean;
  isDeleting?: boolean;
}

export const ChatItemActions: React.FC<ChatItemActionsProps> = ({
  chat,
  onToggleFavorite,
  onDelete,
  isFavoriting,
  isDeleting,
}) => {
  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);

  const handleActionClick = (
    e: React.MouseEvent,
    action?: (e: React.MouseEvent) => void,
  ) => {
    e.stopPropagation();
    action?.(e);
  };

  const handleRenameClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsRenameDialogOpen(true);
  };

  const handleRenameClose = () => {
    setIsRenameDialogOpen(false);
  };

  return (
    <>
      <Menubar className="border-0 bg-transparent p-0 h-auto">
        <MenubarMenu>
          <MenubarTrigger
            className="p-1 cursor-pointer hover:bg-gray-200 rounded-full data-[state=open]:bg-gray-200"
            onClick={(e) => e.stopPropagation()}
            disabled={isFavoriting || isDeleting}
          >
            <MoreHorizontal className="h-4 w-4 text-gray-500" />
          </MenubarTrigger>
          <MenubarContent
            align="end"
            side="right"
            className="w-[170px] bg-white shadow-lg rounded-md border-gray-200 text-xs"
          >
            <MenubarItem
              className="flex items-center gap-2 py-1.5 px-2.5 cursor-pointer hover:bg-gray-100"
              disabled={isDeleting || isFavoriting}
              onClick={handleRenameClick}
            >
              <PencilLine size={14} className="text-gray-600" /> Rename
            </MenubarItem>
            <MenubarItem
              className="flex items-center gap-2 py-1.5 px-2.5 cursor-pointer hover:bg-gray-100"
              onClick={(e) => handleActionClick(e, onToggleFavorite)}
              disabled={isFavoriting || isDeleting}
            >
              {chat.is_favorite ? (
                <>
                  <StarOff size={14} className="text-gray-600" /> Unfavorite
                </>
              ) : (
                <>
                  <Star size={14} className="text-gray-600" /> Favorite
                </>
              )}
            </MenubarItem>
            <MenubarItem
              className="flex items-center gap-2 py-1.5 px-2.5 text-red-600 hover:bg-red-50 cursor-pointer"
              onClick={(e) => handleActionClick(e, onDelete)}
              disabled={isDeleting || isFavoriting}
            >
              <Trash size={14} /> Delete
            </MenubarItem>
          </MenubarContent>
        </MenubarMenu>
      </Menubar>

      {isRenameDialogOpen && (
        <ChatSessionRename
          chatTitle={chat.title}
          chatUuid={chat.uuid}
          isOpen={isRenameDialogOpen}
          onCancel={handleRenameClose}
        />
      )}

    </>
  );
};
