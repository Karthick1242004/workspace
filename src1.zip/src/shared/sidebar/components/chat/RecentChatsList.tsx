import React, { useState, useMemo, useEffect, useCallback } from "react";
import { useFetchHandler } from "@/@logic/getHandlers";
import { useNavigation } from "@/hooks/navigationHook";
import { cn } from "@/lib/utils";
import { useParams } from "react-router-dom";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import { Skill, Workspace } from "@/@logic/workspaceStore";
import { useQueryClient } from "@tanstack/react-query";
import SearchBar from "@/shared/searchbar";
import { ChatItem } from "./ChatItem";
import { SkeletonChatItem } from "./RecentChatsSkeleton";
import { useUsageLogger } from "@/utils/usageLogger";

export interface Chat {
  id: number;
  uuid: string;
  title: string;
  createdAt: string;
  lastUpdated: string;
  skill: Skill;
  workspace: Workspace;
  is_favorite: boolean;
}

export default function RecentChatsList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [highlightedChatId, setHighlightedChatId] = useState<string | null>(
    null
  );

  const { navigateTo } = useNavigation();
  const params = useParams<{ chatId?: string }>();
  const queryClient = useQueryClient();
  const usageLogger = useUsageLogger()
  const {
    data: chatsData,
    isLoading: isLoadingChats,
    error: chatsError,
  } = useFetchHandler("chats/recent/", "recent-chats-list") as {
    data: Chat[] | undefined;
    isLoading: boolean;
    error: any;
  };
  const chats: Chat[] = chatsData || [];

  const { mutate: deleteMutate, isPending: isDeleting } = useMutateHandler({
    endUrl: `chats/delete`,
    method: HTTPMethod.POST,
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["recent-chats-list"] });
      const {chat_session_uuid } = variables as any
      usageLogger(`Deleted the Chat Session ${chat_session_uuid}`)
    },
  });

  const {
    mutate: favouriteMutate,
    isPending: isFavoriting,
    variables: favoriteDataRaw,
  } = useMutateHandler({
    endUrl: `chats/favorite`,
    method: HTTPMethod.POST,
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["recent-chats-list"] });
      const { is_favorite, chat_session_uuid } = variables as any
      usageLogger(`${is_favorite ? 'Favorited' : 'UnFavorited'} the Chat Session ${chat_session_uuid}`)
    },
  });
  const favoriteData: any = favoriteDataRaw;


  useEffect(() => {
    if (params.chatId) {
      const currentChatId = params.chatId;
      setHighlightedChatId(currentChatId);
    } else {
      setHighlightedChatId(null);
    }
  }, [params.chatId, chats]);

  const sortedAndFilteredChats = useMemo(() => {
    if (!chats) return [];
    const filtered = chats.filter(
      (chat) =>
        chat.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        chat.id.toString().includes(searchQuery)
    );
    return filtered.sort((a, b) => {
      if (a.is_favorite && !b.is_favorite) return -1;
      if (!a.is_favorite && b.is_favorite) return 1;
      return 0;
    });
  }, [chats, searchQuery]);

  const handleChatClick = useCallback(
    (chat: Chat) => {
      navigateTo({ path: `chat/${chat.uuid}` });
    },
    [navigateTo]
  );

  const handleDeleteChat = useCallback(
    (chatToDelete: Chat) => {
      if (params.chatId && params.chatId === chatToDelete.uuid) {
        navigateTo({ path: `/chat?new=true` });
      }
      deleteMutate({ chat_session_uuid: chatToDelete.uuid });
    },
    [deleteMutate, navigateTo, params.chatId]
  );

  const handleToggleFavorite = useCallback(
    (chatToFavorite: Chat) => {
      favouriteMutate({
        chat_session_uuid: chatToFavorite.uuid,
        is_favorite: !chatToFavorite.is_favorite,
      });
    },
    [favouriteMutate]
  );

  return (
    <div className="flex flex-col px-2 pt-3 border-t border-gray-200 min-h-0">
      <div className="flex-shrink-0 px-1 mb-3">
        <p className="text-xs text-gray-700 font-medium mb-2 ml-2">Recent Chats</p>
        <SearchBar
          onChange={(e) => setSearchQuery(e.target.value)}
          value={searchQuery}
          placeholder="Search chats..."
          className="mb-0"
        />
      </div>

      <div
        className={cn(
          "flex-1 overflow-y-auto -mt-3 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 min-h-0",
          "pr-1"
        )}
      >
        {isLoadingChats ? (
          Array.from({ length: 5 }).map((_, i) => <SkeletonChatItem key={i} />)
        ) : chatsError ? (
          <p className="text-xs text-red-500 text-center py-4">
            Error loading chats. Please try again.
          </p>
        ) : sortedAndFilteredChats.length === 0 ? (
          <p className="text-xs text-gray-500 text-center py-4">
            {searchQuery ? "No chats found." : "No recent chats."}
          </p>
        ) : (
          sortedAndFilteredChats.map((chat) => (
            <ChatItem
              key={chat.id}
              chat={chat}
              isHighlighted={highlightedChatId === chat.uuid}
              onClick={() => handleChatClick(chat)}
              onToggleFavorite={handleToggleFavorite}
              onDelete={handleDeleteChat}
              isFavoriting={isFavoriting}
              isDeleting={isDeleting}
              favoriteChatId={favoriteData?.chat_session_uuid}
            />
          ))
        )}
      </div>
    </div>
  );
}
