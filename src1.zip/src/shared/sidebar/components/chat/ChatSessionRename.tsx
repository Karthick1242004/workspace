import { HTTPMethod } from '@/@logic';
import { useMutateHandler } from '@/@logic/mutateHandlers';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from '@/components/ui/input';
import { useUsageLogger } from '@/utils/usageLogger';
import { useQueryClient } from '@tanstack/react-query';
import React, { useState, useCallback } from 'react';
import toast from 'react-hot-toast';

interface ChatRenameProp {
    chatTitle: string;
    chatUuid: string;
    isOpen: boolean;
    onCancel: () => void;
}

export default function ChatSessionRename({ chatTitle, chatUuid, isOpen, onCancel }: ChatRenameProp) {
    const [newName, setNewName] = useState(chatTitle);
    const queryClient = useQueryClient();
    const usageLogger = useUsageLogger();
    
    const { mutate: renameMutate, isPending: isRenaming } = useMutateHandler({
        endUrl: 'chats/rename-chat-session',
        method: HTTPMethod.POST,
        onSuccess: (_data, variables) => {
            toast.success("Renamed successfully");
            queryClient.invalidateQueries({ queryKey: ['recent-chats-list'] });
            onCancel();
            const {chat_session_uuid} = variables as any
            usageLogger(`Renamed the Chat Session ${chat_session_uuid}`)
        },
    });

    const handleRename = useCallback(() => {
        if (newName.trim() === "") {
            toast.error("Chat title cannot be empty");
            return;
        }
        renameMutate({
            chat_session_uuid: chatUuid,
            new_name: newName.trim(),
        });
    }, [renameMutate, chatUuid, newName]);

    return (
      <Dialog open={isOpen} onOpenChange={(open) => !open && onCancel()}>
        <DialogContent className="sm:max-w-[360px] bg-white rounded-md p-6 shadow-md">
          <DialogHeader>
            <DialogTitle className="text-black font-semibold text-sm font-unilever">Rename chat title</DialogTitle>
          </DialogHeader>

          <div className="mt-4">
            <Input
              id="chatTitle"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              required
              className="h-8 text-xs font-normal text-gray-600 border-gray-300"
              autoFocus
            />
          </div>

          <DialogFooter className="mt-6 flex justify-end gap-2 border-t border-gray-300 pt-4">
            <DialogClose asChild>
              <button
                className="border border-red-500 text-red-500 text-xs font-normal py-1.5 px-6 rounded-sm hover:bg-red-50 cursor-pointer"
                type="button"
                onClick={() => setNewName(chatTitle)}
              >
                Cancel
              </button>
            </DialogClose>

            <button
              className="bg-blue-600 text-white text-xs font-normal py-1.5 px-3 rounded-sm hover:bg-blue-700 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={handleRename}
              type="button"
              disabled={isRenaming}
            >
              {isRenaming ? "Saving..." : "Save Changes"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
}
