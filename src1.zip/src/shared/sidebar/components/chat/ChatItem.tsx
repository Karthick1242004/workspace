import React from "react";
import { LoaderCircle, MessageCircleMore, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { ChatItemActions } from "./ChatItemActions";
import { Chat } from "./RecentChatsList";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ChatItemProps {
  chat: Chat;
  isHighlighted: boolean;
  onClick: () => void;
  onToggleFavorite: (chat: Chat) => void;
  onDelete: (chat: Chat) => void;
  isFavoriting?: boolean;
  isDeleting?: boolean;
  favoriteChatId?: string;
}

export const ChatItem: React.FC<ChatItemProps> = ({
  chat,
  isHighlighted,
  onClick,
  onToggleFavorite,
  onDelete,
  isFavoriting,
  isDeleting,
  favoriteChatId,
}) => {
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(chat);
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(chat);
  };

  return (
    <div
      onClick={onClick}
      className={cn(
        "group flex flex-row justify-between items-center text-gray-700 px-3 py-1 my-1 rounded-md cursor-pointer transition-colors duration-150",
        isHighlighted
          ? "bg-[#EFF1FF] text-blue-700 font-semibold border-[#1f35c41f] border-[1px]"
          : "hover:bg-white"
      )}
      title={chat.title || `Chat ${chat.id}`}
    >
      <div className="flex items-center gap-2.5 flex-grow min-w-0">
        <MessageCircleMore
          size={18}
          className={cn(
            "flex-shrink-0",
            isHighlighted ? "text-blue-600" : "text-gray-500"
          )}
        />
        <p
          className={cn(
            "text-[11px] flex-grow truncate font-unilever",
            isHighlighted ? "font-semibold" : "font-normal"
          )}
        >
          {chat.title || `Chat ${chat.id}`}
        </p>
      </div>

      <div className="flex items-center flex-shrink-0">
        {isFavoriting && favoriteChatId === chat.uuid ? (
          <LoaderCircle
            color="var(--workspace-color-highlight)"
            className="animate-spin"
          />
        ) : (
          chat.is_favorite && (
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={handleFavoriteClick}
                  className="p-1 rounded-full hover:bg-yellow-100 mr-1 cursor-pointer"
                  aria-label="Unfavorite chat"
                  disabled={isFavoriting}
                >
                  <Star size={15} className="text-yellow-500 fill-yellow-500" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="top" className="text-xs">
                <p>Unfavorite</p>
              </TooltipContent>
            </Tooltip>
          )
        )}
        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
          <ChatItemActions
            chat={chat}
            onToggleFavorite={handleFavoriteClick}
            onDelete={handleDeleteClick}
            isFavoriting={isFavoriting}
            isDeleting={isDeleting}
          />
        </div>
      </div>
    </div>
  );
};
