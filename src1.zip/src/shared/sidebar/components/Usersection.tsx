import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { getUserProfile } from "@/utils/getUserProfile";
import { useMsal } from "@azure/msal-react";
import { Avatar, AvatarFallback, AvatarImage } from "@radix-ui/react-avatar";
import { ChevronsUpDown, Shield, BarChart3, HelpCircle } from "lucide-react";
import React, { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";

interface UsersectionProps {
  sideBarCollapse: boolean;
}

const Usersection = ({ sideBarCollapse }: UsersectionProps) => {
  const [avatar, setAvatar] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true);
  const { accounts } = useMsal();

  const account = accounts[0];
  const name = account?.name || "";
  const email = account?.username || "";
  const isSuperAdmin =
    account?.idTokenClaims?.roles?.includes("MSB_SUPER_ADMINS");

  
  // Improved name parsing with better fallback logic
  const getInitials = useCallback((fullName: string): string => {
    if (!fullName) return "U";

    // Handle "Last, First" format
    if (fullName.includes(", ")) {
      const [lastName, firstName] = fullName.split(", ");
      return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
    }

    // Handle "First Last" format
    const nameParts = fullName.split(" ");
    if (nameParts.length >= 2) {
      return `${nameParts[0][0]}${nameParts[1][0]}`.toUpperCase();
    }

    // Single name fallback
    return fullName.charAt(0).toUpperCase();
  }, []);

  // Improved display name parsing
  const getDisplayName = useCallback((fullName: string): string => {
    if (!fullName) return "Unknown User";

    // Handle "Last, First" format
    if (fullName.includes(", ")) {
      const [lastName, firstName] = fullName.split(", ");
      return `${firstName} ${lastName}`;
    }

    return fullName;
  }, []);

  const fetchUserProfile = useCallback(async () => {
    if (accounts.length === 0) return;

    try {
      setIsLoading(true);
      const userProfile = await getUserProfile(account);
      setAvatar(userProfile || "");
    } catch (error) {
      console.error("Failed to fetch user profile:", error);
      setAvatar("");
    } finally {
      setIsLoading(false);
    }
  }, [accounts, account]);

  useEffect(() => {
    fetchUserProfile();
  }, [fetchUserProfile]);

  // Loading state
  if (isLoading) {
    return (
      <div className="flex flex-row gap-4 items-center bg-white rounded-md p-1 font-unilever animate-pulse">
        <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
        {sideBarCollapse && (
          <div className="flex-1">
            <div className="h-3 bg-gray-300 rounded mb-1"></div>
            <div className="h-2 bg-gray-300 rounded w-16"></div>
          </div>
        )}
      </div>
    );
  }

  const displayName = getDisplayName(name);
  const initials = getInitials(name);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <div className="flex flex-row gap-4 items-center bg-white rounded-md px-1 py-3 font-unilever cursor-pointer hover:bg-gray-50 transition-colors w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1">
          <div className="flex gap-2 items-center flex-1 min-w-0">
            <Avatar className="relative">
              <AvatarImage
                className="rounded-full w-8 h-8 object-cover"
                src={avatar}
                alt={`${displayName}'s profile`}
              />
              <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white text-xs font-medium w-8 h-8 rounded-full flex items-center justify-center">
                {initials}
              </AvatarFallback>
            </Avatar>

            {sideBarCollapse && (
              <div className="flex-1 min-w-0 text-left">
                <p className="font-unilever text-xs font-medium text-gray-900 truncate">
                  {displayName}
                </p>
                {isSuperAdmin && (
                  <p className="font-unilever text-gray-500 text-xs flex items-center gap-1">
                    Super Admin
                  </p>
                )}
              </div>
            )}
          </div>
          {sideBarCollapse && (
            <ChevronsUpDown size={12} className="text-gray-400 flex-shrink-0" />
          )}
        </div>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        className="w-56 bg-white border border-gray-200 shadow-lg rounded-lg"
        align="start"
        sideOffset={5}
      >
        <DropdownMenuLabel className="px-3 py-2 border-b-1 border-[#717174]">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium text-gray-900 font-unilever">
              {displayName}
            </p>
            <p className="text-xs text-gray-500 font-unilever">{email}</p>
          </div>
        </DropdownMenuLabel>

        <DropdownMenuSeparator />

        <DropdownMenuGroup>
          <DropdownMenuItem asChild>
            <Link
              to="/access-control"
              className="flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 cursor-pointer font-unilever"
            >
              <Shield size={14} />
              {isSuperAdmin ? "Admin Controls" : "Access Control"}
            </Link>
          </DropdownMenuItem>

          {isSuperAdmin && <DropdownMenuItem asChild>
            <Link
              to="/analytics"
              className="flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 cursor-pointer font-unilever"
            >
              <BarChart3 size={14} />
              Analytics
            </Link>
          </DropdownMenuItem>
          }


          <DropdownMenuItem asChild>
            <Link
              to="/help-section"
              className="flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 cursor-pointer font-unilever"
            >
              <HelpCircle size={14} />
              Help
            </Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default Usersection;
