import SearchBar from "../../searchbar";
import {
  MessageCircleMore,
  MoreHorizontal,
  PencilLine,
  Pin,
  PinOff,
  Trash,
} from "lucide-react";
import React, { useState, useMemo, useEffect } from "react";
import { useFetchHandler } from "@/@logic/getHandlers";
import { useNavigation } from "@/hooks/navigationHook";
import { cn } from "@/lib/utils";
import { useParams } from "react-router-dom";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import { Skill, useWorkspaceStore, Workspace } from "@/@logic/workspaceStore";
import { useQueryClient } from "@tanstack/react-query";
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarTrigger,
} from "@/components/ui/menubar";

interface Chat {
  id: number;
  title: string;
  createdAt: string;
  lastUpdated: string;
  skill: Skill;
  workspace: Workspace;
  is_favorite: boolean;
}

export default function RecentChats() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);

  const { navigateTo } = useNavigation();
  const params = useParams();
  const { setSelectedSkillId, setSelectedWorkspaceId } = useWorkspaceStore();
  const queryClient = useQueryClient();

  const { data: chats } = useFetchHandler(
    "chats/recent/?userId=1",
    "chats/recent"
  ) as { data: Chat[] };

  const { mutate: deleteMutate } = useMutateHandler({
    endUrl: `chats/delete`,
    method: HTTPMethod.POST,
    onSuccess: () => {
      setSelectedChat(null);
      queryClient.invalidateQueries({ queryKey: ["chats/recent"] });
    },
  });

  const { mutate: favouriteMutate } = useMutateHandler({
    endUrl: `chats/favorite`,
    method: HTTPMethod.POST,
    onSuccess: () => {
      setSelectedChat(null);
      queryClient.invalidateQueries({ queryKey: ["chats/recent"] });
    },
  });

  useEffect(() => {
    if (params.chatId && chats) {
      const chat = chats.find((chat) => chat.id === Number(params.chatId));
      if (chat) {
        setSelectedChat(chat);
        setSelectedSkillId(chat.skill.id);
        setSelectedWorkspaceId(chat.workspace.id);
      } else {
        setSelectedChat(null);
      }
    }
  }, [chats, params, setSelectedSkillId, setSelectedWorkspaceId]);

  const filteredChats = useMemo(() => {
    if (!searchQuery.trim() || !chats) return chats;
    return chats.filter(
      (chat) =>
        chat.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        chat.id.toString().includes(searchQuery)
    );
  }, [chats, searchQuery]);

  const handleChatClick = (chat: Chat) => {
    setSelectedChat(chat);
    setSelectedSkillId(chat.skill.id);
    setSelectedWorkspaceId(chat.workspace.id);
    navigateTo({ path: `chat/${chat.id}` });
  };

  const handleDeleteChat = (chat: Chat) => {
    if (params.chatId && Number(params.chatId) === chat.id) {
      navigateTo({ path: `/chat/new` })
    }
    deleteMutate({ id: chat.id, user_id: 1, chat_session_id: chat.id });

  };

  return (
    <div className="flex-1 px-4 py-3 border-t border-gray-200">
      <p className="text-[14px] text-gray-600 mb-2 ml-2">Recent Chats</p>
      <SearchBar
        onChange={(e) => setSearchQuery(e.target.value)}
        value={searchQuery}
        placeholder="Search chats..."
      />
      <div
        className="overflow-y-auto scrollbar-hide h-[calc(var(--sidebar-height)_-_var(--recent-skills-height)_-_20rem)]"
        style={{ padding: "0 1px" }}
      >
        {filteredChats?.map((chat, index) => (
          <div
            key={index}
            onClick={() => handleChatClick(chat)}
            className={cn(
              "group flex flex-row justify-between items-center text-[#4B4B53] px-3 rounded-md cursor-pointer",
              selectedChat?.id === chat.id
                ? "color-[#5B6EFB] bg-[#EFF1FF]"
                : " hover:bg-gray-100"
            )}
          >
            <div
              key={chat.id}
              className="flex flex-grow-1 !text-[#4B4B53] items-center gap-3 py-1 pr-2 hover:bg-gray-100 rounded-[10px] cursor-pointer"
            >
              <MessageCircleMore
                size={20}
                className={selectedChat?.id === chat.id ? "text-[#1F36C7]" : ""}
              />
              <div className="flex flex-grow-1">
                <p
                  className={cn(
                    "text-xs flex-grow-1 truncate",
                    selectedChat?.id === chat.id
                      ? "font-bold text-[#1F36C7]"
                      : ""
                  )}
                >
                  {chat.title ? chat.title : chat.id}
                </p>
                {chat.is_favorite && (
                  <Pin
                    size={20}
                    className="cursor-pointer text-[#7283ff]"
                    onClick={(e) => {
                      favouriteMutate({
                        chat_session_id: chat.id,
                        user_id: 1,
                      });
                      e.stopPropagation();
                    }}
                  />
                )}
              </div>
            </div>
            <div className="invisible group-hover:visible">
              <Menubar className="border-0">
                <MenubarMenu>
                  <MenubarTrigger className="p-1 cursor-pointer bg-gray-200">
                    <MoreHorizontal
                      className="h-4 w-4 text-gray-500"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </MenubarTrigger>
                  <MenubarContent
                    align="end"
                    side="right"
                    className="w-[160px] bg-white border-none"
                  >
                    <MenubarItem className="flex flex-row gap-2 cursor-pointer">
                      <PencilLine size={15} /> Rename
                    </MenubarItem>
                    <MenubarItem
                      className="flex flex-row gap-2 cursor-pointer"
                      onClick={(e) => {
                        favouriteMutate({
                          chat_session_id: chat.id,
                          user_id: 1,
                        });
                        e.stopPropagation();
                      }}
                    >
                      {chat.is_favorite ? (
                        <>
                          <PinOff size={15} /> Unpin
                        </>
                      ) : (
                        <>
                          <Pin size={15} /> Pin
                        </>
                      )}
                    </MenubarItem>
                    <MenubarItem
                      className="text-red-600 flex flex-row gap-2 cursor-pointer"
                      onClick={(e) => {
                        handleDeleteChat(chat);
                        e.stopPropagation();
                      }}
                    >
                      <Trash size={15} /> Delete
                    </MenubarItem>
                  </MenubarContent>
                </MenubarMenu>
              </Menubar>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
