import React, { useState } from "react";
import RecentSkills from "./components/skill/RecentSkills";
import { Link, useLocation } from "react-router-dom";
import {
  LayoutGrid,
  PanelLeftClose,
  PanelLeftOpen,
  SquarePen,
} from "lucide-react";
import RecentChatsList from "./components/chat/RecentChatsList";
import { useNavigation } from "@/hooks/navigationHook";
import { useChatSessionStore } from "@/modules/chat/store/chatSessionStore";
import Usersection from "./components/Usersection";
import Ally from "@/assets/icons/Allylogo.svg";
import { cn } from "@/lib/utils";

export default function SideBar() {
  const location = useLocation();
  const { startNewChatSession } = useChatSessionStore();
  const { navigateTo } = useNavigation();
  const [isExpanded, setIsExpanded] = useState(true);
  const isChatPage = location.pathname === "/chat";
  const isWorkspacePage = location.pathname.startsWith("/workspace");
  const isAccessControlPage = location.pathname.includes("/access-control");

  const handleNewChat = () => {
    startNewChatSession();
    navigateTo({ path: `/chat` });
  };

  const toggleSidebar = () => {
    setIsExpanded((prev) => !prev);
  };

  return (
    <div
      className="transition-all duration-400 ease-in-out h-full rounded-[15px] shadow-lg overflow-hidden pb-2"
      style={{
        width: isExpanded ? "260px" : "4rem",
        background:
          "linear-gradient(0deg, rgba(255, 255, 255, 0.75) 0%, rgba(255, 255, 255, 0.75) 100%), linear-gradient(90deg, rgba(0, 94, 238, 0.08) 0%, rgba(0, 177, 143, 0.10) 100%)",
        boxShadow:
          "-4px 0px 4px 0px rgba(0, 94, 238, 0.05), 4px 0px 4px 0px rgba(0, 94, 238, 0.05), 0px 4px 4px 0px rgba(0, 94, 238, 0.05), 0px -2px 4px 0px rgba(0, 94, 238, 0.05)",
      }}
    >
      {isExpanded ? (
        // Expanded Sidebar
        <div className="font-unilever h-full py-2 flex flex-col w-full">
          <div className="flex-shrink-0">
            <div className="flex flex-row justify-between items-center py-2 px-4">
              <Link
                className="flex flex-row gap-2 items-center"
                to="/workspace"
              >
                <img src={Ally} alt="Ally" className="w-8 h-8" />
                <p className="text-xl font-bold bg-gradient-to-b from-indigo-500 via-indigo-700 to-indigo-900 bg-clip-text text-transparent">
                  Ally
                </p>
              </Link>
              <button
                className="cursor-pointer p-1 rounded"
                onClick={toggleSidebar}
                aria-label="Collapse sidebar"
              >
                <PanelLeftClose className="w-5 h-5" />
              </button>
            </div>

            <div className="flex flex-row gap-0 mt-2 items-center px-2 py-1 border-t border-gray-200">
              <Link
                to="/chat"
                onClick={handleNewChat}
                className={cn(
                  "w-full flex flex-row items-center gap-2 rounded-md px-3 py-2 text-[clamp(10px,12px,14px)] transition-all",
                  isChatPage
                    ? "bg-gradient-to-t from-indigo-800 via-indigo-600 to-indigo-400 text-white"
                    : "bg-transparent text-black hover:bg-white active:bg-gradient-to-b active:from-indigo-600 active:via-indigo-600 active:to-indigo-400 active:text-white"
                )}
              >
                <SquarePen size={15} className="text-current" />
                New Chat
              </Link>
            </div>

            <div className="flex flex-row gap-2 mb-1 items-center px-2 pb-2 mt-1.5 border-b border-gray-200">
              <Link
                to="/workspace/my-workspace"
                className={cn(
                  "w-full flex flex-row items-center gap-2 rounded-md px-3 py-2 text-[clamp(10px,12px,14px)] transition-all",
                  isWorkspacePage
                    ? "bg-gradient-to-t from-indigo-800 via-indigo-600 to-indigo-400 text-white"
                    : "bg-transparent text-black hover:bg-white active:bg-gradient-to-b active:from-indigo-600 active:via-indigo-600 active:to-indigo-400 active:text-white"
                )}
              >
                <LayoutGrid size={15} />
                Workspace & Skills
              </Link>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto overflow-x-hidden min-h-0 custom-scrollbar">
            <RecentSkills />
            <RecentChatsList />
          </div>

          <div className="flex-shrink-0 px-2 mt-2">
            <Usersection sideBarCollapse={isExpanded} />
          </div>
        </div>
      ) : (
        // Collapsed Sidebar
        <div className="flex flex-col justify-between py-3 px-2 font-unilever h-full">
          <div className="flex flex-col gap-2 px-1 mt-3">
            <button
              className="cursor-pointer flex justify-center p-1 hover:bg-gray-200 rounded"
              onClick={toggleSidebar}
              aria-label="Expand sidebar"
            >
              <PanelLeftOpen className="w-5 h-5" />
            </button>
            <div className="py-3 border-t-[1px] border-b-[1px] border-[#E4E4E4]">
              <Link
                to="/chat"
                onClick={handleNewChat}
                className={cn(
                  "w-full flex justify-center items-center rounded-md px-2.5 py-1.5 text-[clamp(10px,12px,14px)] transition-all",
                  isChatPage
                    ? "bg-gradient-to-t from-indigo-800 via-indigo-600 to-indigo-400 text-white"
                    : "bg-transparent text-black hover:bg-white active:bg-gradient-to-b active:from-indigo-600 active:via-indigo-600 active:to-indigo-400 active:text-white"
                )}
                title="New Chat"
              >
                <SquarePen size={18} className="text-current" />
              </Link>

              <Link
                to="/workspace/my-workspace"
                className={cn(
                  "w-full flex justify-center items-center rounded-md px-2.5 py-1.5 text-[clamp(10px,12px,14px)] transition-all",
                  isWorkspacePage
                    ? "bg-gradient-to-t from-indigo-800 via-indigo-600 to-indigo-400 text-white"
                    : "bg-transparent text-black hover:bg-white active:bg-gradient-to-b active:from-indigo-600 active:via-indigo-600 active:to-indigo-400 active:text-white"
                )}
                title="Workspace & Skills"
              >
                <LayoutGrid size={18} />
              </Link>
            </div>
          </div>

          <Usersection sideBarCollapse={isExpanded} />
        </div>
      )}
    </div>
  );
}
