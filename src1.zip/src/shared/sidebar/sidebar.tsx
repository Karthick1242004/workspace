import React from "react";
import RecentSkills from "./components/recent-skills";
import RecentChats from "./components/recent-chats";
import { Link, useLocation } from "react-router-dom";
import { LayoutGrid, SquarePen, UserPen } from "lucide-react";

export default function SideBar() {
  const location = useLocation();
  const isWorkspacePage = location.pathname.includes("/workspace/my-workspace");

  return (
    <div
      className="bg-[#F4FAFC] mt-2 relative rounded-[15px] font-unilever"
      style={{
        height: "var(--sidebar-height)",
        boxShadow: "var(--shadow-default)",
        minWidth: "var(--sidebar-width",
      }}
    >
      <div className="flex flex-col gap-2 justify-between h-full py-3">
        <>
          <div className="flex flex-row gap-2 items-center px-4 pb-1 border-b border-gray-200">
            <Link
              to="/workspace/my-workspace"
              className={`w-full flex flex-row items-center gap-2 rounded-md px-3 py-2 text-[12px] font-unilever transition-all ${
                isWorkspacePage
                  ? "bg-gradient-to-t from-indigo-800 via-indigo-600 to-indigo-400 text-white"
                  : "bg-transparent text-black active:bg-gradient-to-b active:from-indigo-600 active:via-indigo-600 active:to-indigo-400 active:text-white"
              }`}
            >
              <LayoutGrid size={15} />
              Workspace & Skills
            </Link>
            <Link to="/chat/new?new=true">
              <SquarePen size={18} className="text-gray-600" />
            </Link>
          </div>
          <RecentSkills />
          <RecentChats />
        </>
        <div className="px-3">
          <Link
            to="/access-control"
            className="w-full flex flex-row justify-center items-center text-[12px] text-[#495FE7] border border-[#495FE7] bg-none gap-2 rounded-sm px-3 py-2 font-unilever cursor-pointer"
          >
            <UserPen size={15} /> Access Controls
          </Link>
        </div>
      </div>
    </div>
  );
}
