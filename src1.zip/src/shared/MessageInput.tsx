import React, { KeyboardEvent, useEffect, useRef, useState } from "react";
import { Paperclip, ArrowUp, X } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import AI_BRAIN from "../assets/images/AI-brain.svg";
import COPY_RIGHT from "../assets/images/copyright.svg";
import GROUP from "../assets/images/Group.svg";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { cn } from "@/lib/utils";

interface MessageInputProps {
  onSendMessage: (message: string) => void;
  skillID: number;
  selectedImages: File[];
  setSelectedImages: React.Dispatch<React.SetStateAction<File[]>>;
  isAiResponding: boolean;
}

export const MessageInput: React.FC<MessageInputProps> = ({
  onSendMessage,
  skillID,
  selectedImages,
  setSelectedImages,
  isAiResponding,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [textInput, setTextInput] = useState("");
  const [previewURLs, setPreviewURLs] = useState<string[]>([]);
  const { workspaces } = useWorkspaceStore();

  const isSkillAvailable = workspaces.some((workspace) =>
    workspace.skills.some((skill) => skill.id === skillID)
  );

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey && !isAiResponding) {
      e.preventDefault();
      handleSendClick();
    }
  };

  const handleSendClick = () => {
    setSelectedImages([]);
    setPreviewURLs([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = ""; // Reset file input
    }
    if (textInput.trim()) {
      onSendMessage(textInput.trim());
      setTextInput("");
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []);
    const newPreviews = files.map((file) => URL.createObjectURL(file));
    setSelectedImages((prev) => prev.concat(files));
    setPreviewURLs((prev) => prev.concat(newPreviews));
  };

  useEffect(() => {
    return () => {
      previewURLs.forEach((url) => URL.revokeObjectURL(url));
    };
  }, []);

  const handleRemoveImage = (index: number) => {
    URL.revokeObjectURL(previewURLs[index]);

    setSelectedImages((prev) => [
      ...prev.slice(0, index),
      ...prev.slice(index + 1),
    ]);
    setPreviewURLs((prev) => [
      ...prev.slice(0, index),
      ...prev.slice(index + 1),
    ]);
  };

  const handlePaperclipClick = () => {
    if (isSkillAvailable && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div>
      <div
        className="border-[1.5px] border-[#FFC4D2] rounded-[10px] bg-white p-2 md:p-3 w-[50vw] flex flex-col items-center"
        style={{
          border: "1.5px solid transparent",
          borderRadius: "8px",
          backgroundImage: `linear-gradient(white,white), linear-gradient(to right, #FFC4D2, #9AF6F4)`,
          backgroundOrigin: "border-box",
          backgroundClip: "padding-box, border-box",
        }}
      >
        {previewURLs.length > 0 && (
          <div className="w-full mb-2 flex gap-2 flex-wrap">
            {previewURLs.map((url, idx) => (
              <div key={idx} className="relative">
                <img
                  src={url}
                  alt={`Preview ${idx}`}
                  className="max-h-[100px] rounded-md object-contain"
                />
                <button
                  onClick={() => handleRemoveImage(idx)}
                  className="absolute top-0 right-0 bg-white p-1 rounded-full text-black"
                  type="button"
                >
                  <X size={16} className="cursor-pointer" />
                </button>
              </div>
            ))}
          </div>
        )}
        <textarea
          ref={textareaRef}
          value={textInput}
          onChange={(e) => {
            setTextInput(e.target.value);
            e.target.style.height = "auto";
            e.target.style.height = `${Math.min(e.target.scrollHeight, 150)}px`;
          }}
          onKeyDown={handleKeyDown}
          placeholder="Ask a question..."
          rows={1}
          className="w-full p-2 text-sm bg-white focus:outline-none resize-none overflow-hidden scrollbar-hide"
          style={{
            maxHeight: "150px",
            paddingTop: "0px",
            paddingBottom: "10px",
            overflowY: "scroll",
          }}
          disabled={!isSkillAvailable}
        ></textarea>
        <div className="flex justify-between items-center w-full mt-0.5">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePaperclipClick}
              disabled={!isSkillAvailable}
              className={`p-1 md:p-2 ${
                isSkillAvailable
                  ? "hover:text-gray-700 text-gray-500 cursor-pointer transition-transform duration-300 hover:rotate-180"
                  : "text-gray-300 cursor-not-allowed"
              } bg-transparent border-none focus:outline-none`}
              tabIndex={0}
              aria-label="Attach files"
            >
              <Paperclip size={16} />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".jpg,.jpeg,.png,image/jpeg,image/png"
              multiple
              onChange={handleFileChange}
              style={{ display: "none" }}
              disabled={!isSkillAvailable}
            />
          </div>
          {isAiResponding ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-900"></div>
          ) : (
            <button
              className={cn(
                "md:p-2 rounded-md transition duration-200 cursor-pointer",
                textInput.trim() || previewURLs.length > 0
                  ? "bg-[#1F36C7] text-white"
                  : "bg-blue-300 text-white cursor-not-allowed"
              )}
              onClick={handleSendClick}
              disabled={!textInput.trim() && previewURLs.length === 0}
              type="button"
              aria-label="Send"
            >
              <ArrowUp size={12} />
            </button>
          )}
        </div>
      </div>
      <p className="text-[10px] text-xs pb-2 pt-2 text-gray-500 text-center w-full">
        Please use with discretion and follow &nbsp;
        <Dialog>
          <DialogTrigger asChild>
            <span className="underline cursor-pointer">usage terms</span>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[40%] bg-white font-unilever">
            <p className="flex justify-center text-md py-2 font-unilever-medium bg-gradient-to-t from-[#1F36C7] to-[#697DFF] bg-clip-text text-transparent ">
              Usage Terms
            </p>
            <hr style={{ border: "0.1px solid #DCDCDC" }} className="my-1" />
            <p className="font-unilever-medium text-sm mt-2">
              Points to remember when using the tool:
            </p>
            <div className="flex flex-col gap-2 mt-2">
              <div className="flex gap-2 mb-2 items-center">
                <img
                  src={AI_BRAIN}
                  alt="AI Brain"
                  className="w-[25px] h-[25px]"
                />
                <p className="text-[12px]">
                  Inputs may{" "}
                  <span className="font-medium">not be fully up to date</span>{" "}
                  and the tool might{" "}
                  <span className="font-medium">'hallucinate'</span> facts or
                  even sources, so independently fact-check Outputs.
                </p>
              </div>
              <div className="flex gap-2 mb-2 items-center">
                <img
                  src={COPY_RIGHT}
                  alt="Copyright"
                  className="w-[25px] h-[25px]"
                />
                <p className="text-[12px]">
                  Outputs may be subject to third party rights (such as
                  copyright), meaning that you should{" "}
                  <span className="font-medium">
                    use the Output as stimulus only.
                  </span>{" "}
                  use the Output as stimulus only.
                </p>
              </div>
              <div className="flex gap-2 mb-2 items-center">
                <img src={GROUP} alt="Group" className="w-[25px] h-[25px] " />
                <p className="text-[12px]">
                  <span className="font-medium">Do not prompt</span> the tool
                  with{" "}
                  <span className="underline text-[#697DFF] font-medium">
                    Personal Data
                  </span>{" "}
                  (e.g. a photo, name, email address etc of a living person) or{" "}
                  <span className="font-medium">
                    third-party data/materials
                  </span>{" "}
                  (e.g. data we licence from our insight providers like
                  Euromonitor, Kantar, retailer media partners, etc.).
                </p>
              </div>
            </div>
            <div className="bg-[#F3F8FF] p-3 mt-4">
              <p className="font-unilever-medium text-xs">Need Help?</p>
              <p className="text-xs mt-2">
                Contact your local Data{" "}
                <span className="underline text-[#697DFF]">
                  Protection Officer
                </span>{" "}
                /{" "}
                <span className="underline text-[#697DFF]">legal business</span>{" "}
                partner if your use case involves doing any of the above.
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </p>
    </div>
  );
};
