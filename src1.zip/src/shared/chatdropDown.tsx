import React, { useEffect, useState } from "react";
import { ChevronDown, Loader2, Search, Check } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { GradientBorderButton } from "@/components/ui/gradient-border-button";
import { cn } from "@/lib/utils";

interface DropdownItem {
  value: string;
  label: string;
}

interface DropdownSelectProps {
  title: string;
  items: DropdownItem[] | string[];
  searchPlaceholder?: string;
  groupTitle?: string;
  className?: string;
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  disableSearch?: boolean;
  isLoading?: boolean;
  disabled?: boolean;
}

export default function DropdownSelect({
  title,
  items,
  searchPlaceholder = "Search",
  className,
  defaultValue,
  value,
  onValueChange,
  disableSearch = false,
  isLoading = false,
  disabled = false,
}: DropdownSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedValue, setSelectedValue] = useState<string | undefined>(
    undefined
  );
  const [selectedLabel, setSelectedLabel] = useState("");
  const isTransparent = className?.includes("transparent");

  const normalizedItems = React.useMemo(() => {
    if (!items || items.length === 0) return [];
    if (typeof items[0] === "string") {
      return (items as string[]).map((item) => ({
        value: item,
        label: item,
      }));
    }
    return items as DropdownItem[];
  }, [items]);

  useEffect(() => {
    let currentLabel = title;
    let currentValue: string | undefined = undefined;

    const targetValue = value !== undefined ? value : defaultValue;

    if (targetValue !== undefined) {
      const matchingItem = normalizedItems.find(
        (item) => item.value === targetValue
      );
      if (matchingItem) {
        currentLabel = matchingItem.label;
        currentValue = matchingItem.value;
      } else if (value === undefined && defaultValue) {
        currentLabel = defaultValue;
      }
    }
    setSelectedLabel(currentLabel);
    setSelectedValue(currentValue);
  }, [defaultValue, title, value, normalizedItems]);

  const filteredItems = normalizedItems.filter((item) =>
    item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleItemSelect = (item: DropdownItem) => {
    if (isLoading || disabled) return;
    setSelectedValue(item.value);
    setSelectedLabel(item.label);
    setIsOpen(false);
    setSearchQuery("");
    if (onValueChange) {
      onValueChange(item.value);
    }
  };

  const effectiveDisabled = disabled || isLoading;

  return (
    <div className={cn("w-full", className)}>
      <DropdownMenu
        open={isOpen && !effectiveDisabled}
        onOpenChange={(openState) => {
          if (!effectiveDisabled) {
            setIsOpen(openState);
            if (!openState) setSearchQuery("");
          }
        }}
      >
        <DropdownMenuTrigger asChild disabled={effectiveDisabled}>
          {isTransparent ? (
            <div
              className={cn(
                "flex items-center justify-between text-gray-600 text-sm font-medium px-2 py-1 focus:ring-offset-0 bg-transparent w-full cursor-pointer",
                effectiveDisabled && "cursor-not-allowed opacity-70"
              )}
              aria-disabled={effectiveDisabled}
              role="button"
              tabIndex={effectiveDisabled ? -1 : 0}
            >
              <span className="text-[12px] text-gray-500 truncate font-unilever">
                {selectedLabel}
              </span>
              {isLoading ? (
                <Loader2 className="h-4 w-4 ml-1 animate-spin text-gray-500 flex-shrink-0" />
              ) : (
                <ChevronDown
                  className={cn(
                    "h-4 w-4 ml-1 transition-transform text-gray-500 flex-shrink-0",
                    isOpen && "rotate-180"
                  )}
                />
              )}
            </div>
          ) : (
            <GradientBorderButton
              isActive={isOpen && !effectiveDisabled}
              className={cn(
                "w-full cursor-pointer",
                effectiveDisabled && "cursor-not-allowed opacity-70"
              )}
              disabled={effectiveDisabled}
              aria-disabled={effectiveDisabled}
            >
              <span className="text-[12px] truncate font-unilever">
                {selectedLabel}
              </span>
              {isLoading ? (
                <Loader2 className="h-4 w-4 ml-2 animate-spin flex-shrink-0" />
              ) : (
                <ChevronDown
                  className={cn(
                    "h-4 w-4 ml-2 transition-transform flex-shrink-0",
                    isOpen && "rotate-180"
                  )}
                />
              )}
            </GradientBorderButton>
          )}
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="p-2 bg-white shadow-lg"
          align="center"
          style={{
            width: "100%",
            minWidth: "var(--radix-dropdown-menu-trigger-width)",
            border: "1.5px solid transparent",
            borderRadius: "8px",
            backgroundImage: `
              linear-gradient(white, white), 
              linear-gradient(to right, #FFC4D2, #9AF6F4)
            `,
            backgroundOrigin: "border-box",
            backgroundClip: "padding-box, border-box",
            boxSizing: "border-box",
          }}
        >
          {isLoading ? (
            <div className="flex items-center justify-center p-4 h-[100px]">
              <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
            </div>
          ) : (
            <div className="flex flex-col max-w-[230px]">
              {!disableSearch && (
                <div className="mb-2">
                  <div className="relative">
                    <Search className="absolute left-0.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-600" />
                    <input
                      type="text"
                      placeholder={searchPlaceholder}
                      className="pl-5.5 h-7 text-xs !outline-none !border-b w-full"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      autoFocus
                    />
                  </div>
                </div>
              )}
              <div
                className={cn(
                  "space-y-0.5 w-full",
                  !disableSearch &&
                    "max-h-[180px] overflow-y-auto custom-scrollbar scrollbar-thin"
                )}
              >
                {filteredItems.length > 0 ? (
                  filteredItems.map((item) => {
                    const isSelected = item.value === selectedValue;
                    return (
                      <DropdownMenuItem
                        key={item.value}
                        className={cn(
                          "cursor-pointer p-1.5 text-[12px] font-unilever hover:bg-gray-100 rounded focus:bg-blue-50 focus:text-blue-700 w-full flex items-center justify-between", // Added items-center and justify-between
                          isSelected && "bg-blue-50 text-blue-700 font-medium"
                        )}
                        onClick={() => handleItemSelect(item)}
                        textValue={item.label}
                      >
                        <span className="truncate flex-grow">{item.label}</span>
                        {isSelected && (
                          <Check className="h-4 w-4 ml-2 text-blue-700 flex-shrink-0" />
                        )}
                      </DropdownMenuItem>
                    );
                  })
                ) : (
                  <div className="text-xs text-gray-400 text-center py-3 px-1 font-unilever">
                    {searchQuery ? "No results found." : "No items available."}
                  </div>
                )}
              </div>
            </div>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
