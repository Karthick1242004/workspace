import React, { useEffect, useState } from "react"
import { ChevronDown } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { GradientBorderButton } from "@/components/ui/gradient-border-button"
import { cn } from "@/lib/utils"

interface DropdownItem {
  value: string;
  label: string;
}

interface DropdownSelectProps {
  title: string;
  items: DropdownItem[] | string[];
  searchPlaceholder?: string;
  groupTitle?: string;
  className?: string;
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  disableSearch?: boolean;
}

export default function DropdownSelect({
  title,
  items,
  searchPlaceholder = "Search",
  groupTitle = "Workspaces",
  className,
  defaultValue,
  value,
  onValueChange,
  disableSearch = false,
}: DropdownSelectProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedValue, setSelectedValue] = useState("")
  const [selectedLabel, setSelectedLabel] = useState("")
  const isTransparent = className?.includes("transparent")
  
  // Normalize items to always have value/label structure
  const normalizedItems = React.useMemo(() => {
    if (items.length === 0) return [];
    
    if (typeof items[0] === 'string') {
      return (items as string[]).map(item => ({
        value: item,
        label: item
      }));
    }
    
    return items as DropdownItem[];
  }, [items]);

  // Initialize value with defaultValue or title
  useEffect(() => {
    if (value !== undefined) {
      const matchingItem = normalizedItems.find(item => item.value === value);
      if (matchingItem) {
        setSelectedValue(matchingItem.value);
        setSelectedLabel(matchingItem.label);
      }
    } else if (defaultValue) {
      const matchingItem = normalizedItems.find(item => item.value === defaultValue);
      if (matchingItem) {
        setSelectedValue(matchingItem.value);
        setSelectedLabel(matchingItem.label);
      } else {
        setSelectedValue(defaultValue);
        setSelectedLabel(defaultValue);
      }
    } else {
      setSelectedValue("");
      setSelectedLabel(title);
    }
  }, [defaultValue, title, value, normalizedItems]);

  // Filter items based on search query
  const filteredItems = normalizedItems.filter((item) =>
    item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Handle item selection
  const handleItemSelect = (item: DropdownItem) => {
    setSelectedValue(item.value);
    setSelectedLabel(item.label);
    setIsOpen(false);
    setSearchQuery("");

    if (onValueChange) {
      onValueChange(item.value);
    }
  };

  return (
    <div className={cn("w-full", className)}>
      <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
        <DropdownMenuTrigger asChild>
          {isTransparent ? (
            <button 
              className="flex items-center justify-between text-gray-600 text-sm font-medium px-2 py-1 focus:ring-offset-0 bg-transparent"
            >
              <span className="text-[12px] text-gray-500">{selectedLabel}</span>
              <ChevronDown className={`h-4 w-4 ml-1 transition-transform text-gray-500 ${isOpen ? "rotate-180" : ""}`} />
            </button>
          ) : (
            <GradientBorderButton isActive={isOpen} className="w-full">
              <span className="text-[12px]">{selectedLabel}</span>
              <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
            </GradientBorderButton>
          )}
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-[100%] p-2 bg-white" align="center"
          style={{
            border: "1.5px solid transparent",
            borderRadius: "8px",
            backgroundImage: `
              linear-gradient(white, white), 
              linear-gradient(to right, #FFC4D2, #9AF6F4)
            `,
            backgroundOrigin: "border-box",
            backgroundClip: "padding-box, border-box",
          }}>
          <div className="mb-1">
            
            {!disableSearch && (
              <>
              <p className="text-xs font-medium text-gray-600 font-unilever text-[12px] p-1">Recent {groupTitle}</p>
              
              <div className="relative mb-1 text-[12px]">
                <Input
                  type="text"
                  placeholder={searchPlaceholder}
                  className="pl-8 h-8 flex-1 text-[12px] border-0 outline-none font-unilever placeholder:text-[12px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  style={{ fontSize: '12px' }}
                />
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="absolute left-2.5 top-2 h-4 w-4 text-gray-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
              </>
            )}
            
            <div className="space-y-1">
              {filteredItems.length > 0 ? (
                filteredItems.map((item, index) => (
                  <DropdownMenuItem
                    key={index}
                    className="cursor-pointer p-1 text-[12px] font-unilever hover:bg-gray-50"
                    onClick={() => handleItemSelect(item)}
                  >
                    {item.label}
                  </DropdownMenuItem>
                ))
              ) : (
                <div className="text-xs text-gray-500 text-center font-unilever flex justify-center text-[12px]">
                  No results found.
                </div>
              )}
            </div>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}