import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import WorkSpace from "../../modules/workspace/workspace";
import { useWorkspaceStore, Workspace } from "@/@logic/workspaceStore";

export default function WorkspaceCategoryTabs() {
  const { workspaces = [] } = useWorkspaceStore();

  function groupWorkspaceByCategory(workspaces: Workspace[]) {
    const groupedWorkspaces: { [category: string]: Workspace[] } = {};
    if(!workspaces) return groupedWorkspaces;
    workspaces.forEach((workspace) => {
      const category = workspace.category;
      if (!groupedWorkspaces[category as string]) {
        groupedWorkspaces[category as string] = [];
      }
      groupedWorkspaces[category as string].push(workspace);
    });
    return groupedWorkspaces;
  }

  const data = groupWorkspaceByCategory(workspaces);


  return (
    <Tabs defaultValue="my-workspace" className="flex w-full h-full max-w-[1300px] mx-auto">
      <TabsList className="h-[36px] bg-white mt-3">
        <TabsTrigger value="my-workspace" className="cursor-pointer">My AI Workspace</TabsTrigger>
        {
          Object.keys(data).map((category) => {
            if(category.toLowerCase() === "private") return null;
            return <TabsTrigger key={category} value={category} className="cursor-pointer">
              {category}
            </TabsTrigger>
        })
        }
      </TabsList>
      <TabsContent value="my-workspace">
        {workspaces && <WorkSpace workspacesData={data["Private"]} isLoading={false} selectedCategory="Private"/>}
      </TabsContent>
      {
        Object.keys(data).map((category) => {
          if(category === "private") return null;
          return <TabsContent key={category} value={category}>
            {data[category] && <WorkSpace workspacesData={data[category]} isLoading={false} selectedCategory={category}/>}
          </TabsContent>
        })
      }
    </Tabs>
  );
}
