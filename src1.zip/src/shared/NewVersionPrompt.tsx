"use client";

import { Button } from "@/components/ui/button";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import { CloudDownload } from "lucide-react";

interface NewVersionPromptProps {
  open?: boolean;
}

export default function NewVersionPrompt({
  open = true,
}: NewVersionPromptProps) {
  return (
    <div className="min-h-screen bg-gray-500 flex items-center justify-center p-4">
      <Dialog open={open}>
        <DialogContent
          className="sm:max-w-md bg-white rounded-lg shadow-lg border-0 p-8 [&>button]:hidden"
          onPointerDownOutside={(e) => e.preventDefault()}
          onEscapeKeyDown={(e) => e.preventDefault()}
        >
          <DialogHeader className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <CloudDownload className="w-8 h-8 text-blue-600" />
            </div>
            <DialogTitle className="text-xl font-semibold text-gray-900 text-center font-unilever">
              New Update Available
            </DialogTitle>
            <DialogDescription className="text-gray-600 text-sm leading-relaxed text-center font-unilever">
              A new version of the application has been released. Please refresh
              to get the latest features and improvement
            </DialogDescription>
          </DialogHeader>

          <div className="border-t border-gray-200 my-4"></div>

          <div className="flex justify-center">
            <Button
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md text-sm font-medium font-unilever cursor-pointer"
              onClick={() => window.location.reload()}
            >
              Update and Reload
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
