import React, { useEffect, useState } from "react";
import { PowerBIEmbed } from "powerbi-client-react";
import { models } from "powerbi-client";
import { PBI_EMBED_URL } from "@/constant/pbi";
import { getPbiReportDetails } from "@/utils/getPbiAccessToken";
import { useLocation, useParams } from "react-router-dom";
import { useMsal } from "@azure/msal-react";
import { getPbiFilters, PBI_Role } from "./pbi-filter.utils";

const reportConfigSetting = {
  type: "report",
  embedUrl: "",
  accessToken: "",
  id: "",
  tokenType: models.TokenType.Aad,
  filters: [],
  settings: {
    panes: {
      filters: {
        expanded: false,
        visible: false,
      },
    },
    navContentPaneEnabled: false,
    background: models.BackgroundType.Default,
    zoomLevel: 0.78,
  },
};

const PbiEmbed = () => {
  const { workspaceId, skillId } = useParams();
  const { accounts } = useMsal();
  const account = accounts[0];
  const isSuperAdmin =
    account?.idTokenClaims?.roles?.includes("MSB_SUPER_ADMINS");

  const location = useLocation();
  const skill_access_level = (location.state as any)?.accessLevel;
  const workspace_access = (location.state as any)?.workspaceAccessLevel;

  const [reportConfig, setReportConfig] = useState(reportConfigSetting);
  
  const accessLevelfunction = (): {url:string,role?:PBI_Role} => {
    if (isSuperAdmin) {
      return { "url": PBI_EMBED_URL.SUPER_ADMIN.URL, role: PBI_EMBED_URL.SUPER_ADMIN.ROLE as PBI_Role};
    } else if (
      PBI_EMBED_URL.WORKSPACE_ADMIN.ACCESS_LEVEL.includes(workspace_access)
    ) {
      return { "url": PBI_EMBED_URL.WORKSPACE_ADMIN.URL, role: PBI_EMBED_URL.WORKSPACE_ADMIN.ROLE as PBI_Role};
    } else if (PBI_EMBED_URL.SKILL_ADMIN.ACCESS_LEVEL.includes(skill_access_level)) {
      return { "url": PBI_EMBED_URL.SKILL_ADMIN.URL, role: PBI_EMBED_URL.SKILL_ADMIN.ROLE as PBI_Role};
    }
    return {url:''}
  };

  useEffect(() => {
    (async () => {
      try {
        const { url, role } = accessLevelfunction();

        const filters = getPbiFilters(Number(workspaceId), Number(skillId), role);
        
        const reportId = url?.split("/")[6];

        const response = await getPbiReportDetails(reportId || "");

        if (response) {
          setReportConfig({
            ...reportConfig,
            embedUrl: response.embedUrl,
            id: response.id,
            accessToken: response.token,
            filters: filters as any,
          });
        }
      } catch (error) {
        console.error("Failed to get PBI access token:", error);
      }
    })();
  }, []);

  return reportConfig.embedUrl ? (
    <PowerBIEmbed
      key={reportConfig.id}
      embedConfig={reportConfig}
      cssClassName="power-bi-report-class w-[100%] h-full bg-white"
    />
  ) : null;
};

export default PbiEmbed;
