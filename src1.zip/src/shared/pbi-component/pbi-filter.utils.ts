import { models } from "powerbi-client";
export type PBI_Role = "SUPER_ADMIN" | "WORKSPACE_ADMIN" | "SKILL_ADMIN";

const generatePBIFilterObject = (table_name:string,column_name:string,filter_value:number) => {
  return {
        $schema: "http://powerbi.com/product/schema#basic",
        target: {
          table: table_name,
          column: column_name,
        },
        operator: "In",
        values: [filter_value],
        filterType: models.FilterType.Basic,
        // requireSingleSelection: true
  }
}

export const getPbiFilters = (
  currentWorkspaceId: number,
  skillId: number,
  roles?: PBI_Role
) => {
  if (roles === "SUPER_ADMIN") {
    if(currentWorkspaceId && skillId) return [
        generatePBIFilterObject('Telemetry','WorkspaceId',currentWorkspaceId),
        generatePBIFilterObject('Telemetry','SkillId',skillId)
      ];
    if(currentWorkspaceId) return [
      generatePBIFilterObject('Telemetry','WorkspaceId',currentWorkspaceId)
    ];
  } else if (roles === "WORKSPACE_ADMIN") {
    return [
      generatePBIFilterObject('Telemetry','WorkspaceId',currentWorkspaceId)
    ];
  } else if (roles === "SKILL_ADMIN") {
    return [
      generatePBIFilterObject('Telemetry','WorkspaceId',currentWorkspaceId),
      generatePBIFilterObject('Telemetry','SkillId',skillId)
    ];
  }
  return []
};
