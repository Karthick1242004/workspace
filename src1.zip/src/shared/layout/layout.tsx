import React, { Suspense, useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import SideBar from "@/shared/sidebar/sidebar";
import { useFetchHandler } from "@/@logic/getHandlers";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { useUsageLogger } from "@/utils/usageLogger";
import { usageLoggerConstants } from "@/constant/usageLogger";
import UsageTerms from "../UsageTerms";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

export default function Layout() {
  const setIsLoading = useWorkspaceStore((state) => state.setIsLoading);
  const [dialogOpen, setDialogOpen] = useState(true);
  const location = useLocation();
  const usageLogger = useUsageLogger();
  const { data: userStatus } = useFetchHandler("access-control/check-user", "check-user");
  const { data: workspacesData, isLoading } = useFetchHandler(
    "workspaces/?userId=1",
    "workspace"
  );
  useEffect(() => {
    setIsLoading(isLoading);
  }, [isLoading]);

  const { setWorkspaces } = useWorkspaceStore();
  useEffect(() => {
    if (workspacesData) {
      setWorkspaces(workspacesData);
    }
  }, [workspacesData]);
  
  useEffect(()=>{
    usageLogger(`${usageLoggerConstants.navigation.all} ${location.pathname}`)
  },[location.pathname])


  return (
    <div
      className="h-full p-1 xl:p-2 bg-cover bg-center flex gap-2"
      style={{
        background:
          "linear-gradient(134deg, rgba(146, 245, 243, 0.30) 0%, rgba(254, 162, 184, 0.30) 100%), #FFF",
      }}
    >
      <SideBar />
      <Suspense fallback={<div>Loading...</div>}>
        <Outlet />
        {userStatus === false &&
          <div>
            <Dialog open={dialogOpen}>
              <DialogContent className="sm:max-w-[500px] md:max-w-[600px] bg-white font-unilever p-6 rounded-lg shadow-xl">
                <UsageTerms isChat={false} setDialogOpen={setDialogOpen} />
              </DialogContent>
            </Dialog>
          </div>
        }
      </Suspense>
    </div>
  );
}