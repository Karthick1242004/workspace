import React, { Suspense, useEffect, useMemo, useState } from "react"
import { Outlet } from "react-router-dom"
import Topbar from "./Topbar"
import SideBar from "@/shared/sidebar/sidebar"
import { useFetchHandler } from "@/@logic/getHandlers";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import MSB_BG from "../../assets/images/MSB_Background.png"

export default function Layout() {
  const setIsLoading = useWorkspaceStore((state) => state.setIsLoading);
  const { data: workspacesData, isLoading } = useFetchHandler(
    "workspaces/?userId=1",
    "workspace"
  );
  useEffect(() => {
    setIsLoading(isLoading);
  }, [isLoading]);

  const { setWorkspaces } = useWorkspaceStore();
  useEffect(() => {
    if (workspacesData) {
      setWorkspaces(workspacesData);
    }
  }, [workspacesData]);

  return (
    <div
      className="p-2 bg-cover bg-center"
      style={{ backgroundImage: `url(${MSB_BG})` }}
    >
      <Topbar />
      <div className="flex flex-row gap-2">
        <SideBar />
        <Suspense fallback={<div>Loading...</div>}>
          <Outlet />
        </Suspense>
      </div>
    </div>
  )
}
