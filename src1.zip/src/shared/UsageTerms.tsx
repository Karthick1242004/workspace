import React, { useState } from "react";
import AI_BRAIN_SVG from "@/assets/images/AI-brain.svg";
import COPY_RIGHT_SVG from "@/assets/images/copyright.svg";
import GROUP_SVG from "@/assets/images/Group.svg";
import { Button } from "@/components/ui/button";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
interface usageTermsProp {
  isChat: boolean;
  setDialogOpen?: React.Dispatch<React.SetStateAction<boolean>>;
}

export default function UsageTerms({ isChat, setDialogOpen }: usageTermsProp) {
  const [accepted, setAccepted] = useState(false);
  const { mutate, isPending } = useMutateHandler({
    endUrl: "/access-control/create-user",
    method: HTTPMethod.POST,
  });
  const createUser = () => {
    const emptyObj = {
      name: "",
    };
    mutate(emptyObj);
    if (setDialogOpen) setDialogOpen(false);
  };

  return (
    <div>
      <p className="flex justify-center text-lg py-2 font-unilever-medium bg-gradient-to-t from-[#1F36C7] to-[#697DFF] bg-clip-text text-transparent ">
        Usage Terms
      </p>
      <hr style={{ borderTop: "1px solid #E5E7EB" }} className="my-3" />
      <p className="font-unilever-medium text-sm mt-2 mb-3 text-gray-700">
        Points to remember when using the tool:
      </p>
      <div className="flex flex-col gap-4 text-gray-600">
        <div className="flex gap-3 items-start">
          <img
            src={AI_BRAIN_SVG as string}
            alt="AI Brain"
            className="w-7 h-7 mt-0.5 flex-shrink-0"
          />
          <p className="text-xs leading-relaxed">
            Inputs may{" "}
            <span className="font-medium text-gray-800">
              not be fully up to date
            </span>{" "}
            and the tool might{" "}
            <span className="font-medium text-gray-800">'hallucinate'</span>{" "}
            facts or even sources, so independently fact-check Outputs.
          </p>
        </div>
        <div className="flex gap-3 items-start">
          <img
            src={COPY_RIGHT_SVG as string}
            alt="Copyright"
            className="w-7 h-7 mt-0.5 flex-shrink-0"
          />
          <p className="text-xs leading-relaxed">
            Outputs may be subject to third party rights (such as copyright),
            meaning that you should{" "}
            <span className="font-medium text-gray-800">
              use the Output as stimulus only.
            </span>
          </p>
        </div>
        <div className="flex gap-3 items-start">
          <img
            src={GROUP_SVG as string}
            alt="Group"
            className="w-7 h-7 mt-0.5 flex-shrink-0"
          />
          <p className="text-xs leading-relaxed">
            <span className="font-medium text-gray-800">Do not prompt</span> the
            tool with{" "}
            <span className="underline text-[#697DFF] font-medium hover:text-blue-700">
              Personal Data
            </span>{" "}
            (e.g. a photo, name, email address etc of a living person) or{" "}
            <span className="font-medium text-gray-800">
              third-party data/materials
            </span>{" "}
            (e.g. data we licence from our insight providers like Euromonitor,
            Kantar, retailer media partners, etc.).
          </p>
        </div>
      </div>
      <div className="bg-blue-50 p-4 rounded-md mt-6 border border-blue-200">
        <p className="font-unilever-medium text-xs text-blue-800">Need Help?</p>
        <p className="text-xs mt-1 text-blue-700">
          Contact your local Data{" "}
          <span className="underline text-[#697DFF] hover:text-blue-700 cursor-pointer">
            Protection Officer
          </span>{" "}
          /{" "}
          <span className="underline text-[#697DFF] hover:text-blue-700 cursor-pointer">
            legal business
          </span>{" "}
          partner if your use case involves doing any of the above.
        </p>
      </div>
      {isChat === true ? (
        <></>
      ) : (
        <>
          <div className="flex mt-4 flex-row text-xs gap-2 items-center">
            <input
              type="checkbox"
              checked={accepted}
              onChange={(e) => setAccepted(e.target.checked)}
              className="h-4 w-4 cursor-pointer"
            />
            <p className="w-full">
              I accept that I have read and understood how to use the tool
              responsibly
            </p>
          </div>
          <Button
            className="w-full cursor-pointer bg-blue-700 text-white p-2.5 mt-4 rounded-md active:bg-blue-800 text-xs"
            disabled={!accepted}
            onClick={createUser}
          >
            {isPending ? "Loading..." : "Continue"}
          </Button>
        </>
      )}
    </div>
  );
}
