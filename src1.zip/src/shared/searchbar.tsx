import React from 'react';
import SearchIcon from "@/assets/icons/search.svg";
import { Search } from 'lucide-react';

interface SearchBarProps extends React.InputHTMLAttributes<HTMLInputElement> {
 
}

export default function SearchBar({ value, onChange, placeholder }: SearchBarProps) {
  return (
    <div className="relative mb-2 mt-1">
      <div className="absolute inset-y-0 left-2 flex items-center pointer-events-none">
        <Search className="h-4 w-4 text-gray-800" />
      </div>
      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder || "Search..."}
        className="w-full pl-7 pr-3 py-1 text-[12px]  border-b-1 border-gray-300  focus:outline-none"
      />
    </div>
  );
}