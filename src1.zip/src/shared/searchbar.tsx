import React from 'react';
import SearchIcon from "@/assets/icons/search.svg";

interface SearchBarProps extends React.InputHTMLAttributes<HTMLInputElement> {
 
}

export default function SearchBar({ value, onChange, placeholder }: SearchBarProps) {
  return (
    <div className="relative mb-1">
      <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
        <img src={SearchIcon} alt="Search" className="h-4 w-4 text-gray-400" />
      </div>
      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder || "Search..."}
        className="w-full pl-10 pr-3 py-2 text-[12px] bg-gray-50 border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
      />
    </div>
  );
}