import { ENVIRONEMENTAL_VARS } from "@/env";

export const PBI_EMBED_URL = {
    SUPER_ADMIN: {
        URL: ENVIRONEMENTAL_VARS.PBI_URLS.SUPER_ADMIN,
        ROLE: 'SUPER_ADMIN'
    },
    WORKSPACE_ADMIN: {
        URL: ENVIRONEMENTAL_VARS.PBI_URLS.WORKSPACE_AMDIN,
        ACCESS_LEVEL: ['owner'],
        ROLE: 'WORKSPACE_ADMIN'
    },
    SKILL_ADMIN: {
        URL: ENVIRONEMENTAL_VARS.PBI_URLS.SKILL_ADMIN,
        ACCESS_LEVEL: ['owner','editor','viewer'],
        ROLE: 'SKILL_ADMIN'
    }
}