
export const usageLoggerConstants = {
    click: {
        workspace: 'Clicked the Workapce card',
        skill: 'Visited Skill info',
        switched_workspace:"Switched the Workspace",
        switched_skill:"Switched the Skill"
    },

    change: {
        
    },

    edit:{
        workspace: 'Edited the Workspace',
        skill: 'Edited the Skill',
        Persona: 'Edited the Persona',
        Category: 'Edited the Category'
    },
    delete:{
        workspace: 'Deleted the Workspace',
        skill: 'Deleted the Skill'
    },

    navigation: {
        all: 'Navigated to the page'
    }
}