export const rolePlay = [
    "Procurement Specialist",
    "Marketplace Specialist",
    "Financial Specialist",
  ];