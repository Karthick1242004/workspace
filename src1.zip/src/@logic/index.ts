export const requestHeaders = {
  // "Content-Type": "application/json",
};

export const baseURL = 'https://bpace-ai04-d-930708-webapi-05.azurewebsites.net/api/';

export enum HTTPMethod {
  POST = "POST",
  PUT = "PUT",
  DELETE = "DELETE"
}
