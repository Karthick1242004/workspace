import { ENVIRONEMENTAL_VARS } from "@/env";

export const requestHeaders = {
  // "Content-Type": "application/json",
};

export const baseURL = ENVIRONEMENTAL_VARS.VITE_API_BASE_URL;

export enum HTTPMethod {
  POST = "POST",
  PUT = "PUT",
  DELETE = "DELETE"
}
