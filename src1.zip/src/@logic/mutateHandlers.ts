import { useMutation } from "@tanstack/react-query";
import { HTTPMethod } from ".";
import { Workspace } from "./workspaceStore";
import axiosInstance from "../utils/axiosInstance";

// Define input parameters for the POST request
export interface PostRequestParams {
  endUrl: string;
  method: HTTPMethod;
  headers?: Record<string, string>;
  onSuccess?: ((data: any) => void) | ((data: any, variables: Payload) => void);
  payload?: Payload;
  onError?: (error: any) => void;
}
export type Payload =  { [key: string]: string | number | boolean | null | File[] }
  | Workspace
  | FormData
/**
 * Custom hook that returns a mutation handler to perform a POST fetch operation using Tanstack Query.
 * It accepts a URL, payload, and headers, then performs the fetch asynchronously with error handling.
 */
export const useMutateHandler = ({
  endUrl,
  method,
  onSuccess,
  onError,
}: PostRequestParams) => {
  const mutation = useMutation({
    // Unique key for this mutation
    mutationKey: [method, endUrl],

    // Use axiosInstance instead of fetch
    mutationFn: async (payload: Payload) => {
      try {
        const isFormData = payload instanceof FormData;
        const response = await axiosInstance({
          url: endUrl,
          method,
          data: payload,
          headers: isFormData ? {} : { "Content-Type": "application/json" },
          // headers: { "Content-Type": "application/json" }, // You can pass additional headers here
        });
        return response.data;
      } catch (error) {
        console.error("POST request failed:", error);
        throw error;
      }
    },

    // Handle success
    onSuccess: (data, variables) => {
      // For frontend usage, you can update a global store here if needed.
      if (!onSuccess) return;

      if (onSuccess.length === 2) {
        (onSuccess as (data: any, variables: Payload) => void)(data, variables);
      } else {
        (onSuccess as (data: any) => void)(data);
      }
    },
    // onError: Handle errors during the POST request
    onError: (error: Error) => {
      console.error("POST request failed:", error);
      if(onError){
        onError(error);
      }
    },
  });

  return mutation;
};
