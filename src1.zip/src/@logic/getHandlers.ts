import { useQuery } from "@tanstack/react-query";
import axiosInstance from "../utils/axiosInstance";

/**
 * Custom hook to handle GET requests (including images) using Tanstack Query with Axios.
 *
 * @param endUrl - The API endpoint to fetch data from.
 * @param key - Optional query key for caching.
 * @param enabled - Whether the query should be enabled.
 * @param isImage - Whether to expect an image (blob) response. Default: false (json)
 * @returns A query object containing the fetched data, error, and loading state.
 */
export const useFetchHandler = (
  endUrl: string,
  key?: string | string[],
  enabled: boolean = true,
  isImage: boolean = false,
  refetchOnMount: boolean = false,
  retryCount: number = 2
) => { 
  
  return useQuery({
    enabled: !!endUrl && !!enabled,
    queryKey: [key, endUrl, isImage],
    queryFn: async () => {
      if (!endUrl) return;
      try {
        const config = isImage
          ? { responseType: 'blob' as const }
          : undefined;
        const response = await axiosInstance.get(endUrl, config);
        if(isImage) {
          return response.data;
        }
        return response.data.data;
      } catch (error) {
        console.error("Error in Fetch Handler:", error);
        throw error;
      }
    },
    retry: retryCount,
    staleTime: refetchOnMount ? 0 : 5 * 60 * 1000,
    refetchOnMount: refetchOnMount,
  });
};