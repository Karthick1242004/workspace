import { create } from "zustand";
import { ProcessingStatus } from "../modules/workspace/workspace-details"; 

interface Audit {
  created_at?: string;
  updated_at?: string;
}

export interface Persona {
  id: number;
  name: string;
}

export interface Skill extends Audit {
  is_favorited: boolean;
  logo: string | undefined;
  id: number;
  name: string;
  domain: string;
  description: string;
  processing_status: ProcessingStatus;
  is_processed_for_rag: boolean;
  workspace?: string | number;
  updated_at?: string;
  questions: string;
  chat_sessions_count: number;
  created_by: string;
  access_level: string;
  ai_model: {
    id: number;
    name: string;
  }
}
export interface Workspace extends Audit {
  is_favorited: boolean;
  id: number;
  name: string;
  description?: string;
  category?: string;
  icc?: string;
  cost_center?: string;
  responsible_wl3?: string;
  skills: Skill[];
  personas?: Persona[];
  created_by: string;
  created_by_me: boolean;
  access_level: string;
}

interface WorkspaceStore {
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  workspaces: Workspace[];
  getWorkspaces: () => Workspace[];
  selectedWorkspaceId: number | null; 
  setSelectedWorkspaceId: (workspaceId: number | null) => void;
  selectedSkillId: number | null; 
  setSelectedSkillId: (skillId: number | null) => void;
  setWorkspaces: (workspaces: Workspace[]) => void;
  addWorkspace: (workspace: Workspace) => void;
  updateWorkspace: (workspace: Workspace) => void;
  clearWorkspaces: () => void;
  updateSkillStatus: (
    skillId: number,
    processing_status: ProcessingStatus,
    is_processed_for_rag: boolean,
    last_modified: string,
  ) => void;
  removeSkill: (skillId: number) => void;
  getCurrentSkillOptions: () => { value: number; label: string; questions: string; id: number }[];
  getSelectedSkill: () => Skill | undefined;
  getAiModelOptions: () => { value: number; label: string }[];
  favoriteWorkspace: (workSpaceId:number,fav:boolean) => void;
  favoriteSkill: (SKillId:number,fav:boolean) => void;
  deleteWorkspace: (workSpaceId:number) => void;
  deleteSkill: (workSpaceId:number) => void;
}

export const useWorkspaceStore = create<WorkspaceStore>((set, get) => ({
  workspaces: [],
  isLoading: false,
  setIsLoading: (loading: boolean) => set({ isLoading: loading }),
  selectedWorkspaceId: null,
  setSelectedWorkspaceId: (workspaceId: number | null) =>
    set({
      selectedWorkspaceId: workspaceId,
      selectedSkillId: null,
    }),
  selectedSkillId: null,
  setSelectedSkillId: (skillId: number | null) =>
    set({ selectedSkillId: skillId }),
  setWorkspaces: (workspaces: Workspace[]) => set({ workspaces }),
  getWorkspaces: () => get().workspaces,
  addWorkspace: (workspace: Workspace) =>
    set((state: WorkspaceStore) => ({
      workspaces: [...state.workspaces, workspace],
    })),
  updateWorkspace: (workspace: Workspace) =>
    set((state: WorkspaceStore) => ({
      workspaces: state.workspaces.map((w) =>
        w.id === workspace.id ? { ...w, ...workspace } : w,
      ),
    })),
  clearWorkspaces: () => set({ workspaces: [] }),
  updateSkillStatus: (
    skillId: number,
    processing_status: ProcessingStatus,
    is_processed_for_rag: boolean,
    last_modified: string,
  ) =>
    set((state: WorkspaceStore) => ({
      workspaces: state.workspaces.map((workspace) => ({
        ...workspace,
        skills: workspace.skills.map((skill) =>
          skill.id === skillId
            ? {
                ...skill,
                processing_status,
                is_processed_for_rag,
                updated_at: last_modified,
              }
            : skill,
        ),
      })),
    })),
  removeSkill: (skillId: number) =>
    set((state: WorkspaceStore) => ({
      workspaces: state.workspaces.map((workspace) => ({
        ...workspace,
        skills: workspace.skills.filter((skill) => skill.id !== skillId),
      })),
    })),
  getCurrentSkillOptions: () => {
    const { workspaces, selectedWorkspaceId } = get();
    if (!selectedWorkspaceId) return [];
    const selectedWs = workspaces.find((ws) => ws.id === selectedWorkspaceId);
    return selectedWs
      ? selectedWs.skills.map((s) => ({
          value: s.id,
          label: s.name,
          questions: s.questions,
          id: s.id,
        }))
      : [];
  },
  getSelectedSkill: () => {
    const { workspaces, selectedWorkspaceId, selectedSkillId } = get();
    if (!selectedWorkspaceId || !selectedSkillId) return undefined;
    const selectedWs = workspaces.find((ws) => ws.id === selectedWorkspaceId);
    return selectedWs?.skills.find((s) => s.id === selectedSkillId);
  },
  getAiModelOptions: () => {
    const { selectedSkillId } = get();
    if (!selectedSkillId) return [];
    const selectedSkill = get().getSelectedSkill();
    if (!selectedSkill) return [];
    return selectedSkill.ai_model
      ? [{ value: selectedSkill.ai_model.id, label: selectedSkill.ai_model.name }]
      : [];
  },

  favoriteWorkspace: (workSpaceId: number,fav:boolean) =>
    set((state: WorkspaceStore) => ({
      workspaces: state.workspaces.map((workspace) => {
        if (workspace.id === workSpaceId) return { ...workspace, is_favorited: fav }
        return workspace
      })
    })),

  favoriteSkill: (skillId: number,fav:boolean) =>
    set((state: WorkspaceStore) => ({
      workspaces: state.workspaces.map((workspace) => ({
        ...workspace,
        skills: workspace.skills.map((skill) => {
          if (skill.id !== skillId) return { ...skill, is_favorited:fav }
          return skill
        }
        ),
      })),
    })),

  deleteWorkspace: (workSpaceId: number) =>
    set((state: WorkspaceStore) => ({
      workspaces: state.workspaces.filter((workspace) => workspace.id !== workSpaceId)
    })),

  deleteSkill: (skillId: number) =>
    set((state: WorkspaceStore) => ({
      workspaces: state.workspaces.map((workspace) => ({
        ...workspace,
        skills: workspace.skills.filter((skill) => skill.id !== skillId),
      })),
    })),

}));