import React from "react"
import { cn } from "@/lib/utils"

interface GradientBorderButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    isActive?: boolean
    children: React.ReactNode
}

export const GradientBorderButton = React.forwardRef<HTMLButtonElement, GradientBorderButtonProps>(
    ({ className, isActive = false, children, ...props }, ref) => {
        return (
            <button
                ref={ref}
                className={cn(
                    "relative flex items-center justify-between rounded-md px-3 py-2 text-sm font-medium text-gray-600 transition-all",
                    className
                )}
                style={{
                    border: "1px solid transparent",
                    borderRadius: "8px",
                    backgroundImage: isActive
                        ? `linear-gradient(white, white), linear-gradient(to right, #FFC4D2, #9AF6F4)`
                        : `linear-gradient(#F0EEF3, #F0EEF3), linear-gradient(to right, #FFC4D2, #9AF6F4)`,
                    backgroundOrigin: "border-box",
                    backgroundClip: "padding-box, border-box",
                }}
                onMouseOver={(e) => {
                    if (!isActive) {
                        e.currentTarget.style.backgroundImage = `linear-gradient(white, white), linear-gradient(to right, #FFC4D2, #9AF6F4)`;
                    }
                }}
                onMouseOut={(e) => {
                    if (!isActive) {
                        e.currentTarget.style.backgroundImage = `linear-gradient(#F0EEF3, #F0EEF3), linear-gradient(to right, #FFC4D2, #9AF6F4)`;
                    }
                }}
                {...props}
            >
                {children}
            </button>
        )
    }
)
