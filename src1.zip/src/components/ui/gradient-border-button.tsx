import React from "react";
import { cn } from "@/lib/utils";

interface GradientBorderButtonProps
  extends React.HTMLAttributes<HTMLDivElement> {
  isActive?: boolean;
  children: React.ReactNode;
  disabled?: boolean;
}

export const GradientBorderButton = React.forwardRef<
  HTMLDivElement,
  GradientBorderButtonProps
>(
  (
    {
      className,
      isActive = false,
      disabled = false,
      children,
      onClick,
      onMouseOver,
      onMouseOut,
      onKeyDown,
      ...props
    },
    ref
  ) => {
    const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
      if (disabled) return;
      onClick?.(e);
    };

    const handleMouseOver = (e: React.MouseEvent<HTMLDivElement>) => {
      if (disabled) return;
      if (!isActive) {
        e.currentTarget.style.backgroundImage = `linear-gradient(white, white), linear-gradient(to right, #FFC4D2, #9AF6F4)`;
      }
      onMouseOver?.(e);
    };

    const handleMouseOut = (e: React.MouseEvent<HTMLDivElement>) => {
      if (disabled) return;
      if (!isActive) {
        e.currentTarget.style.backgroundImage = `linear-gradient(#F0EEF3, #F0EEF3), linear-gradient(to right, #FFC4D2, #9AF6F4)`;
      }
      onMouseOut?.(e);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (disabled) return;
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        handleClick(e as any);
      }
      onKeyDown?.(e);
    };

    return (
      <div
        ref={ref}
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-disabled={disabled}
        className={cn(
          "relative flex items-center justify-between rounded-md px-3 py-2 text-sm font-medium text-gray-600 transition-all",
          disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer",
          className
        )}
        style={{
          border: "1px solid transparent",
          borderRadius: "4px",
          backgroundImage: isActive
            ? `linear-gradient(white, white), linear-gradient(to right, #FFC4D2, #9AF6F4)`
            : `linear-gradient(#F0EEF3, #F0EEF3), linear-gradient(to right, #FFC4D2, #9AF6F4)`,
          backgroundOrigin: "border-box",
          backgroundClip: "padding-box, border-box",
        }}
        onClick={handleClick}
        onMouseOver={handleMouseOver}
        onMouseOut={handleMouseOut}
        onKeyDown={handleKeyDown}
        {...props}
      >
        {children}
      </div>
    );
  }
);

GradientBorderButton.displayName = "GradientBorderButton";
