import React from "react"
import { cn } from "@/lib/utils"

function Skeleton({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-gray-200 flex items-center justify-center", className)}
      {...props}
    >
            {children}
      </div>
  )
}

export { Skeleton } 