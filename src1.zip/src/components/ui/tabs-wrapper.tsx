import React from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

interface TabOption {
  label: string;
  value: string;
}

interface TabsWrapperProps {
  tabs: TabOption[];
  value: string; 
  onValueChange: (value: string) => void;
  className?: string;
}

const TabsWrapper: React.FC<TabsWrapperProps> = ({
  tabs,
  value,
  onValueChange,
  className,
}) => {
  return (
    <Tabs value={value} onValueChange={onValueChange} className={cn(className)}>
      <div className="flex items-center justify-between">
        <TabsList className="bg-white">
          {tabs.map((tab) => (
            <TabsTrigger key={tab.value} value={tab.value} className="mx-1 cursor-pointer">
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>
        
      </div>
    </Tabs>
  );
};

export default TabsWrapper;