import PbiEmbed from '@/shared/pbi-component/PbiEmbed'
import React from 'react'

const Analytics = () => {
    return (
        <div className='max-w-[var(--max-content-width)] mx-auto  w-[100%] bg-white/60 rounded-xl'>
            <PbiEmbed />
        </div>
    )
}

export default Analytics