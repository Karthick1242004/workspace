import React, { useEffect, useRef, useState, useCallback } from "react";
import { useChatSessionStore } from "../store/chatSessionStore";
import { useChatOperations } from "../hooks/chatOperations";
import { ArrowDownCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import ChatMessage from "../model/ChatMessage";
import ChatMessageBubble from "./ChatMessageBubble";

interface ChatMessagesProps {
  avatar?: string;
  name?: string;
  scrollableContainerRef: React.RefObject<HTMLDivElement | null>;
}

const ChatMessages: React.FC<ChatMessagesProps> = ({
  avatar,
  name,
  scrollableContainerRef,
}) => {
  const {
    messages,
    editingMessageId,
    setEditingMessageId,
    copiedMessageId,
    setCopiedMessageId,
  } = useChatSessionStore();

  const {
    handleRegenerateResponse,
    handleSaveEditedMessage,
    handleSubmitFeedback,
  } = useChatOperations();

  const [editedText, setEditedText] = useState("");
  const [showScrollToBottomButton, setShowScrollToBottomButton] =
    useState(false);
  const thinkingText = "Thinking...";

  const endOfMessagesRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = "smooth") => {
    endOfMessagesRef.current?.scrollIntoView({ behavior });
  }, []);

  useEffect(() => {
    const container = scrollableContainerRef.current;
    if (!container) return;
    const isNearBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight < 150;
  
    if (isNearBottom) {
      const timeout = setTimeout(() => {
        scrollToBottom("smooth");
      }, 50);
      return () => clearTimeout(timeout);
    }
  }, [messages, scrollToBottom]);
  
  useEffect(() => {
    const container = scrollableContainerRef.current;

    const handleScroll = () => {
      if (container) {
        const { scrollTop, scrollHeight, clientHeight } = container;
        const isScrolledUp = scrollHeight - scrollTop > clientHeight + 300;
        setShowScrollToBottomButton(isScrolledUp);
      }
    };

    if (container) {
      container.addEventListener("scroll", handleScroll);
      handleScroll();
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, [scrollableContainerRef]);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea && editingMessageId !== null) {
      textarea.style.height = "auto";
      const scrollHeight = textarea.scrollHeight;
      textarea.style.height = `${Math.min(scrollHeight, 150)}px`;
    }
  }, [editedText, editingMessageId]);

  const handleStartEdit = (msg: ChatMessage) => {
    setEditingMessageId(msg.id);
    setEditedText(msg.message);
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditedText("");
  };

  const onSaveEdit = (originalMessage: ChatMessage) => {
    handleSaveEditedMessage(originalMessage, editedText);
  };

  return (
    <>
      <div className="flex flex-col gap-2 w-full max-w-[var(--chat-content-width)] mx-auto px-2 md:px-0">
        {messages.map((msg) => (
          <ChatMessageBubble
            key={msg.id}
            msg={msg}
            avatar={avatar}
            userName={name}
            editingId={editingMessageId}
            copiedId={copiedMessageId}
            editedText={editedText}
            thinkingText={thinkingText}
            textareaRef={textareaRef}
            onStartEdit={() => handleStartEdit(msg)}
            onSaveEdit={() => onSaveEdit(msg)}
            onCancelEdit={handleCancelEdit}
            onEditText={setEditedText}
            setCopiedMessageId={setCopiedMessageId}
            onFeedback={(message, isGood) =>
              handleSubmitFeedback(message, isGood)
            }
            onRegenerate={(messageToRegen, modelId) => {
              handleRegenerateResponse(messageToRegen, modelId);
            }}
          />
        ))}
        <div ref={endOfMessagesRef} />
      </div>

      {showScrollToBottomButton && (
        <button
          onClick={() => scrollToBottom("smooth")}
          className={cn(
            "fixed bottom-24 md:bottom-28 right-4 md:right-8 z-20 cursor-pointer",
            "p-2.5 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-all duration-300",
            "focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2",
            "animate-fade-in"
          )}
          aria-label="Scroll to bottom"
        >
          <ArrowDownCircle size={22} />
        </button>
      )}
    </>
  );
};

export default ChatMessages;