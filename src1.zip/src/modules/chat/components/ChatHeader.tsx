import React from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import DropdownSelect from "@/shared/chatdropDown";

interface ChatHeaderProps {
  workspaces: { value: string; label: string }[];
  workspaceId?: number;
  isLoadingWorkspaces: boolean;
  onWorkspaceChange: (id: number) => void;
  skillOptions: { value: string; label: string }[];
  skillId?: number;
  onSkillChange: (id: number) => void;
  gptModels: { value: number; label: string }[];
  selectedModel: number | null;
  setSelectedModel: (value: number) => void;
  isLoadingModels: boolean;
  rolePlayItems: { value: string; label: string }[];
  selectedRole: string;
  setSelectedRole: (value: string) => void;
  chatTitle: string;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({
  workspaces,
  workspaceId,
  isLoadingWorkspaces,
  onWorkspaceChange,
  skillOptions,
  skillId,
  onSkillChange,
  gptModels,
  selectedModel,
  setSelectedModel,
  isLoadingModels,
  rolePlayItems,
  selectedRole,
  setSelectedRole,
  chatTitle,
}) => {
  const workspaceExists = workspaces.some(
    (w) => w.value === String(workspaceId)
  );
  const skillExists = skillOptions.some((s) => s.value === String(skillId));
  const modelExists = gptModels.some((m) => m.value === selectedModel);
  const roleExists = rolePlayItems.some((r) => r.value === selectedRole);

  return (
    <div className="flex items-center justify-between flex-wrap gap-2 w-full px-4 py-2">
      <div className="flex items-center">
        {/* Workspace Select */}
        <Tooltip>
          <TooltipTrigger>
            <DropdownSelect
              title="Workspace"
              items={workspaces}
              searchPlaceholder="Search workspaces"
              groupTitle="Workspaces"
              defaultValue={
                workspaceId && workspaceExists ? String(workspaceId) : undefined
              }
              onValueChange={(value: string) =>
                onWorkspaceChange(Number(value))
              }
              isLoading={isLoadingWorkspaces}
              className="max-w-[150px] transparent text-sm"
            />
          </TooltipTrigger>
          <TooltipContent
            side="bottom"
            sideOffset={4}
            className="font-unilever"
            disableArrow
          >
            <p>Workspace</p>
          </TooltipContent>
        </Tooltip>

        <div className="px-2 text-gray-400">/</div>

        {/* Skill Select */}
        <Tooltip>
          <TooltipTrigger>
            <DropdownSelect
              title="Skill"
              items={skillOptions}
              searchPlaceholder="Search skills"
              groupTitle="Skills"
              defaultValue={
                skillId && skillExists ? String(skillId) : undefined
              }
              onValueChange={(value: string) => onSkillChange(Number(value))}
              isLoading={isLoadingWorkspaces}
              className="max-w-[150px] transparent text-sm"
              disabled={!workspaceId || skillOptions.length === 0} // Disable if no workspace or no skills
            />
          </TooltipTrigger>
          <TooltipContent
            side="bottom"
            sideOffset={4}
            className="font-unilever"
            disableArrow
          >
            <p>Skill</p>
          </TooltipContent>
        </Tooltip>

        <div className="px-2 text-gray-400">/</div>

        {/* Chat Title */}
        <Tooltip>
          <TooltipTrigger>
            <div className="text-xs font-medium bg-gradient-to-b from-blue-300 via-blue-700 to-blue-900 bg-clip-text text-transparent truncate max-w-[200px] font-unilever">
              {chatTitle}
            </div>
          </TooltipTrigger>
          <TooltipContent
            side="bottom"
            sideOffset={4}
            className="font-unilever"
            disableArrow
          >
            <p>Current Chat</p>
          </TooltipContent>
        </Tooltip>
      </div>

      <div className="flex gap-3 items-center">
        {/* Persona */}
        <Tooltip>
          <TooltipTrigger>
            <DropdownSelect
              key={`role-${selectedRole}`}
              title="Persona"
              items={rolePlayItems}
              searchPlaceholder="Search Persona"
              groupTitle="Persona"
              defaultValue={
                selectedRole && roleExists ? selectedRole : undefined
              }
              onValueChange={setSelectedRole}
              disableSearch={true}
              className="max-w-[150px] text-sm"
            />
          </TooltipTrigger>
          <TooltipContent
            side="bottom"
            sideOffset={4}
            className="font-unilever"
            disableArrow
          >
            <p>Persona</p>
          </TooltipContent>
        </Tooltip>

        {/* Model */}
        <Tooltip>
          <TooltipTrigger>
            <DropdownSelect
              key={`model-${selectedModel}`}
              title="Model"
              items={gptModels.map((m) => ({
                value: String(m.value),
                label: m.label,
              }))}
              searchPlaceholder="Search Model"
              groupTitle="Model"
              defaultValue={
                selectedModel && modelExists ? String(selectedModel) : undefined
              }
              onValueChange={(value: string) => setSelectedModel(Number(value))}
              disableSearch={true}
              className="min-w-[120px] text-sm"
              isLoading={isLoadingModels}
            />
          </TooltipTrigger>
          <TooltipContent
            side="bottom"
            sideOffset={4}
            className="font-unilever"
            disableArrow
          >
            <p>Model</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </div>
  );
};

export default ChatHeader;
