import React from "react";
import ChatMessages from "./ChatMessages";
import NewChatSuggestion from "./NewChatSuggestion";
import { useChatSessionStore } from "../store/chatSessionStore";
import { ragStatusType } from "../Chat";

interface ChatBodyProps {
  scrollableContainerRef: React.RefObject<HTMLDivElement | null>;
  avatar?: string;
  ragStatus: ragStatusType
}

const ChatBody: React.FC<ChatBodyProps> = ({ scrollableContainerRef, avatar, ragStatus}) => {
  const { showWelcomeMessage } = useChatSessionStore();

  return showWelcomeMessage ? (
    <div className="flex flex-1 justify-center items-center overflow-auto w-full h-full">
      <NewChatSuggestion ragStatus={ragStatus} />
    </div>
  ) : (
    <ChatMessages avatar={avatar} scrollableContainerRef={scrollableContainerRef} />
  );
};

export default ChatBody;