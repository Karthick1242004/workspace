import React from "react";

interface GradientStrokeTextProps {
  text: string;
}

const GradientStrokeText: React.FC<GradientStrokeTextProps> = ({ text}) => {
  return (
    <svg
      viewBox="0 0 600 50"
    className="mt-10"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="strokeGradient" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#FF8CA8" />
          <stop offset="100%" stopColor="#41FFFB" />
        </linearGradient>
      </defs>

      <text
        x="50%"
        y="50%"
        textAnchor="middle"
        dominantBaseline="middle"
        stroke="url(#strokeGradient)"
        strokeWidth="0.5"
        fill="transparent"
        className="font-unilever-bold text-4xl"
      >
        {text}
      </text>
    </svg>
  );
};

export default GradientStrokeText;
