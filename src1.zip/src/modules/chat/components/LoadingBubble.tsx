import React from "react";

const LoadingBubble: React.FC<{ thinkingText: string }> = ({ thinkingText }) => (
  <div className="relative inline-block align-middle">
    <svg
      aria-hidden
      viewBox="0 0 100 32"
      width="100%"
      height="100%"
      style={{
        position: "absolute", top: 0, left: 0,
        width: "100%", height: "100%", zIndex: 0, pointerEvents: "none"
      }}
      preserveAspectRatio="none"
    >
      <rect x="0" y="0" width="100" height="32" rx="10" fill="transparent" />
    </svg>
    <div className="relative z-10 p-0 px-2 py-2">
      <div className="flex text-black tracking-[0.05rem] font-light ">
        {thinkingText.split("").map((letter, i) => (
          <span
            key={i}
            className="animate-fade text-[12px] font-unilever"
            style={{
              animationDelay: `${i * 0.1}s`,
            }}
          >
            {letter}
          </span>
        ))}
      </div>
    </div>
    <style>{`@keyframes fade { 0% { opacity: 1; } 100% { opacity: 0.2; } } .animate-fade {animation: fade 0.8s infinite alternate; display: inline-block;}`}</style>
  </div>
);

export default LoadingBubble;