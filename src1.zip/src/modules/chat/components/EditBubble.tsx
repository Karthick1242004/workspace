import React from "react";
import { Button } from "@/components/ui/button";

type EditBubbleProps = {
  textareaRef: React.RefObject<HTMLTextAreaElement | null>;
  value: string;
  onChange: (v: string) => void;
  onSave: () => void;
  onCancel: () => void;
};

const EditBubble: React.FC<EditBubbleProps> = ({
  textareaRef, value, onChange, onSave, onCancel
}) => (
  <div className="flex flex-col gap-2 overflow-hidden bg-[#EDF0FF] border border-[#d0d8ff] rounded-lg p-3 min-w-xl">
    <textarea
      ref={textareaRef}
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full text-xs p-2 border-none rounded-lg bg-[#EDF0FF] resize-none overflow-hidden focus:outline-none font-unilever"
      rows={1}
      style={{ maxHeight: "150px" }}
    />
    <div className="flex gap-2 justify-end ">
      <Button
        className="text-xs px-2 border border-[#D5D5D5] cursor-pointer"
        onClick={onCancel}
      >
        Cancel
      </Button>
      <Button
        className="text-xs px-2  bg-[#005EEE] text-white cursor-pointer"
        onClick={onSave}
      >
        Send
      </Button>
    </div>
  </div>
);

export default EditBubble;