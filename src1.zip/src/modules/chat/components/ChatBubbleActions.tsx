import React from "react";
import ChatMessage from "../model/ChatMessage";
import { UserMessageActions } from "./UserMessageActions";
import { AiMessageActions } from "./AiMessageActions";

interface ChatBubbleActionsProps {
  msg: ChatMessage;
  isAI: boolean;
  isUser: boolean;
  copiedId: number | null;
  editingId: number | null;
  onCopy: (text: string, type: "user" | "ai") => void;
  onEdit: (id: number, val: string) => void;
  onFeedback: (message: ChatMessage, isGood: boolean) => void;
  onRegenerate: (message: ChatMessage, newModelId?: number) => void;
}

const ChatBubbleActions: React.FC<ChatBubbleActionsProps> = ({
  msg,
  isAI,
  isUser,
  copiedId,
  editingId,
  onCopy,
  onEdit,
  onFeedback,
  onRegenerate,
}) => {
  if (editingId === msg.id) return null;

  if (isUser) {
    return (
      <UserMessageActions
        msg={msg}
        copiedId={copiedId}
        onCopy={onCopy}
        onEdit={onEdit}
      />
    );
  }

  if (isAI) {
    return (
      <AiMessageActions
        msg={msg}
        copiedId={copiedId}
        onCopy={onCopy}
        onFeedback={onFeedback}
        onRegenerate={onRegenerate}
      />
    );
  }

  return null;
};

export default ChatBubbleActions;
