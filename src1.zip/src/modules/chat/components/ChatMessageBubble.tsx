import React, { useRef } from "react";
import { Sparkle, Info, AlertTriangle } from "lucide-react";
import ChatBubbleActions from "./ChatBubbleActions";
import LoadingBubble from "./LoadingBubble";
import EditBubble from "./EditBubble";
import { ChatImageViewer } from "./ChatImageViewer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useMsal } from "@azure/msal-react";
import { MarkdownWrapper } from "./MarkdownWrapper";
import ChatMessage from "../model/ChatMessage";
import { cn } from "@/lib/utils";
import AllyLogo from "@/assets/icons/Allylogo.svg";
import AllyThinking from "@/assets/icons/ally_thinking.gif";

interface ChatMessageBubbleProps {
  msg: ChatMessage;
  avatar?: string;
  userName?: string;
  editingId: number | null;
  copiedId: number | null;
  editedText: string;
  thinkingText: string;
  textareaRef: React.RefObject<HTMLTextAreaElement | null>;
  setCopiedMessageId: (id: number | null) => void;
  onStartEdit: (id: number, text: string) => void;
  onSaveEdit: (msg: ChatMessage) => void;
  onCancelEdit: () => void;
  onEditText: (val: string) => void;
  onFeedback: (message: ChatMessage, isGood: boolean) => void;
  onRegenerate: (message: ChatMessage, modelId?: number) => void;
}

const ChatMessageBubble: React.FC<ChatMessageBubbleProps> = ({
  msg,
  avatar,
  userName,
  editingId,
  copiedId,
  editedText,
  thinkingText,
  textareaRef,
  onStartEdit,
  onSaveEdit,
  onCancelEdit,
  onEditText,
  setCopiedMessageId,
  onFeedback,
  onRegenerate,
}) => {
  const contentRef = useRef(null);

  const isAI = ["msb_admin", "ai", "bot"].includes(msg.role.toLowerCase());
  const isUser = msg.role.toLowerCase() === "user";

  const { accounts } = useMsal();

  const getInitials = (nameString?: string): string => {
    if (!nameString) return "?";
    const parts = nameString.split(", ");
    if (parts.length > 1 && parts[1]) return parts[1][0].toUpperCase();
    const nameParts = nameString.split(" ");
    if (nameParts.length > 0 && nameParts[0])
      return nameParts[0][0].toUpperCase();
    return nameString[0]?.toUpperCase() || "?";
  };

  const nameForAvatarFallback = getInitials(userName || accounts[0]?.name);

  const showActions =
    editingId !== msg.id && !(isAI && msg.isLoading) && !msg.error;

  const handleCopy = async (message: string, type: "user" | "ai") => {
    if (contentRef.current && type === "ai") {
      const shadowRoot = (contentRef.current as any).shadowRoot;
      const textContent = shadowRoot?.textContent || "";
      await navigator.clipboard.writeText(textContent);
      setCopiedMessageId(msg.id);
    } else {
      await navigator.clipboard.writeText(message);
      setCopiedMessageId(msg.id);
    }
  };

  return (
    <div
      className={`flex flex-1 gap-2 ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      {isAI && !msg.isLoading && <img src={AllyLogo} className="self-start" />}

      {isAI && msg.isLoading && (
        <img
          src={AllyThinking}
          className="self-start w-[35px] animate-bounce"
        />
      )}

      <div className="relative group">
        {editingId === msg.id ? (
          <EditBubble
            textareaRef={textareaRef}
            value={editedText}
            onChange={onEditText}
            onSave={() => onSaveEdit(msg)}
            onCancel={onCancelEdit}
          />
        ) : msg.isLoading ? (
          <LoadingBubble thinkingText={thinkingText} />
        ) : (
          <div
            className={cn(
              "border text-sm rounded-lg py-2 px-3 break-words font-unilever",
              isUser
                ? "bg-[#EDF0FF] text-gray-800"
                : "bg-white/60 text-gray-800"
            )}
            style={{
              border: isAI ? "1px solid #FFC4D2" : "1px solid #AFBAFF",
            }}
          >
            {isUser ? (
              <>
                {msg.files && msg.files.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    {msg.files.map((file, index) => (
                      <ChatImageViewer key={index} file={file} />
                    ))}
                  </div>
                )}
                <div className="whitespace-pre-wrap text-xs">{msg.message}</div>
              </>
            ) : (
              <>
                {msg.error ? (
                  <div className="flex items-center gap-1.5 text-red-600">
                    <AlertTriangle size={16} />
                    <span className="text-xs font-medium">{msg.error}</span>
                  </div>
                ) : (
                  <>
                    <MarkdownWrapper
                      wrapperRef={contentRef}
                      markdown={msg.message}
                    />
                    {!msg.isLoading && (
                      <div
                        className="flex items-center gap-1.5 w-fit p-1 mt-2 text-gray-500 bg-gray-50 border border-gray-200 rounded"
                        style={{ fontSize: "10px" }}
                      >
                        <Info size={13} className="text-blue-500" />
                        AI Generated. Please check for accuracy.
                      </div>
                    )}
                  </>
                )}
              </>
            )}
          </div>
        )}

        {isUser && msg.error && (
          <div className="flex items-center gap-1.5 mt-1.5 text-red-600 text-xs px-1 justify-end">
            <AlertTriangle size={14} />
            <span>{msg.error}</span>
          </div>
        )}

        {showActions && (
          <ChatBubbleActions
            msg={msg}
            isAI={isAI}
            isUser={isUser}
            copiedId={copiedId}
            editingId={editingId}
            onCopy={handleCopy}
            onEdit={onStartEdit}
            onFeedback={onFeedback}
            onRegenerate={onRegenerate}
          />
        )}
      </div>

      {isUser && (
        <Avatar className="w-[35px] h-[35px]">
          {avatar ? (
            <AvatarImage src={avatar} alt={nameForAvatarFallback} />
          ) : null}
          <AvatarFallback className="bg-gray-600 text-white text-xs">
            {nameForAvatarFallback}
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
};

export default ChatMessageBubble;
