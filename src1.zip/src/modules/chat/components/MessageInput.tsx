import React, {
  KeyboardEvent,
  useEffect,
  useRef,
  useState,
  useCallback,
} from "react";
import { Paperclip, ArrowUp, X } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { cn } from "@/lib/utils";
import { useChatSessionStore } from "../store/chatSessionStore";
import axiosInstance from "@/utils/axiosInstance";
import { useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { ragStatusType } from "../Chat";
import UsageTerms from "@/shared/UsageTerms";

interface MessageInputProps {
  onSendMessage: (message: string, files: File[]) => void;
  skillID: number | null;
  selectedImages: File[];
  setSelectedImages: React.Dispatch<React.SetStateAction<File[]>>;
  isAiResponding: boolean;
  placeholder?: string;
  ragStatus: ragStatusType;
}

export const MessageInput: React.FC<MessageInputProps> = ({
  onSendMessage,
  skillID,
  selectedImages,
  setSelectedImages,
  isAiResponding,
  placeholder = "Ask a question or upload an image...",
  ragStatus,
}) => {
  const queryClient = useQueryClient();
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [textInput, setTextInput] = useState("");
  const [previewURLs, setPreviewURLs] = useState<string[]>([]);
  const { workspaces } = useWorkspaceStore();
  const { selectedAiModelId } = useChatSessionStore();
  
  

  const isSkillAvailableAndProcessed =
    !!skillID &&
    workspaces.some((workspace) =>
      workspace.skills.some(
        (skill) => skill.id === skillID && skill.is_processed_for_rag
      )
    );

  useEffect(() => {
    const newPreviewURLs = selectedImages.map((file) =>
      URL.createObjectURL(file)
    );
    setPreviewURLs(newPreviewURLs);

    return () => {
      newPreviewURLs.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [selectedImages]);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (
      e.key === "Enter" &&
      !e.shiftKey &&
      !isAiResponding &&
      (textInput.trim() || selectedImages.length > 0)
    ) {
      e.preventDefault();
      handleSendClick();
    }
  };

  const handleSendClick = () => {
    if (
      (textInput.trim() || selectedImages.length > 0) &&
      !isAiResponding &&
      isSkillAvailableAndProcessed
    ) {
      onSendMessage(textInput.trim(), selectedImages);
      setTextInput("");
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []);
    if (files.length > 0) {
      const newFiles = files.filter(
        (file) =>
          !selectedImages.some(
            (existingFile) =>
              existingFile.name === file.name &&
              existingFile.size === file.size &&
              existingFile.lastModified === file.lastModified
          )
      );
      setSelectedImages((prevFiles) => [...prevFiles, ...newFiles]);
    }
  };

  const handleRemoveImage = useCallback(
    (indexToRemove: number) => {
      setSelectedImages((prevFiles) =>
        prevFiles.filter((_, index) => index !== indexToRemove)
      );
    },
    [setSelectedImages]
  );

  const handlePaperclipClick = () => {
    if (
      isSkillAvailableAndProcessed &&
      fileInputRef.current &&
      !isAiResponding
    ) {
      fileInputRef.current.click();
    }
  };

  const canInteract =
    isSkillAvailableAndProcessed &&
    !isAiResponding &&
    selectedAiModelId &&
    !(ragStatus === "Pending" || ragStatus === "Failure");

  const canSend =
    (textInput.trim() || selectedImages.length > 0) && canInteract;

  let dynamicPlaceholder = placeholder;

  if (!skillID) {
    dynamicPlaceholder = "Please select a skill to begin.";
  } else if (!isSkillAvailableAndProcessed) {
    dynamicPlaceholder = "Selected skill is not ready or available for chat.";
  } else if (isAiResponding) {
    dynamicPlaceholder = "AI is responding...";
  } else if (!selectedAiModelId) {
    dynamicPlaceholder = "Please select an AI model to begin.";
  }

  dynamicPlaceholder =
    ragStatus === "Pending"
      ? "Checking Skill status..."
      : ragStatus === "Failure"
      ? "Skill processing failed. Please try again later."
      : dynamicPlaceholder;

  return (
    <div className="flex flex-col items-center w-full">
      <div
        className="border-[1.5px] rounded-[10px] bg-white p-2 md:p-3 w-full flex flex-col transition-all duration-300 hover:shadow-lg"
        style={{
          border: "1.5px solid transparent",
          borderRadius: "8px",
          backgroundImage: `linear-gradient(white,white), linear-gradient(to right, #FFC4D2, #9AF6F4)`,
          backgroundOrigin: "border-box",
          backgroundClip: "padding-box, border-box",
        }}
      >
        {previewURLs.length > 0 && (
          <div className="w-full mb-2 flex gap-2 flex-wrap p-1 bg-slate-50 rounded max-h-[150px] overflow-y-auto scrollbar-thin animate-in fade-in-50 slide-in-from-top-2 duration-300">
            {previewURLs.map((url, idx) => (
              <div
                key={`${url}-${idx}`}
                className="relative h-[60px] w-[60px] flex-shrink-0 animate-in fade-in-50 zoom-in-95 duration-300"
                style={{ animationDelay: `${idx * 100}ms` }}
              >
                <img
                  src={url}
                  alt={`Preview ${idx + 1}`}
                  className="h-full w-full rounded-md object-cover border border-gray-200 transition-transform duration-200 hover:scale-105"
                />
                <button
                  onClick={() => handleRemoveImage(idx)}
                  className="absolute -top-1.5 -right-1.5 bg-gray-700 hover:bg-red-600 text-white p-0.5 rounded-full leading-none shadow-md transition-all duration-200 hover:scale-110 active:scale-95"
                  type="button"
                  aria-label="Remove image"
                >
                  <X
                    size={14}
                    strokeWidth={2.5}
                    className="transition-transform duration-200 hover:rotate-90"
                  />
                </button>
              </div>
            ))}
          </div>
        )}
        <textarea
          ref={textareaRef}
          value={textInput}
          onChange={(e) => {
            setTextInput(e.target.value);
            e.target.style.height = "auto";
            e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
          }}
          onKeyDown={handleKeyDown}
          placeholder={dynamicPlaceholder}
          rows={1}
          className="w-full p-2 text-sm bg-white focus:outline-none resize-none overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 font-unilever transition-all duration-200 focus:bg-gray-50 custom-scrollbar"
          style={{
            maxHeight: "120px",
          }}
          disabled={!canInteract}
        />
        <div className="flex justify-between items-center w-full mt-1">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePaperclipClick}
              disabled={!canInteract}
              className={cn(
                "group cursor-pointer bg-white border border-gray-200 p-1 md:p-1.5 rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-300 hover:scale-105 active:scale-95",
                canInteract
                  ? "text-gray-500 hover:bg-gray-100 hover:text-blue-600 hover:border-blue-300 hover:shadow-md"
                  : "text-gray-300 cursor-not-allowed"
              )}
              tabIndex={0}
              aria-label="Attach files"
            >
              <Paperclip
                size={18}
                className="transition-all duration-300 ease-in-out group-hover:rotate-45 group-hover:scale-110"
              />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".jpg,.jpeg,.png,image/jpeg,image/png"
              multiple
              onChange={handleFileChange}
              style={{ display: "none" }}
              disabled={!canInteract}
            />
          </div>
          {isAiResponding && isSkillAvailableAndProcessed ? (
            <div className="p-2">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <button
              className={cn(
                "p-1 rounded-md transition-all duration-200 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-offset-1 hover:scale-105 active:scale-95 cursor-pointer",
                canSend
                  ? "bg-gradient-to-t from-blue-800 via-blue-600 to-blue-400 text-white shadow-md focus:ring-blue-500 hover:shadow-lg hover:from-blue-900 hover:via-blue-700 hover:to-blue-500"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed focus:ring-gray-400"
              )}
              onClick={handleSendClick}
              disabled={!canSend}
              type="button"
              aria-label="Send message"
            >
              <ArrowUp
                size={16}
                className="transition-transform duration-200 hover:scale-110"
              />
            </button>
          )}
        </div>
      </div>
      <p className="text-[10px] md:text-xs py-2 text-gray-500 text-center w-full font-unilever">
        Please use with discretion and follow &nbsp;
        <Dialog>
            <DialogTrigger asChild>
              <span className="underline cursor-pointer hover:text-blue-600">
                usage terms
              </span>
            </DialogTrigger>
          <DialogContent className="sm:max-w-[500px] md:max-w-[600px] bg-white font-unilever p-6 rounded-lg shadow-xl">
            <UsageTerms isChat={true}/>
          </DialogContent>
        </Dialog>
      </p>
    </div>
  )
}
