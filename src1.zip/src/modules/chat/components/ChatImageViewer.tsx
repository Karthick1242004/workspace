import { useFetchHandler } from "@/@logic/getHandlers";
import { Skeleton } from "@/components/ui/skeleton";
import React from "react";

export function ChatImageViewer({ file }: any) {
  
  const { data, isLoading } = useFetchHandler(
    `/chats/file/${file.id}/download/`,
    file.id,
    true,
    true
  );
  const imgUrl = data ? URL.createObjectURL(data) : undefined;

  return (
    <div className="flex justify-center items-center">
      {isLoading ? (
        <Skeleton className="w-[80px] h-[80px] rounded-sm bg-gray-400" />
      ) : (
        <img
          src={imgUrl}
          alt={file.name}
          height={120}
          width={120}
          className="cursor-pointer"
          onClick={() => window.open(imgUrl, "_blank")}
        />
      )}
    </div>
  );
}
