import React from "react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeRaw from "rehype-raw";
import root from "react-shadow";

export function MarkdownWrapper({ markdown, wrapperRef }: { markdown: string, wrapperRef: any }) {
  return (
    <root.div className="text-xs" ref={wrapperRef}>
      <Markdown
        components={{
          table: ({ node, ...props }) => (
            <table
              style={{
                borderCollapse: "collapse",
                border: "1px solid black",
                padding: "0.5rem",
              }}
              {...props}
            >
              {props.children}
            </table>
          ),
          th: ({ node, ...props }) => (
            <th
              style={{
                border: "1px solid black",
                padding: "0.25rem 0.5rem",
              }}
              {...props}
            >
              {props.children}
            </th>
          ),
          td: ({ node, ...props }) => (
            <td
              style={{
                border: "1px solid black",
                padding: "0.25rem 0.5rem",
              }}
              {...props}
            >
              {props.children}
            </td>
          ),
        }}
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeRaw]}
      >
        {markdown}
      </Markdown>
    </root.div>
  );
}

