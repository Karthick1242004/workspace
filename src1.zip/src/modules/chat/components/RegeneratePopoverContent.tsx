import React from "react";
import { Check, ChevronRight, RotateCcw as MainRetryIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import ChatMessage from "../model/ChatMessage";
import { AiModelOption } from "../store/chatConfigStore";

interface RegeneratePopoverContentProps {
  msg: ChatMessage;
  aiModels: AiModelOption[];
  retrySameModelId: number | null | undefined;
  retrySameModelName: string;
  onRegenerate: (message: ChatMessage, newModelId?: number) => void;
  closePopover: () => void;
}

export const RegeneratePopoverContent: React.FC<
  RegeneratePopoverContentProps
> = ({
  msg,
  aiModels,
  retrySameModelId,
  retrySameModelName,
  onRegenerate,
  closePopover,
}) => {
  const handleRegenerateWithSpecificModel = (modelId?: number) => {
    onRegenerate(msg, modelId);
    closePopover();
  };

  return (
    <div className="flex flex-col text-xs">
      {/* Retry Same Button */}
      <button
        className="flex items-center gap-3 p-2 text-left text-gray-700 hover:bg-gray-100 transition-colors duration-150 rounded-t-md cursor-pointer"
        onClick={() => handleRegenerateWithSpecificModel(retrySameModelId!)}
      >
        <MainRetryIcon size={15} className="text-blue-600 flex-shrink-0" />
        <span className="flex-grow font-xs font-unilever">
          Retry with {retrySameModelName}
        </span>
      </button>

      {/* Separator */}
      <div className="flex items-center px-4 py-2">
        <div className="flex-grow border-t border-gray-200"></div>
        <span className="px-2 text-xs text-gray-400 font-unilever">or switch model</span>
        <div className="flex-grow border-t border-gray-200"></div>
      </div>

      {/* Model List */}
      <div className="max-h-[200px] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 px-1 pb-1">
        {aiModels.length > 0 ? (
          aiModels.map((model: AiModelOption) => {
            const isDisabled = model.id === msg.ai_model_id;
            return (
              <button
                key={model.id}
                className={cn(
                  "flex items-center justify-between px-3 py-1.5 text-left text-gray-700 hover:bg-gray-100 transition-colors duration-150 w-full rounded-md cursor-pointer",
                  isDisabled
                    ? "opacity-50 cursor-not-allowed"
                    : "hover:bg-blue-50"
                )}
                onClick={() =>
                  !isDisabled && handleRegenerateWithSpecificModel(model.id)
                }
                disabled={isDisabled}
              >
                <span className="flex-grow truncate font-xs font-unilever">{model.name}</span>
                {isDisabled ? (
                  <Check
                    size={16}
                    className="text-blue-600 flex-shrink-0 ml-2"
                  />
                ) : (
                  <></>
                )}
              </button>
            );
          })
        ) : (
          <p className="px-4 py-3 text-xs text-gray-500 text-center">
            No other models available.
          </p>
        )}
      </div>
    </div>
  );
};
