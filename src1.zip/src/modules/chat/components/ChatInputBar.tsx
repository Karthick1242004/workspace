import React, { useState } from "react";
import { MessageInput } from "./MessageInput";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { useChatOperations } from "../hooks/chatOperations";
import { useChatSessionStore } from "../store/chatSessionStore";
import { ragStatusType } from "../Chat";

const ChatInputBar = ( { ragStatus } : { ragStatus : ragStatusType}) => {
  const { handleSendMessage } = useChatOperations();
  const { isAiResponding } = useChatSessionStore();
  const { selectedSkillId } = useWorkspaceStore();

  const [selectedImages, setSelectedImages] = useState<File[]>([]);

  const onSendFromMessageInput = (message: string, files: File[]) => {
    if (!selectedSkillId) {
      console.warn("Attempted to send message without active session or skill.");
      return;
    }    
    handleSendMessage(message, files);
    setSelectedImages([]); 
  };

  return (
<div className="w-full flex justify-center items-end z-1">
      <div className="w-full max-w-[var(--chat-content-width)] px-2 md:px-0">
        <MessageInput
          onSendMessage={onSendFromMessageInput}
          skillID={selectedSkillId}
          selectedImages={selectedImages}
          setSelectedImages={setSelectedImages}
          isAiResponding={isAiResponding}
          ragStatus={ragStatus}
        />
      </div>
    </div>
  );
};

export default ChatInputBar;