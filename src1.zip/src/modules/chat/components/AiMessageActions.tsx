import React from "react";
import {
  Copy,
  ThumbsUp,
  ThumbsDown,
  Check,
  RotateCcw as MainRetryIcon,
  Cpu,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import ChatMessage from "../model/ChatMessage";
import { useChatSessionStore } from "../store/chatSessionStore";
import { useWorkspaceStore } from "@/@logic/workspaceStore";

interface AiMessageActionsProps {
  msg: ChatMessage;
  copiedId: number | null;
  onCopy: (text: string, type: 'ai') => void;
  onFeedback: (message: ChatMessage, isGood: boolean) => void;
  onRegenerate: (message: ChatMessage, newModelId?: number) => void;
}

const actionsClassBase =
  "cursor-pointer text-gray-500 hover:text-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-400 rounded transition-all duration-200 hover:scale-110 hover:bg-blue-50 active:scale-95";
const iconSize = 15;

export const AiMessageActions: React.FC<AiMessageActionsProps> = ({
  msg,
  copiedId,
  onCopy,
  onFeedback,
  onRegenerate,
}) => {
  const { selectedAiModelId: globalSelectedModelId, isAiResponding } = useChatSessionStore();

  const { getAiModelOptions } = useWorkspaceStore();

  const aiModels = getAiModelOptions() ?? [];

  const modelThatGeneratedThisMessage = aiModels.find(
    (m) => m.value === msg.ai_model_id
  );
  const displayedModelName = modelThatGeneratedThisMessage?.label;

  const retrySameModelId = msg.ai_model_id || globalSelectedModelId;

  return (
    <div className="flex flex-wrap items-center gap-x-2.5 mr-1 mt-1">
      <div
        className={cn(
          "flex gap-x-2.5 items-center transition-opacity duration-200",
          "opacity-0 group-hover:opacity-100"
        )}
      >
        <Tooltip
          open={copiedId === msg.id ? true : undefined}
          delayDuration={0}
        >
          <TooltipTrigger asChild>
            <button
              onClick={() => onCopy(msg.message, 'ai')}
              className={cn(actionsClassBase, "p-0.5")}
              aria-label="Copy AI response"
              
            >
              {copiedId === msg.id ? (
                <Check
                  size={iconSize}
                  className="text-green-500 animate-pulse"
                />
              ) : (
                <Copy
                  size={iconSize}
                  className="transition-transform duration-200 hover:rotate-12"
                />
              )}
            </button>
          </TooltipTrigger>
          <TooltipContent sideOffset={4} disableArrow>
            <p>{copiedId === msg.id ? "Copied!" : "Copy"}</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => onFeedback(msg, true)}
              className={cn(
                actionsClassBase,
                "p-0.5",
                msg.user_feedback === true
                  ? "text-green-500 hover:text-green-600 bg-green-50"
                  : "hover:bg-green-50"
              )}
              aria-label="Good response"
            >
              <ThumbsUp
                size={iconSize}
                fill={msg.user_feedback === true ? "currentColor" : "none"}
                className="transition-transform duration-200 hover:-rotate-12"
              />
            </button>
          </TooltipTrigger>
          <TooltipContent sideOffset={4} disableArrow>
            <p>Good Response</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => onFeedback(msg, false)}
              className={cn(
                actionsClassBase,
                "p-0.5",
                msg.user_feedback === false
                  ? "text-red-500 hover:text-red-600 bg-red-50"
                  : "hover:bg-red-50"
              )}
              aria-label="Bad response"
            >
              <ThumbsDown
                size={iconSize}
                fill={msg.user_feedback === false ? "currentColor" : "none"}
                className="transition-transform duration-200 hover:rotate-12"
              />
            </button>
          </TooltipTrigger>
          <TooltipContent sideOffset={4} disableArrow>
            <p>Bad Response</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              className={cn(
                actionsClassBase,
                "p-0.5 h-auto data-[state=open]:text-blue-600",
                isAiResponding ? "pointer-events-none" : "hover:bg-blue-50"
              )}
              onClick={() => onRegenerate(msg, retrySameModelId ?? undefined)}
              disabled={isAiResponding}
            >
              <MainRetryIcon
                size={iconSize}
                className="transition-transform duration-300 hover:rotate-180"
              />
            </button>
          </TooltipTrigger>
          <TooltipContent sideOffset={4} disableArrow>
            <p>{isAiResponding ? "Please wait..." : "Regenerate"}</p>
          </TooltipContent>
        </Tooltip>
      </div>

      {displayedModelName && (
        <div className="flex items-center text-[10px] text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity duration-200 justify-start">
          <Cpu
            size={11}
            className="mr-1 text-gray-400 transition-transform duration-200 hover:scale-110"
          />
          Generated with {displayedModelName}
        </div>
      )}
    </div>
  );
};
