import React from "react";
import { Button } from "@/components/ui/button";
import GradientStrokeText from "./GradientText";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { useChatOperations } from "../hooks/chatOperations";
import { useMsal } from "@azure/msal-react";
import { ragStatusType } from "../Chat";
import { Loader2 } from "lucide-react";

export default function NewChatSuggestion({
  ragStatus,
}: {
  ragStatus: ragStatusType;
}) {
  const { accounts } = useMsal();
  const name = accounts[0]?.name?.split(",")[1] || "User";

  const { selectedWorkspaceId, selectedSkillId, getSelectedSkill } =
    useWorkspaceStore();

  const { handleSendMessage } = useChatOperations();

  const currentSkill = getSelectedSkill();
  const skillName = currentSkill?.name;
  const questionsString = currentSkill?.questions;

  function parseStringArray(input?: string): string[] {
    if (!input) return [];
    try {
      const parsed = JSON.parse(input);
      if (
        Array.isArray(parsed) &&
        parsed.every((item) => typeof item === "string")
      ) {
        return parsed;
      }
      // If 'questions' is a string that itself contains a JSON array string:
      if (typeof parsed === "string") {
        const nestedParsed = JSON.parse(parsed);
        if (
          Array.isArray(nestedParsed) &&
          nestedParsed.every((item) => typeof item === "string")
        ) {
          return nestedParsed;
        }
      }
      console.warn("Parsed questions is not an array of strings:", parsed);
      return [];
    } catch (e) {
      console.error("Invalid JSON in skill questions", input, e);
      return [];
    }
  }

  const suggestionQuestions = parseStringArray(questionsString);

  const handleQuickMessage = (quickMsg: string) => {
    const trimmedMessage = quickMsg.trim();
    if (trimmedMessage) {
      handleSendMessage(trimmedMessage);
    }
  };

  const displayName = name;

  return (
    <div className="flex flex-col flex-1 items-center justify-center w-full text-center px-4">
      <GradientStrokeText text={`Hello ${displayName}`} />
      {ragStatus === "Pending" ? (
        <div className="flex gap-2">
          <Loader2 className="animate-spin" />
          <p className="text-gray-600 font-unilever text-sm">
            Checking skill status, please wait...
          </p>
        </div>
      ) : ragStatus === "Failure" ? (
        <p className="text-gray-600 font-unilever text-sm">
          Skill processing failed. Please try again later.
        </p>
      ) : (
        <>
          {selectedSkillId && skillName ? (
            <p className="text-gray-600 mb-8 font-unilever text-sm">
              Tap into the expertise of{" "}
              <span className="font-unilever-medium">{skillName}</span>, ask
              your questions!
            </p>
          ) : selectedWorkspaceId ? (
            <p className="text-gray-600 mb-8 font-unilever text-sm">
              Please select a skill to see suggestions and start chatting.
            </p>
          ) : (
            <p className="text-gray-600 mb-8 font-unilever text-sm">
              Please select a workspace and a skill to begin.
            </p>
          )}

          <div className="flex gap-3 flex-wrap justify-center max-w-2xl">
            {suggestionQuestions.length > 0 && selectedSkillId ? (
              suggestionQuestions.map((text: string, idx: number) => (
                <Button
                  key={idx}
                  variant="outline"
                  className="text-xs rounded-[5px] px-3 border-gray-300 bg-white hover:bg-gray-100 py-2 font-unilever cursor-pointer shadow-sm"
                  onClick={() => handleQuickMessage(text)}
                  disabled={!selectedSkillId}
                >
                  {text}
                </Button>
              ))
            ) : selectedSkillId ? (
              <p className="text-gray-500 text-sm">
                No specific question suggestions available for this skill.
                <br />
                Feel free to ask anything!
              </p>
            ) : null}
          </div>
        </>
      )}
    </div>
  );
}
