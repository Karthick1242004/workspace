import React from "react";
import { Copy, Pencil, Check } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import ChatMessage from "../model/ChatMessage";
import { useChatSessionStore } from "../store/chatSessionStore";
import { cn } from "@/lib/utils";

interface UserMessageActionsProps {
  msg: ChatMessage;
  copiedId: number | null;
  onCopy: (text: string, type: "user") => void;
  onEdit: (id: number, val: string) => void;
}

const iconSize = 15;

export const UserMessageActions: React.FC<UserMessageActionsProps> = ({
  msg,
  copiedId,
  onCopy,
  onEdit,
}) => {
  const { isAiResponding } = useChatSessionStore();

  return (
    <div className="flex gap-2.5 mr-1 mt-1 justify-end items-center">
      {copiedId === msg.id ? (
        <Check size={iconSize} className="text-green-500 animate-pulse" />
      ) : (
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => onCopy(msg.message, 'user')}
              className="opacity-0 group-hover:opacity-100 transition-all duration-200 cursor-pointer text-gray-500 hover:text-blue-600 px-1 py-0.5 rounded hover:scale-110 hover:bg-blue-50 active:scale-95 focus:outline-none focus:ring-1 focus:ring-blue-400"
              aria-label="Copy message"
            >
              <Copy
                size={iconSize}
                className="transition-transform duration-200 hover:rotate-12"
              />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom" sideOffset={4} disableArrow>
            <p>Copy</p>
          </TooltipContent>
        </Tooltip>
      )}
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => onEdit(msg.id, msg.message)}
            className={cn(
              "opacity-0 group-hover:opacity-100 transition-all duration-200  text-gray-500 px-1 py-0.5 rounded active:scale-95 focus:outline-none focus:ring-1 focus:ring-blue-400",
              isAiResponding
                ? "cursor-not-allowed"
                : "cursor-pointer hover:text-blue-600  hover:scale-110 hover:bg-blue-50"
            )}
            aria-label="Edit message"
            disabled={isAiResponding}
          >
            <Pencil
              size={iconSize}
              className="transition-transform duration-200 hover:-rotate-12 hover:scale-110"
            />
          </button>
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={4} disableArrow>
          <p>Edit</p>
        </TooltipContent>
      </Tooltip>
    </div>
  );
};
