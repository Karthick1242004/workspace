import React from "react";
import {
  Copy,
  Pencil,
  ThumbsUp,
  ThumbsDown,
  RotateCcw,
  Check,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import ChatMessage from "./ChatMessageModel";

interface ChatBubbleActionsProps {
  msg: ChatMessage;
  isAI: boolean;
  isUser: boolean;
  copiedId: number | null;
  editingId: number | null;
  onCopy: (text: string, id: number) => void;
  onEdit: (id: number, val: string) => void;
  onFeedback: (message: ChatMessage, isGood: boolean) => void;
  onRegenerate: (message: ChatMessage) => void;
}
const actionsClass =
  "opacity-0 group-hover:opacity-100 transition-opacity duration-200 cursor-pointer text-gray-500";

const ChatBubbleActions: React.FC<ChatBubbleActionsProps> = ({
  msg,
  isAI,
  isUser,
  copiedId,
  editingId,
  onCopy,
  onEdit,
  onFeedback,
  onRegenerate,
}) => {
  if (editingId === msg.id) return null;

  if (isUser) {
    return (
      <div className="flex gap-2 mr-1 mt-2 justify-end">
        {copiedId === msg.id ? (
          <Check size={14} className="text-green-500" color="green" />
        ) : (
          <Tooltip>
            <TooltipTrigger>
              <Copy
                size={14}
                className={actionsClass}
                color="black"
                onClick={() => onCopy(msg.message, msg.id)}
              />
            </TooltipTrigger>
            <TooltipContent
              side="bottom"
              sideOffset={4}
              className="bg-white border-none"
            >
              <p>Copy</p>
            </TooltipContent>
          </Tooltip>
        )}
        <Tooltip>
          <TooltipTrigger>
            <Pencil
              size={14}
              className={actionsClass}
              color="black"
              onClick={() => onEdit(msg.id, msg.message)}
            />
          </TooltipTrigger>
          <TooltipContent
            side="bottom"
            sideOffset={4}
            className="bg-white border-none"
          >
            <p>Edit</p>
          </TooltipContent>
        </Tooltip>
      </div>
    );
  }
  if (isAI) {
    return (
      <div className="flex gap-2 mr-1 mt-2 ">
        <Tooltip open={copiedId === msg.id}>
          <TooltipTrigger>
            {copiedId === msg.id ? (
              <Check size={14} className="text-green-500" color="green" />
            ) : (
              <Copy
                size={14}
                className={actionsClass}
                color="black"
                onClick={() => onCopy(msg.message, msg.id)}
              />
            )}
          </TooltipTrigger>
          <TooltipContent
            side="top"
            sideOffset={4}
            className="bg-white border-none"
          >
            
              {copiedId === msg.id
                ? "Copied AI Generated Content. Please Use Responsibly"
                : "Copy"}
          </TooltipContent>
        </Tooltip>


        <Tooltip>
          <TooltipTrigger>
            <ThumbsUp
              size={14}
              className={actionsClass}
              color="black"
              onClick={() => onFeedback(msg, true)}
              fill={msg.user_feedback === true ? "green" : "none"}
            />
          </TooltipTrigger>
          <TooltipContent
            side="top"
            sideOffset={4}
            className="bg-white border-none"
          >
            <p>Good Response</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger>
            <ThumbsDown
              size={14}
              className={actionsClass}
              color="black"
              onClick={() => onFeedback(msg, false)}
              fill={msg.user_feedback === false ? "red" : "none"}
            />
          </TooltipTrigger>
          <TooltipContent
            side="top"
            sideOffset={4}
            className="bg-white border-none"
          >
            <p>Bad Response</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger>
            <RotateCcw
              size={14}
              className={actionsClass}
              color="black"
              onClick={() => onRegenerate(msg)}
            />
          </TooltipTrigger>
          <TooltipContent
            side="top"
            sideOffset={4}
            className="bg-white border-none"
          >
            <p>Regenerate Response</p>
          </TooltipContent>
        </Tooltip>
      </div>
    );
  }

  return null;
};

export default ChatBubbleActions;
