import { create } from "zustand";
import ChatMessage from "../model/ChatMessage";

export interface RolePlayOption {
  value: number;
  label: string;
}

interface ChatSessionState {
  chatSessionId: string | null;
  chatTitle: string;
  messages: ChatMessage[];
  isAiResponding: boolean;
  showWelcomeMessage: boolean;
  editingMessageId: number | null;
  copiedMessageId: number | null;
  isNewChatSession: boolean;
  selectedAiModelId: number | null;
  selectedRole: RolePlayOption | null;

  startNewChatSession: () => void;
  setChatSessionId: (id: string | null, title?: string) => void;
  setChatTitle: (title: string) => void;
  loadMessages: (messages: ChatMessage[]) => void;
  setMessage: (message: ChatMessage[]) => void;
  addMessage: (message: ChatMessage) => void;
  removeMessage: (messageId: number) => void;
  updateMessage: (messageId: number, updates: Partial<ChatMessage>) => void;
  optimisticallyUpdateMessagesForEdit: (
    originalMessageToEdit: ChatMessage,
    newText: string,
    aiLoadingMessage: ChatMessage
  ) => void;
  replaceMessages: (messages: ChatMessage[]) => void;
  setIsAiResponding: (isResponding: boolean) => void;
  setShowWelcomeMessage: (show: boolean) => void;
  setEditingMessageId: (id: number | null) => void;
  setCopiedMessageId: (id: number | null) => void;
  setSelectedAiModelId: (id: number | null) => void;
  setSelectedRole: (role: RolePlayOption | null) => void;
}

export const useChatSessionStore = create<ChatSessionState>((set, get) => ({
  chatSessionId: null,
  chatTitle: "New Chat",
  messages: [],
  isAiResponding: false,
  showWelcomeMessage: true,
  editingMessageId: null,
  copiedMessageId: null,
  isNewChatSession: true,
  selectedAiModelId: null,
  selectedRole: null,

  startNewChatSession: () => {
    set({
      chatSessionId: null,
      chatTitle: "New Chat",
      messages: [],
      isAiResponding: false,
      showWelcomeMessage: true,
      editingMessageId: null,
      isNewChatSession: true,
      selectedRole: null,
      selectedAiModelId: null,
    });
  },

  setChatSessionId: (id, title = "New Chat") => {
    set({
      chatSessionId: id,
      chatTitle: id ? title : "New Chat",
      isNewChatSession: !id,
    });
  },

  setChatTitle: (title) => set({ chatTitle: title }),
  loadMessages: (messages) =>
    set({
      messages,
      showWelcomeMessage: messages.length === 0,
      isNewChatSession: false,
    }),
  setMessage: (message) => set({ messages: message }),
  addMessage: (message) =>
    set((state) => ({
      messages: [...state.messages, message],
      showWelcomeMessage: false,
    })),
  removeMessage: (messageId: number) =>
    set((state) => ({
      messages: state.messages.filter((msg) => msg.id !== messageId),
    })),
  updateMessage: (messageId, updates) =>
    set((state) => ({
      messages: state.messages.map((msg) =>
        msg.id === messageId ? { ...msg, ...updates } : msg
      ),
    })),
  optimisticallyUpdateMessagesForEdit: (
    originalMessageToEdit,
    newText,
    aiLoadingMessage
  ) => {
    set((state) => {
      const messagesUpToEdited = state.messages.filter(
        (msg) => msg.id < originalMessageToEdit.id
      );
      const updatedEditedMessage = {
        ...originalMessageToEdit,
        message: newText,
        isLoading: false,
      };
      return {
        messages: [
          ...messagesUpToEdited,
          updatedEditedMessage,
          aiLoadingMessage,
        ],
        isAiResponding: true,
      };
    });
  },
  replaceMessages: (newMessages) => {
    set({
      messages: newMessages,
      isAiResponding: false,
      editingMessageId: null,
      showWelcomeMessage: newMessages.length === 0,
    });
  },
  setIsAiResponding: (isResponding) => set({ isAiResponding: isResponding }),
  setShowWelcomeMessage: (show) => set({ showWelcomeMessage: show }),
  setEditingMessageId: (id) => set({ editingMessageId: id }),
  setCopiedMessageId: (id) => {
    set({ copiedMessageId: id });
    if (id !== null) {
      setTimeout(() => set({ copiedMessageId: null }), 3000);
    }
  },
  setSelectedAiModelId: (id: any) => set({ selectedAiModelId: id }),
  setSelectedRole: (role: any) => set({ selectedRole: role }),
}));
