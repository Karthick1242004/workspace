import { create } from "zustand";

export interface AiModelOption {
  id: number;
  name: string;
}

export interface RolePlayOption {
  value: number;
  label: string;
}

interface ChatConfigState {
  aiModels: AiModelOption[];
  selectedAiModelId: number | null; 
  selectedRole: RolePlayOption | null;

  setAiModels: (models: AiModelOption[]) => void;
  setSelectedAiModelId: (id: number | null) => void; 
  setSelectedRole: (role: RolePlayOption | null) => void;
}

export const useChatConfigStore = create<ChatConfigState>((set, get) => ({
  aiModels: [],
  selectedAiModelId: null,
  selectedRole: null,

  setAiModels: (models: AiModelOption[]) => set({ aiModels: models }),
  setSelectedAiModelId: (id: any) => set({ selectedAiModelId: id }),
  setSelectedRole: (role: any) => set({ selectedRole: role }),
}));