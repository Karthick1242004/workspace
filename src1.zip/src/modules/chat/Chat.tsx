import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { useNavigation } from "@/hooks/navigationHook";
import ChatMessage from "./ChatMessageModel";
import ChatHeader from "./ChatHeader";
import ChatBody from "./ChatBody";
import ChatInputBar from "./ChatInputBar";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { baseURL } from "@/@logic";
import { useFetchHandler } from "@/@logic/getHandlers";
import toast from "react-hot-toast";
import { useMsal } from "@azure/msal-react";
import { getUserProfile } from "@/utils/getUserProfile";
import axiosInstance from "@/utils/axiosInstance";
import { useQueryClient } from "@tanstack/react-query";

function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [selectedRole, setSelectedRole] = useState<any>(null);
  const [isNewChat, setIsNewChat] = useState(true);
  const [selectedModel, setSelectedModel] = useState("");
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [avatar, setAvatar] = useState<string>();
  const [isAiResponding, setIsAiResponding] = useState(false);

  const { chatId: chatIdParam } = useParams();
  const [searchParams, setSelectedParams] = useSearchParams();
  const queryClient = useQueryClient();

  const chatIdRef = useRef(
    chatIdParam === "new" ? undefined : Number(chatIdParam)
  );
  const chatId = chatIdRef.current;

  const { navigateTo } = useNavigation();

  const {
    selectedSkillId,
    selectedWorkspaceId,
    setSelectedWorkspaceId,
    setSelectedSkillId,
    workspaces,
  } = useWorkspaceStore();

  const { accounts } = useMsal();

  const name = accounts[0]?.name
    ? accounts[0]?.name.split(", ")[1]
      ? accounts[0]?.name.split(", ")[1]
      : accounts[0]?.name.split(",")[0]
    : "";

  const userProfile = async () => {
    if (accounts.length > 0) {
      const userProfile = await getUserProfile(accounts[0]);
      setAvatar(userProfile);
    }
  };

  useEffect(() => {
    userProfile();
  }, [accounts]);

  useEffect(() => {
    if (searchParams.has("new") && searchParams.get("new") === "true") {
      setSelectedParams({});
      setMessages([]);
      setIsNewChat(true);
      chatIdRef.current = undefined;
    }
  }, [searchParams]);

  const workspaceOptions = useMemo(() => {
    return workspaces.map((w) => ({
      value: w.id,
      label: w.name,
      skills: w.skills.map((skill) => ({
        value: skill.id,
        label: skill.name,
      })),
    }));
  }, [workspaces]);

  useEffect(() => {
    if (workspaces && workspaces.length > 0) {
      if (selectedWorkspaceId === 0 || !selectedWorkspaceId) {
        setSelectedWorkspaceId(workspaces[0].id);
      }
    }
  }, [workspaces]);

  const selectedWorkspace = useMemo(
    () => workspaces.find((w) => w.id === selectedWorkspaceId),
    [workspaces, selectedWorkspaceId]
  );

  const skillOptions = useMemo(() => {
    return (
      selectedWorkspace?.skills
        .filter(
          (skill) =>
            skill.is_processed_for_rag && skill.processing_status == "Completed"
        )
        .map((skill) => ({ value: skill.id, label: skill.name })) || []
    );
  }, [selectedWorkspace]);

  useEffect(() => {
    if (chatIdParam === "new") {
      setMessages([]);
      setSelectedImages([]);
      setIsNewChat(true);
    }
  }, [chatIdParam, selectedSkillId, selectedWorkspaceId]);

  const { data: chat, isLoading } = useFetchHandler(
    chatId ? `chats/?userId=1&chatId=${chatId}` : "",
    chatId ? `chat-${chatId}` : "",
    chatIdParam !== "new"
  );

  useEffect(() => {
    if (!chat || !Array.isArray(chat.messages)) return;

    const formattedMessages = chat.messages.map((msg: any) => ({
      id: msg.id,
      message: msg.message,
      role: msg.role === "AI" ? "MSB_Admin" : msg.role,
      createdAt: msg.createdAt || new Date().toISOString(),
      updatedAt: msg.updatedAt || new Date().toISOString(),
      chat_id: chat.chat.id,
      files: msg.files,
      user_feedback: msg.user_feedback,
    }));

    setMessages(formattedMessages);
    setIsNewChat(false);
  }, [chat]);

  const { data: aiDataModels, isLoading: isLoadingModels } = useFetchHandler(
    "chats/ai-models",
    "chats/ai-models",
    true
  );

  const aiModels = useMemo(() => {
    return (aiDataModels ?? []).map((model: { name: string }) => model.name);
  }, [aiDataModels]);

  useEffect(() => {
    if (aiModels.length > 0 && !selectedModel) setSelectedModel(aiModels[0]);
  }, [aiModels, selectedModel]);

  useEffect(() => {
    chatIdRef.current = chatIdParam === "new" ? undefined : Number(chatIdParam);
    setMessages([]);
    setIsNewChat(chatIdParam === "new");
  }, [chatIdParam]);

  const newChat = useCallback(
    async (userMessage: string) => {
      setIsAiResponding(true);
      const formData = new FormData();
      const payload = {
        userMessage,
        skillId: selectedSkillId || 0,
        isNewChat,
        chatId: chatId || 0,
        aiModelName: selectedModel,
        aiModelId: selectedModel
          ? aiDataModels.find(
              (model: { name: string }) => model.name === selectedModel
            )?.id
          : 0,
      };

      formData.append("payload", JSON.stringify(payload));
      selectedImages.forEach((file) => {
        formData.append("files", file);
      });

      try {
        const response = await axiosInstance.post(
          `${baseURL}chats/?userId=1`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        const responseData = response.data;
        const chatData = responseData.data;

        if (payload.isNewChat) {
          queryClient.invalidateQueries({ queryKey: ["chats/recent"] });
        }

        if (chatData.chat_id) {
          setIsNewChat(false);
          chatIdRef.current = chatData.chat_id;
        }

        setMessages(chatData.messages);
      } catch (error) {
        console.error("Error sending message:", error);

        setMessages((prev) => prev.filter((msg) => !msg.isLoading));

        const errorMessage =
          error instanceof Error
            ? error.message
            : "An unexpected error occurred";

        toast.error(`Failed to send message: ${errorMessage}`, {
          position: "top-right",
          style: {
            borderLeft: "4px solid red",
            fontFamily: "var(--font-unilever)",
            fontSize: "14px",
          },
        });
      } finally {
        setIsAiResponding(false);
      }
    },
    [selectedSkillId, isNewChat, selectedImages, chatId, navigateTo]
  );

  const onSendMessage = useCallback(
    (messageToSend: string) => {
      if (!messageToSend.trim()) return;

      const id = chatId ? messages.length + 1 : 1;
      const userMessage: ChatMessage = {
        id: id,
        message: messageToSend,
        role: "USER",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        chat: chatId || 0,
      };

      const loadingMessage: ChatMessage = {
        id: id + 1,
        message: "",
        role: "MSB_Admin",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        chat: chatId || 0,
        isLoading: true,
      };

      setMessages((prev) => [...prev, userMessage, loadingMessage]);
      newChat(messageToSend);
    },
    [newChat, chatId]
  );

  const onChangeNavigateToNewChat = useCallback(() => {
    if (chatId) navigateTo({ path: `/chat/new` });
  }, [chatId, navigateTo]);

  const handleWorkspaceChange = useCallback(
    (id: number) => {
      setSelectedWorkspaceId(id);
      const ws = workspaces.find((w) => w.id === id);
      if (ws && ws.skills.length) setSelectedSkillId(ws.skills[0].id);
      else setSelectedSkillId(0);
      onChangeNavigateToNewChat();
    },
    [
      workspaces,
      setSelectedWorkspaceId,
      setSelectedSkillId,
      onChangeNavigateToNewChat,
    ]
  );

  const handleSkillChange = useCallback(
    (id: number) => {
      setSelectedSkillId(id);
      onChangeNavigateToNewChat();
    },
    [setSelectedSkillId, onChangeNavigateToNewChat]
  );

  const showWelcome = !chatId && messages.length === 0;  

  return (
    <div className="w-[100vw] font-unilever">
      {isLoading ? (
        <div className="flex justify-center gap-2 items-center h-full">
          <div
            className="animate-spin inline-block size-8 border-3 border-current border-t-transparent text-blue-600 rounded-full dark:text-blue-500"
            role="status"
            aria-label="loading"
          >
            <span className="sr-only">Loading...</span>
          </div>
          <h3> Loading chat...</h3>
        </div>
      ) : (
        <div className="flex flex-col h-[var(--edit-content-height)]">
          <ChatHeader
            workspaces={workspaceOptions}
            workspaceId={selectedWorkspaceId}
            skillOptions={skillOptions}
            skillId={selectedSkillId}
            gptModels={aiModels ?? []}
            selectedModel={selectedModel}
            setSelectedModel={setSelectedModel}
            selectedRole={selectedRole}
            setSelectedRole={setSelectedRole}
            onWorkspaceChange={handleWorkspaceChange}
            onSkillChange={handleSkillChange}
            chatTitle={
              chat && chat?.chat && chat?.chat.title
                ? chat.chat.title
                : "New Chat"
            }
          />
          <ChatBody
            showWelcome={showWelcome}
            messages={messages}
            avatar={avatar}
            name={name}
            onSendMessage={onSendMessage}
            setMessages={setMessages}
            chatId={chatIdRef.current || 0}
            selectedSkillId={selectedSkillId}
            workspaceId={selectedWorkspaceId}
            aiModelsId={
              selectedModel
                ? aiDataModels.find(
                    (model: { name: string }) => model.name === selectedModel
                  )?.id
                : 0
            }
          />
          <ChatInputBar
            onSendMessage={onSendMessage}
            skillID={selectedSkillId || 0}
            selectedImages={selectedImages}
            setSelectedImages={setSelectedImages}
            isAiResponding={isAiResponding}
          />
        </div>
      )}
    </div>
  );
}

export default Chat;
