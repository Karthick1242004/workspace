import React, { useEffect, useMemo, useRef, useState } from "react";
import ChatHeader from "./components/ChatHeader";
import ChatBody from "./components/ChatBody";
import ChatInputBar from "./components/ChatInputBar";
import { useWorkspaceStore, Workspace } from "@/@logic/workspaceStore";
import { useChatSessionStore } from "./store/chatSessionStore";
import { useChatSessionLoader } from "./hooks/useChatSessionLoader";
import { Loader2 } from "lucide-react";
import { useLocation, useParams } from "react-router-dom";
import { useNavigation } from "@/hooks/navigationHook";
import { useMsal } from "@azure/msal-react";
import { getUserProfile } from "@/utils/getUserProfile";
import axiosInstance from "@/utils/axiosInstance";
import { usageLoggerConstants } from "@/constant/usageLogger";
import { useUsageLogger } from "@/utils/usageLogger";
import MSB_BG from "@/assets/images/Shining cube.svg";

export type ragStatusType = "Pending" | "Success" | "Failure";

const Chat: React.FC = () => {
  const { isLoadingChatDetails } = useChatSessionLoader();
  const location = useLocation();
  const rag_status = location?.state?.rag_status ?? false;
  const { navigateTo } = useNavigation();
  const [ragStatus, setRagStatus] = useState<ragStatusType>("Pending");

  const [avatar, setAvatar] = useState<string>();
  const scrollableContainerRef = useRef<HTMLDivElement | null>(null);
  const usageLogger = useUsageLogger();

  const { chatId } = useParams<{ chatId?: string }>();  

  const {
    getWorkspaces,
    selectedWorkspaceId,
    setSelectedWorkspaceId,
    selectedSkillId,
    setSelectedSkillId,
    getCurrentSkillOptions,
    isLoading: isLoadingWorkspaces,
    getAiModelOptions,
  } = useWorkspaceStore();

  const workspaceListFromStore = getWorkspaces();

  const {
    chatTitle,
    chatSessionId,
    startNewChatSession,
    selectedAiModelId,
    setSelectedAiModelId,
    selectedRole,
    setSelectedRole,
  } = useChatSessionStore();

  const aiModels = getAiModelOptions() ?? [];

  const { accounts } = useMsal();

  const userProfile = async () => {
    if (accounts.length > 0) {
      const userProfile = await getUserProfile(accounts[0]);
      setAvatar(userProfile);
    }
  };

  useEffect(() => {
    userProfile();
  }, []);

  useEffect(() => {
    if (aiModels.length > 0 && selectedAiModelId !== aiModels[0].value) {
      setSelectedAiModelId(aiModels[0].value);
    }
  }, [aiModels, setSelectedAiModelId]);

  useEffect(() => {
    if (location.pathname === "/chat") {
      startNewChatSession();
    }
  }, [location.pathname, startNewChatSession]);

  useEffect(() => {
    if (!chatId) {
      if (
        workspaceListFromStore &&
        workspaceListFromStore.length > 0 &&
        (selectedWorkspaceId === null || selectedWorkspaceId === 0)
      ) {
        setSelectedWorkspaceId(workspaceListFromStore[0].id);
        if (
          workspaceListFromStore[0].skills.length > 0 &&
          (selectedSkillId === null || selectedSkillId === 0)
        ) {
          setSelectedSkillId(workspaceListFromStore[0].skills[0].id);
        }
      }
    }
  }, [
    workspaceListFromStore,
    selectedWorkspaceId,
    setSelectedWorkspaceId,
    selectedSkillId,
    setSelectedSkillId,
  ]);

  const skillOptionsForHeader = useMemo(() => {
    return getCurrentSkillOptions().map((skill) => ({
      value: String(skill.id),
      label: skill.label,
    }));
  }, [selectedWorkspaceId, getCurrentSkillOptions]);

  const workspaceOptionsForHeader = useMemo(() => {
    return workspaceListFromStore.map((ws: Workspace) => ({
      value: String(ws.id),
      label: ws.name,
    }));
  }, [workspaceListFromStore]);

  const rolePlayForHeader = useMemo(() => {
    const selectedWorkspace = workspaceListFromStore.find(
      (ws) => ws.id === selectedWorkspaceId
    );
    if (selectedWorkspace?.personas && selectedWorkspace.personas.length > 0) {
      return selectedWorkspace.personas.map((p) => ({
        value: String(p.id),
        label: p.name,
      }));
    }
    return [];
  }, [workspaceListFromStore, selectedWorkspaceId]);

  const handleOnWorkspaceChange = (newWorkspaceId: number) => {
    setSelectedWorkspaceId(newWorkspaceId);
    const ws = workspaceListFromStore.find((w) => w.id === newWorkspaceId);
    if (ws && ws.skills.length > 0) {
      setSelectedSkillId(ws.skills[0].id);
    } else {
      setSelectedSkillId(null);
    }
    startNewChatSession();
    usageLogger(
      `${usageLoggerConstants.click.switched_workspace}`,
      "workspace",
      newWorkspaceId
    );

    navigateTo({ path: `/chat` });
  };

  const handleOnSkillChange = (newSkillId: number) => {
    setSelectedSkillId(newSkillId);
    startNewChatSession();
    usageLogger(
      `${usageLoggerConstants.click.switched_skill}`,
      "skill",
      newSkillId
    );

    navigateTo({ path: `/chat` });
  };

  const showChatAreaLoader =
    (isLoadingChatDetails || isLoadingWorkspaces) && chatSessionId !== null;

  const handleRagCheckStatus = async (skillID: number) => {
    setRagStatus("Pending");
    try {
      const response = await axiosInstance.get(`/skills/${skillID}/rag-status`);
      if (response.status !== 200) {
        throw new Error("Network response was not ok");
      }
      const data = response.data.data;
      if (
        data &&
        data.is_processed_for_rag &&
        (data.processing_status.toLowerCase() === "completed" ||
          data.processing_status.toLowerCase() === "inprogress")
      ) {
        setRagStatus("Success");
      } else {
        setRagStatus("Failure");
      }
    } catch (err: any) {
      console.error("Error fetching status:", err);
      setRagStatus("Failure");
    }
  };

  useEffect(() => {
    if (selectedSkillId) {
      if (rag_status) {
        setRagStatus("Success");
      } else {
        handleRagCheckStatus(selectedSkillId);
      }
    } else if (selectedWorkspaceId && !selectedSkillId) {
      setRagStatus("Failure");
    }
  }, [selectedSkillId, selectedWorkspaceId]);

  return (
    <div
      className="flex flex-col w-full h-full"
      style={{
        backgroundPosition: "center center",
        backgroundRepeat: "no-repeat",
        backgroundSize: "25% 25%",
        backgroundImage: `url(${MSB_BG})`,
      }}
    >
      <ChatHeader
        workspaces={workspaceOptionsForHeader}
        workspaceId={selectedWorkspaceId ?? undefined}
        isLoadingWorkspaces={isLoadingWorkspaces}
        onWorkspaceChange={handleOnWorkspaceChange}
        skillOptions={skillOptionsForHeader}
        skillId={selectedSkillId ?? undefined}
        onSkillChange={handleOnSkillChange}
        gptModels={aiModels}
        selectedModel={selectedAiModelId}
        setSelectedModel={(modelId) => setSelectedAiModelId(modelId)}
        isLoadingModels={isLoadingWorkspaces}
        selectedRole={selectedRole ? String(selectedRole.value) : ""}
        setSelectedRole={(roleValue) => {
          const role = rolePlayForHeader.find((r) => r.value === roleValue);
          if (role) {
            setSelectedRole({ value: Number(role.value), label: role.label });
          } else {
            setSelectedRole(null);
          }
        }}
        rolePlayItems={rolePlayForHeader}
        chatTitle={chatTitle}
      />

      <div
        ref={scrollableContainerRef}
        className="flex-grow overflow-y-auto scrollbar-thin custom-scrollbar"
      >
        {showChatAreaLoader ? (
          <div className="flex flex-1 justify-center items-center h-full">
            <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            <span className="ml-2 text-gray-600">Loading chat...</span>
          </div>
        ) : (
          <ChatBody
            avatar={avatar}
            scrollableContainerRef={scrollableContainerRef}
            ragStatus={ragStatus}
          />
        )}
      </div>
      <ChatInputBar ragStatus={ragStatus} />
    </div>
  );
};

export default Chat;
