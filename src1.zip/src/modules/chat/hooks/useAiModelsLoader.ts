import { useEffect } from "react";
import { useFetchHandler } from "@/@logic/getHandlers";
import { useChatConfigStore, AiModelOption } from "../store/chatConfigStore";

export const useAiModelsLoader = () => {
  const { setAiModels, setSelectedAiModelId, selectedAiModelId } =
    useChatConfigStore();

  const {
    data: fetchedAiModels,
    isLoading: isLoadingModels,
    error: modelsError,
  } = useFetchHandler("chats/ai-models", "ai-models-list", true);

  useEffect(() => {
    if (fetchedAiModels) {
      const modelsToSet: AiModelOption[] = fetchedAiModels.map(
        (m: { id: any; name: any }) => ({ id: m.id, name: m.name })
      );
      setAiModels(modelsToSet);
      if (selectedAiModelId === null && modelsToSet.length > 0) {
        setSelectedAiModelId(modelsToSet[0].id);
      }
    } else if (modelsError) {
      console.error("Failed to load AI Models:", modelsError);
      setAiModels([]);
    }
  }, [
    fetchedAiModels,
    modelsError,
    setAiModels,
    setSelectedAiModelId,
    selectedAiModelId,
  ]);

  return { isLoadingModels };
};
