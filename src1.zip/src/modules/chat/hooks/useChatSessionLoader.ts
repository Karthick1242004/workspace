import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useFetchHandler } from "@/@logic/getHandlers";
import { useChatSessionStore } from "../store/chatSessionStore";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import ChatMessage from "../model/ChatMessage";

export const useChatSessionLoader = () => {
  const { chatId: chatIdParam } = useParams<{ chatId?: string }>();

  const {
    setChatSessionId,
    loadMessages: setChatMessages,
    chatSessionId: currentGlobalChatId,
  } = useChatSessionStore();

  const { setSelectedWorkspaceId, setSelectedSkillId, getWorkspaces } = useWorkspaceStore();

  const workspaces = getWorkspaces();
  const fetchEnabled = !!chatIdParam && workspaces && workspaces.length > 0;

  const {
    data: chatResponse,
    isLoading: isLoadingChatDetails,
    error: chatError,
  } = useFetchHandler(
    fetchEnabled ? `chats/?chat_session_uuid=${chatIdParam}` : "",
    fetchEnabled ? ['chat', chatIdParam] : undefined,
    fetchEnabled,
    false,
    true, // refetch on mount to ensure we get the latest chat details
  );

  useEffect(() => {
    if (chatIdParam && currentGlobalChatId !== chatIdParam) {
      setChatSessionId(chatIdParam);
    }
  }, [chatIdParam, setChatSessionId, currentGlobalChatId]);

  useEffect(() => {
    if (fetchEnabled && chatResponse) {
      if (chatResponse.chat.chat_session_uuid === chatIdParam) {
        const chatSessionIdStr = chatResponse.chat.chat_session_uuid;
        setChatSessionId(chatSessionIdStr, chatResponse.chat.title);

        const messagesWithStringChatId = (chatResponse.messages || []).map(
          (msg: any): ChatMessage => ({
            ...msg,
            chat: String(msg.chat),
          }),
        );
        setChatMessages(messagesWithStringChatId);

        if (chatResponse.workspace)
          setSelectedWorkspaceId(chatResponse.workspace.id);
        if (chatResponse.skill) setSelectedSkillId(chatResponse.skill.id);
      }
    } else if (chatError) {
      console.error(`Error loading chat ${chatIdParam}:`, chatError);
      if (currentGlobalChatId === chatIdParam) {
        useChatSessionStore.getState().startNewChatSession();
      }
    }
  }, [
    chatResponse,
    chatError,
    fetchEnabled,
    chatIdParam,
    setChatSessionId,
    setChatMessages,
    setSelectedWorkspaceId,
    setSelectedSkillId,
    currentGlobalChatId,
  ]);

  return { isLoadingChatDetails };
};