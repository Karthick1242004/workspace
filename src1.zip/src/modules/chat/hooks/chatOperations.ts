import { baseURL, HTTPMethod } from "@/@logic";
import { useWorkspaceStore } from "@/@logic/workspaceStore";
import { useChatSessionStore } from "../store/chatSessionStore";
import ChatMessage from "../model/ChatMessage";
import axiosInstance from "@/utils/axiosInstance";
import { useQueryClient } from "@tanstack/react-query";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import toast from "react-hot-toast";

export const useChatOperations = () => {
  const {
    addMessage,
    removeMessage,
    updateMessage,
    replaceMessages,
    optimisticallyUpdateMessagesForEdit,
    setIsAiResponding,
    setEditingMessageId,
    setChatSessionId,
    chatSessionId,
    isNewChatSession,
    selectedAiModelId,
    selectedRole,
  } = useChatSessionStore();

  const { selectedSkillId } = useWorkspaceStore();
  const queryClient = useQueryClient();

  const findLastLoadingAiMessageId = (
    messages: ChatMessage[]
  ): number | undefined => {
    const loadingAiMessages = messages.filter(
      (m) => m.role.toLowerCase() !== "user" && m.isLoading
    );
    return loadingAiMessages.pop()?.id;
  };

  const onMessagesMutationSuccess = (
    response: any,
    mutationVariables?: any
  ) => {
    let messagesToReplace: any[] | undefined;

    if (
      response.data?.data?.messages &&
      Array.isArray(response.data.data.messages)
    ) {
      messagesToReplace = response.data.data.messages;
    } else if (
      response.data?.messages &&
      Array.isArray(response.data.messages)
    ) {
      messagesToReplace = response.data.messages;
    }

    if (messagesToReplace) {
      const processedMessages = messagesToReplace.map(
        (m): ChatMessage => ({
          ...m,
          chat: String(m.chat),
          isLoading: false,
          error: undefined,
        })
      );
      replaceMessages(processedMessages);
    } else {
      console.warn(
        "Mutation successful, but messages data is not as expected.",
        response.data
      );
      const freshMessages = useChatSessionStore.getState().messages;
      const loadingAiMessageId = findLastLoadingAiMessageId(freshMessages);
      if (loadingAiMessageId) {
        updateMessage(loadingAiMessageId, {
          isLoading: false,
          error: "Response format error. Please try again.",
        });
      }
    }
    setIsAiResponding(false);
  };

  const onMutationError = (error?: any, mutationVariables?: any) => {
    console.error("Mutation failed:", error, "Variables:", mutationVariables);
    const freshMessages = useChatSessionStore.getState().messages;
    const loadingAiMessageId = findLastLoadingAiMessageId(freshMessages);

    const message = "AI response failed, please try again.";
    const errorMessages = error?.response?.data?.message;

    if (loadingAiMessageId) {
      updateMessage(loadingAiMessageId, {
        isLoading: false,
        error: `Error: ${message}`,
      });
    }

    if (errorMessages) {
      toast.error(errorMessages, {
        style: {
          borderLeft: "4px solid red",
          fontFamily: "var(--font-unilever)",
          fontSize: "12px",
        },
      });
    }
    setIsAiResponding(false);
  };

  const { mutate: regenerateChatMutation } = useMutateHandler({
    endUrl: "chats/regenerate_response",
    method: HTTPMethod.POST,
    onSuccess: (response: any) => {
      const aiMessage = {
        id: response.data.ai_message_id,
        message: response.data.ai_response,
        ai_model_id: response.data.ai_model_id,
        ai_model_name: response.data.ai_model_name,
        persona_id: response.data.persona_id,
        persona_name: response.data.persona_name,
        user_feedback: response.data.user_feedback,
        isLoading: false,
        error: undefined,
        role: "AI",
        chat: response.data.chat_session_uuid,
        createdAt: response.data.created_at,
        updatedAt: response.data.updated_at,
      };
      const freshMessages = useChatSessionStore.getState().messages;
      const loadingAiMessageId = findLastLoadingAiMessageId(freshMessages);
      if (loadingAiMessageId) {
        removeMessage(loadingAiMessageId);
      }
      addMessage(aiMessage);
      setIsAiResponding(false);
    },
    onError: onMutationError,
  });

  const { mutate: editChatMutation } = useMutateHandler({
    endUrl: "chats/edit_message",
    method: HTTPMethod.POST,
    onSuccess: (response: any) => {
      const aiMessage = {
        id: response.data.ai_message_id,
        message: response.data.ai_response,
        ai_model_id: response.data.ai_model_id,
        ai_model_name: response.data.ai_model_name,
        persona_id: response.data.persona_id,
        persona_name: response.data.persona_name,
        user_feedback: response.data.user_feedback,
        isLoading: false,
        error: undefined,
        role: "AI",
        chat: response.data.chat_session_uuid,
        createdAt: response.data.created_at,
        updatedAt: response.data.updated_at,
      };
      const freshMessages = useChatSessionStore.getState().messages;
      const loadingAiMessageId = findLastLoadingAiMessageId(freshMessages);
      if (loadingAiMessageId) {
        removeMessage(loadingAiMessageId);
      }
      addMessage(aiMessage);
      setIsAiResponding(false);
    },
    onError: onMutationError,
  });

  const { mutate: userFeedbackMutation } = useMutateHandler({
    endUrl: "chats/ai-feedback",
    method: HTTPMethod.POST,
    onSuccess: (response: any) => {
      console.log("Feedback submitted:", response);
    },
    onError: (error) => {
      console.error("Feedback submission failed:", error);
    },
  });

  const handleSendMessage = async (messageText: string, files?: File[]) => {
    if (!selectedSkillId || !selectedAiModelId) {
      console.error("Skill ID or AI Model ID is missing.");
      setIsAiResponding(false);
      return;
    }

    const isNew = isNewChatSession;
    const effectiveChatId = isNew ? crypto.randomUUID() : chatSessionId;

    if (!effectiveChatId) {
      console.error("Chat ID is missing, cannot send message.");
      return;
    }

    const tempUserId = Date.now();
    const userMessage: ChatMessage = {
      id: tempUserId,
      message: messageText,
      role: "user",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      chat: effectiveChatId,
      isLoading: false,
      error: undefined,
      files: files?.map((file) => ({
        id: Date.now() + Math.random(),
        file_name: file.name,
        file_type: file.type,
        file_path: URL.createObjectURL(file),
      })),
    };

    const tempAiId = Date.now() + 1;
    const aiOptimisticMessage: ChatMessage = {
      id: tempAiId,
      message: "",
      role: "ai",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      chat: effectiveChatId,
      isLoading: true,
      error: undefined,
      files: [],
    };

    addMessage(userMessage);
    addMessage(aiOptimisticMessage);
    setIsAiResponding(true);

    const chatPayload = {
      userMessage: messageText,
      skillId: selectedSkillId,
      aiModelId: selectedAiModelId,
      chatSessionUUID: effectiveChatId,
      isNewChat: isNew,
      personaId: selectedRole ? Number(selectedRole.value) : null,
    };

    const formData = new FormData();
    formData.append("payload", JSON.stringify(chatPayload));

    if (files && files.length > 0) {
      files.forEach((file) => {
        formData.append("files", file, file.name);
      });
    }

    const handleFailure = (err?: any) => {
      console.error("Send message failed:", err);
      updateMessage(tempUserId, {
        error: "Failed to send. Please try again.",
      });
      removeMessage(tempAiId);
      setIsAiResponding(false);
    };

    try {
      const response = await axiosInstance.postForm(
        `${baseURL}chats/`,
        formData
      );

      if (response.status === 200 || response.status === 201) {
        // if (isNew) {
        //   navigate(`/chat/${effectiveChatId}`, { replace: true });
        // }
        const result = response.data?.data;
        const aiMessage = {
          id: result.ai_message_id,
          message: result.ai_response,
          ai_model_id: result.ai_model_id,
          ai_model_name: result.ai_model_name,
          persona_id: result.persona_id,
          persona_name: result.persona_name,
          user_feedback: result.user_feedback,
          isLoading: false,
          error: undefined,
          role: "AI",
          chat: result.chat_session_uuid,
          createdAt: result.created_at,
          updatedAt: result.updated_at,
        };
        const freshMessages = useChatSessionStore.getState().messages;
        const loadingAiMessageId = findLastLoadingAiMessageId(freshMessages);
        if (loadingAiMessageId) {
          removeMessage(loadingAiMessageId);
        }
        addMessage(aiMessage);
        setIsAiResponding(false);

        if (isNew) {
          const chatData = response.data?.data;
          if (chatData) {
            setChatSessionId(effectiveChatId, chatData.title);
          }
          queryClient.invalidateQueries({ queryKey: ["recent-chats-list"] });
        }
      } else {
        handleFailure(new Error(`Unexpected status code: ${response.status}`));
      }
    } catch (error) {
      onMutationError(error, { optimisticAiMessageId: tempAiId });
    }
  };

  const handleRegenerateResponse = (
    messageToRegenerate: ChatMessage,
    newModelId?: number
  ) => {
    if (!chatSessionId || !selectedSkillId) {
      alert("Cannot regenerate: Missing session or skill ID.");
      return;
    }
    const modelToUse =
      newModelId || messageToRegenerate.ai_model_id || selectedAiModelId;
    if (!modelToUse) {
      alert("Cannot regenerate: AI model ID not determined.");
      return;
    }

    const allMessages = useChatSessionStore.getState().messages;
    const msgId = messageToRegenerate.id;
    const updatedMessages = allMessages.map((msg) =>
      msg.id === msgId ? { ...msg, isLoading: true } : msg
    );
    replaceMessages(updatedMessages);

    let previousUserMessage: ChatMessage | undefined;
    for (let i = allMessages.length - 1; i >= 0; i--) {
      if (allMessages[i].id === messageToRegenerate.id) {
        for (let j = i - 1; j >= 0; j--) {
          if (allMessages[j].role.toLowerCase() === "user") {
            previousUserMessage = allMessages[j];
            break;
          }
        }
        break;
      }
    }

    //drop all message after the message to regenerate
    if (previousUserMessage) {
      const updatedMessages = allMessages.filter(
        (msg) => msg.id <= messageToRegenerate.id
      );
      replaceMessages(updatedMessages);
    }

    if (!previousUserMessage) {
      console.error(
        "Could not find the original user message for regeneration."
      );
      alert("Error: Could not determine the context for regeneration.");
      return;
    }

    updateMessage(messageToRegenerate.id, {
      isLoading: true,
      message: "",
      error: undefined,
      ai_model_id: modelToUse,
    });
    setIsAiResponding(true);

    regenerateChatMutation({
      chat_session_uuid: chatSessionId,
      chat_id: previousUserMessage.id,
      message: previousUserMessage.message,
      skill_id: selectedSkillId,
      update_request: false,
      update_response: true,
      ai_model_id: newModelId || selectedAiModelId,
      persona_id: selectedRole ? Number(selectedRole.value) : null,
    });
  };

  const handleSaveEditedMessage = (
    originalMessage: ChatMessage,
    newText: string
  ) => {
    if (!chatSessionId || !selectedSkillId || !selectedAiModelId) {
      alert("Cannot save edit: Missing session, skill, or model ID.");
      return;
    }

    const tempAiId = Date.now() + 1;
    const aiLoadingMessage: ChatMessage = {
      id: tempAiId,
      message: "",
      role: "ai",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      chat: chatSessionId,
      isLoading: true,
      error: undefined,
    };

    optimisticallyUpdateMessagesForEdit(
      originalMessage,
      newText,
      aiLoadingMessage
    );
    setEditingMessageId(null);
    setIsAiResponding(true);

    editChatMutation({
      chat_session_uuid: chatSessionId,
      chat_id: originalMessage.id,
      message: newText,
      skill_id: selectedSkillId,
      update_request: true,
      update_response: false,
      ai_model_id: selectedAiModelId,
      persona_id: selectedRole ? Number(selectedRole.value) : null,
    });
  };

  const handleSubmitFeedback = (message: ChatMessage, isGood: boolean) => {
    if (!chatSessionId) {
      alert("Cannot submit feedback: No active session.");
      return;
    }

    const currentFeedback = message.user_feedback;
    const newFeedbackState = currentFeedback === isGood ? null : isGood;

    updateMessage(message.id, { user_feedback: newFeedbackState });

    userFeedbackMutation({
      chat_session_uuid: chatSessionId,
      chat_id: message.id,
      feedback: newFeedbackState,
    });
  };

  return {
    handleSendMessage,
    handleRegenerateResponse,
    handleSaveEditedMessage,
    handleSubmitFeedback,
  };
};
