import React, { useEffect, useRef, useState } from "react";
import ChatMessageBubble from "./ChatMessageBubble";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import type ChatMessage from "./ChatMessageModel";
import { useWorkspaceStore } from "@/@logic/workspaceStore";

interface ChatMessagesProps {
  messages: ChatMessage[];
  chatSessionId: number;
  avatar?: string;
  name?: string;
  onSendMessage: (message: string) => void;
  setMessages: (messages: ChatMessage[]) => void;
  aiModelsId: number;
}

const ChatMessages: React.FC<ChatMessagesProps> = ({
  messages,
  avatar,
  chatSessionId,
  name,
  onSendMessage,
  setMessages,
  aiModelsId,
}) => {
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editedText, setEditedText] = useState("");
  const thinkingText = "Thinking...";
  const endOfMessagesRef = useRef<HTMLDivElement | null>(null);

  const { selectedSkillId } = useWorkspaceStore();

  const regenerateChat = useMutateHandler({
    endUrl: "chats/regenerate_response?user_id=1",
    method: HTTPMethod.POST,
    onSuccess: (response: any) => {
      if (
        response.data &&
        response.data.messages &&
        Array.isArray(response.data.messages)
      ) {
        setMessages(response.data.messages);
      }
    },
  });

  const editChat = useMutateHandler({
    endUrl: "chats/edit_message?user_id=1",
    method: HTTPMethod.POST,
    onSuccess: (response: any) => {
      if (
        response.data &&
        response.data.messages &&
        Array.isArray(response.data.messages)
      ) {
        setMessages(response.data.messages);
      }
    },
  });

  const userFeedback = useMutateHandler({
    endUrl: "chats/ai-feedback?user_id=1",
    method: HTTPMethod.POST,
    onSuccess: (response: any) => {
      console.log(response);
    },
  });

  useEffect(() => {
    if (endOfMessagesRef.current) {
      endOfMessagesRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleCopy = async (text: string, id: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 3000);
    } catch (err) {
      console.error("Failed to copy text:", err);
    }
  };

  const regenerateResponse = (msg: ChatMessage) => {
    const msgId = msg.id;
    
    const updatedMessages = messages.map((msg) =>
      msg.id === msgId ? { ...msg, isLoading: true } : msg
    );
    setMessages(updatedMessages);
    
    const prev = messages
      .filter((m) => m.id < msgId)
      .sort((a, b) => b.id - a.id)[0];

    const prevId = prev?.id;    

    regenerateChat.mutate({
      chat_session_id: chatSessionId,
      chat_id: prevId,  
      message: "",
      skill_id: selectedSkillId,
      update_request: false,
      update_response: true,
      ai_model_id: aiModelsId
    });
  };

  const handleSave = (message: ChatMessage) => {
    const messageId = message.id;
    
    const updatedMessages = messages.filter((msg) => msg.id < messageId);
    setMessages([
      ...updatedMessages,
      { ...message, message: editedText },
      { ...message, role: "MSB_Admin", isLoading: true },
    ]);
    setEditingId(null);
    setEditedText("");
    
    editChat.mutate({
      chat_session_id: chatSessionId,
      chat_id: messageId, 
      message: editedText,
      skill_id: selectedSkillId,
      update_request: true,
      update_response: false,
      ai_model_id: aiModelsId
    });
  };

  const handleFeedback = (message: any, isGood: boolean) => {
    const messageId = message.id;
    
    if (message.user_feedback === null || message.user_feedback !== isGood) {
      const updatedMessages = messages.map((msg) =>
        msg.id === messageId ? { ...msg, user_feedback: isGood } : msg
      );
      setMessages(updatedMessages);
    } else if (message.user_feedback === isGood) {
      const updatedMessages = messages.map((msg) =>
        msg.id === messageId ? { ...msg, user_feedback: null } : msg
      );
      setMessages(updatedMessages);
    }
    
    const feedbackValue = message.user_feedback === isGood ? false : isGood;
    
    userFeedback.mutate({
      chat_session_id: chatSessionId,
      chat_id: messageId,  
      feedback: feedbackValue,
    });
  };

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      textarea.style.height = `${Math.min(textarea.scrollHeight, 150)}px`;
    }
  }, [editedText]);

  return (
    <div className="flex-1 overflow-y-auto scroll-auto scrollbar-transparent-track mt-4">
      <div className="flex flex-col gap-4 w-[58vw] mx-auto">
        {messages.map((msg) => (
          <ChatMessageBubble
            key={msg.id}
            msg={msg}
            avatar={avatar}
            editingId={editingId}
            copiedId={copiedId}
            editedText={editedText}
            thinkingText={thinkingText}
            textareaRef={textareaRef}
            onStartEdit={(id, val) => {
              setEditingId(id);
              setEditedText(val);
            }}
            onSaveEdit={handleSave}
            onCancelEdit={() => {
              setEditingId(null);
              setEditedText("");
            }}
            onEditText={setEditedText}
            onCopy={handleCopy}
            onFeedback={handleFeedback}
            onRegenerate={regenerateResponse}
          />
        ))}
        <div ref={endOfMessagesRef} />
      </div>
    </div>
  );
};

export default ChatMessages;