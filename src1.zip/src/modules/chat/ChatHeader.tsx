import React from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import DropdownSelect from "@/shared/chatdropDown";
import { rolePlay } from "@/constant/role-play";
import { modelList } from "@/constant/models";

type Option = { value: string | number; label: string };
type WorkspaceOption = Option & { skills: Option[] };

interface ChatHeaderProps {
  workspaces: WorkspaceOption[];
  workspaceId?: number;
  skillOptions: Option[];
  skillId?: number;
  gptModels: string[];
  selectedModel: string;
  setSelectedModel: (value: string) => void;
  selectedRole: any;
  setSelectedRole: (value: any) => void;
  onWorkspaceChange: (id: number) => void;
  onSkillChange: (id: number) => void
  chatTitle: string;
}


const ChatHeader: React.FC<ChatHeaderProps> = ({
  workspaces,
  workspaceId,
  skillOptions,
  skillId,
  gptModels,
  selectedModel,
  setSelectedModel,
  selectedRole,
  setSelectedRole,
  onWorkspaceChange,
  onSkillChange,
  chatTitle,
}) => {
  const mappedWorkspaceItems = workspaces.map(ws => ({
    label: ws.label,
    value: String(ws.value), // convert to string for compatibility
  }));

  const mappedSkillItems = skillOptions.map(skill => ({
    label: skill.label,
    value: String(skill.value),
  }));

  return(
  <div className="flex items-center mt-2 w-full">
    <div className="mx-auto flex">
      {/* Workspace Select */}
      <Tooltip>
        <TooltipTrigger>
        <DropdownSelect
              title="Select Workspace"
              items={mappedWorkspaceItems}
              searchPlaceholder="Search workspaces"
              groupTitle="Workspaces"
              defaultValue={workspaceId ? String(workspaceId) : "Select Workspace"}
              onValueChange={(value: string) => onWorkspaceChange(Number(value))}
              className="min-w-[120px] transparent"
            />
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={4} disableArrow>
          <p>Workspace</p>
        </TooltipContent>
      </Tooltip>

      <div className="flex px-2 text-gray-500">/</div>

      {/* Skill Select */}
      <Tooltip>
        <TooltipTrigger>
        <DropdownSelect
              title="Select Skills"
              items={mappedSkillItems}
              searchPlaceholder="Search skills"
              groupTitle="Skills"
              defaultValue={skillId ? String(skillId) : "Select skills"}
              onValueChange={(value: string) => onSkillChange(Number(value))}
              className="min-w-[120px] transparent"
            />
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={4} disableArrow>
          <p>Skill</p>
        </TooltipContent>
      </Tooltip>

      <div className="flex px-2 text-gray-500">/</div>

      {/* Chat Title */}
      <Tooltip>
        <TooltipTrigger>
          <div className="text-[12px] font-medium bg-gradient-to-t from-[#1F36C7] to-[#697DFF] bg-clip-text text-transparent">
            {chatTitle}
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={4} disableArrow>
          <p>Chat</p>
        </TooltipContent>
      </Tooltip>
    </div>

    <div className="flex gap-2 md:flex-col lg:flex-row">
      {/* Persona */}
      <Tooltip>
        <TooltipTrigger>
          <DropdownSelect
            key={selectedRole?.name}
            title="Select Role"
            items={rolePlay}
            searchPlaceholder="Search"
            groupTitle="Role Play"
            defaultValue={selectedRole}
            onValueChange={setSelectedRole}
            disableSearch={true}
          />
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={4} disableArrow>
          <p>Persona</p>
        </TooltipContent>
      </Tooltip>

      {/* Model */}
      <Tooltip>
        <TooltipTrigger>
          <DropdownSelect
            title="Select Model"
            items={gptModels}
            searchPlaceholder="Search"
            groupTitle="Model"
            defaultValue={selectedModel}
            onValueChange={setSelectedModel}
            disableSearch={true}
          />
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={4} disableArrow>
          <p>Model</p>
        </TooltipContent>
      </Tooltip>
    </div>
  </div>
)};

export default ChatHeader;
