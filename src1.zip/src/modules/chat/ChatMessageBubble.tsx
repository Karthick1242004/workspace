import React from "react";
import markdownit from "markdown-it";
import { Sparkle, Info } from "lucide-react";
import ProfileImg from "../../assets/images/Male Avatar 11.png";
import ChatBubbleActions from "./ChatBubbleActions";
import LoadingBubble from "./LoadingBubble";
import EditBubble from "./EditBubble";
import ChatMessage from "./ChatMessageModel";
import { ChatImageViewer } from "./ChatImageViewer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useMsal } from "@azure/msal-react";
import { MarkdownWrapper } from "./MarkdownWrapper";

interface ChatMessageBubbleProps {
  msg: ChatMessage;
  avatar?: string;
  editingId: number | null;
  copiedId: number | null;
  editedText: string;
  thinkingText: string;
  textareaRef: React.RefObject<HTMLTextAreaElement | null>;
  onStartEdit: (id: number, text: string) => void;
  onSaveEdit: (msg: ChatMessage) => void;
  onCancelEdit: () => void;
  onEditText: (val: string) => void;
  onCopy: (text: string, id: number) => void;
  onFeedback: (message: ChatMessage, isGood: boolean) => void;
  onRegenerate: (message: ChatMessage) => void;
}

const ChatMessageBubble: React.FC<ChatMessageBubbleProps> = ({
  msg,
  avatar,
  editingId,
  copiedId,
  editedText,
  thinkingText,
  textareaRef,
  onStartEdit,
  onSaveEdit,
  onCancelEdit,
  onEditText,
  onCopy,
  onFeedback,
  onRegenerate,
}) => {
  const isAI = ["msb_admin", "ai", "bot"].includes(msg.role.toLowerCase());
  const isUser = msg.role.toLowerCase() === "user";

  const { accounts } = useMsal();

  const name = accounts[0]?.name;

  return (
    <div
      className={`flex flex-1 gap-2 align-middle ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      {/* Left Avatar for AI/Admin */}
      {isAI && (
        <div className="rounded-full self-start text-white bg-[#1F36C7] p-2">
          <Sparkle size={20} />
        </div>
      )}

      {/* Main Bubble */}
      <div className="relative group max-w-[89.5%]">
        {editingId === msg.id ? (
          <EditBubble
            textareaRef={textareaRef}
            value={editedText}
            onChange={onEditText}
            onSave={() => onSaveEdit(msg)}
            onCancel={onCancelEdit}
          />
        ) : msg.isLoading ? (
          <LoadingBubble thinkingText={thinkingText} />
        ) : (
          <div
            className={`border text-[13px] rounded-lg py-2 px-3 break-words text-justify ${
              isUser
                ? "bg-[#e2e6ff] border-[#AFBAFF]"
                : "bg-gray-100 border-[#d9deff]"
            }`}
          >
            {isUser ? (
              <>
                {msg.files && msg.files.length ? (
                  <div className="flex items-center gap-2">
                    {msg.files.map((file, index) => (
                      <ChatImageViewer key={index} file={file} />
                    ))}
                  </div>
                ) : (
                  <></>
                )}
                {msg.message}
              </>
            ) : (
              <>
                <MarkdownWrapper markdown={msg.message} />
                <div
                  className="flex items-center gap-2 w-fit p-1 mt-2"
                  style={{
                    background:
                      "linear-gradient(15deg, rgba(31, 54, 199, 0.05) 26.3%, rgba(105, 125, 255, 0.05) 86.4%)",
                    border: "1px solid rgb(223 227 255)",
                    borderRadius: "4px",
                  }}
                >
                  <Info size={15} color="#697DFF" />
                  <p className="text-[10px]">
                    AI Generated content. Please check for accuracy
                  </p>
                </div>
              </>
            )}
          </div>
        )}

        <ChatBubbleActions
          msg={msg}
          isAI={isAI}
          isUser={isUser}
          copiedId={copiedId}
          editingId={editingId}
          onCopy={onCopy}
          onEdit={onStartEdit}
          onFeedback={onFeedback}
          onRegenerate={onRegenerate}
        />
      </div>

      {/* Right Avatar for User */}
      {isUser && (
        <Avatar className="w-[35px] h-[35px]">
          <AvatarImage src={avatar} />
          <AvatarFallback className="bg-gray-600 text-white">
            {name
              ? name.split(", ")
                ? name.split(", ")[1][0]
                : name.split(" ")[0][0]
              : name?.charAt(0)}
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
};

export default ChatMessageBubble;
