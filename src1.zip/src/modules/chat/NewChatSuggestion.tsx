import { Button } from "@/components/ui/button";
import React from "react";
import GradientStrokeText from "./GradientText";
import { useWorkspaceStore } from "@/@logic/workspaceStore";

interface NewChatSuggestionProps {
  name?: string;
  onSendMessage: (message: string) => void;
  selectedSkillId?: number;
  workspaceId?: number;
}

export default function NewChatSuggestion({
  name,
  onSendMessage,
  selectedSkillId,
  workspaceId,
}: NewChatSuggestionProps) {
  const { workspaces } = useWorkspaceStore();

  function parseStringArray(input?: string): string[] {
    if (!input) return [];
    try {
      const inputArray = JSON.parse(input);
      if (Array.isArray(inputArray)) return inputArray;
      else return parseStringArray(inputArray);
    } catch (e) {
      console.error("Invalid JSON", e);
      return [];
    }
  }

  const questionString =
    workspaceId && selectedSkillId
      ? parseStringArray(
          workspaces
            .find((w) => w.id === workspaceId)
            ?.skills.find((s) => s.id === selectedSkillId)?.questions
        )
      : [];

  const skillName = workspaces
    .find((w) => w.id === workspaceId)
    ?.skills.find((s) => s.id === selectedSkillId)?.name;

  // Reusable handler
  const handleQuickMessage = (quickMsg: string) => {
    const trimmedMessage = quickMsg.trim();
    onSendMessage(trimmedMessage);
  };

  return (
    <>
      <div className="flex flex-col flex-1 items-center justify-center w-full">
        <GradientStrokeText text={`Hello ${name}`} />
        <p className="text-gray-600 mb-8 font-unilever text-xs">
          Tap into the expertise of{" "}
          <span className="font-unilever-medium">{skillName} Skill</span>, ask
          your questions!
        </p>

        <div className="flex gap-4 flex-wrap justify-center mt-[-1%]">
          {questionString && Array.isArray(questionString) ? (
            questionString.map((text: string, idx: number) => (
              <Button
                key={idx}
                variant="outline"
                className="text-xs rounded-[5px] px-3 border border-gray-200 bg-[#FBF6F8] py-3 font-unilever cursor-pointer"
                onClick={() => handleQuickMessage(text)}
                disabled={!selectedSkillId}
              >
                {text}
              </Button>
            ))
          ) : (
            <></>
          )}
        </div>
      </div>
    </>
  );
}
