import React from "react";
import ChatMessages from "./ChatMessages";
import NewChatSuggestion from "./NewChatSuggestion";
import ChatMessage from "./ChatMessageModel";

interface ChatBodyProps {
  showWelcome: boolean;
  messages: ChatMessage[];
  avatar?: string;
  name: string;
  chatId: number;
  onSendMessage: (message: string) => void;
  setMessages: (messages: ChatMessage[]) => void;
  selectedSkillId: number;
  workspaceId: number;
  aiModelsId: number;
}

const ChatBody: React.FC<ChatBodyProps> = ({
  showWelcome,
  messages,
  avatar,
  name,
  chatId,
  onSendMessage,
  setMessages,
  selectedSkillId,
  workspaceId,
  aiModelsId,
}) => {
  
  return showWelcome ? (
    <div className="flex flex-1 justify-center items-center overflow-auto w-full">
      <NewChatSuggestion
        selectedSkillId={selectedSkillId}
        workspaceId={workspaceId}
        name={name}
        onSendMessage={onSendMessage}
      />
    </div>
  ) : (
    <ChatMessages
      messages={messages}
      avatar={avatar}
      name={name}
      onSendMessage={onSendMessage}
      setMessages={setMessages}
      chatSessionId={chatId}
      aiModelsId={aiModelsId}
    />
  );
};

export default ChatBody;
