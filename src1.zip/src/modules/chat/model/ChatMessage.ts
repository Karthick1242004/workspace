export default interface ChatMessage {
  id: number;
  message: string;
  role: string;
  createdAt: string;
  updatedAt: string;
  chat: string;
  isLoading?: boolean;
  files?: {
    id: number;
    file_name: string;
    file_type: string;
    file_path: string;
  }[];
  ai_model_id?: number;
  user_feedback?: boolean | null;
  error?: string;
}