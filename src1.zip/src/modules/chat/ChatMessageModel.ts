export default interface ChatMessage {
    id: number;
    message: string;
    role:string,
    createdAt: string;
    updatedAt: string;
    chat: number;
    isLoading?:boolean;
    chat_id?: number;
    user_feedback?: boolean | null;
    chat_session_id?:number
    files?: {
      file_name: string;
      file_path: string;
      file_type: string;
      id: number;
    }[]
  }
  