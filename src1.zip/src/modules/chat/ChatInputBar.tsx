import React from "react";
import { MessageInput } from "@/shared/MessageInput";

interface ChatInputBarProps {
  onSendMessage: (message: string) => void;
  skillID: number;
  selectedImages: File[];
  setSelectedImages: React.Dispatch<React.SetStateAction<File[]>>;
  isAiResponding: boolean
}

const ChatInputBar: React.FC<ChatInputBarProps> = ({
  onSendMessage,
  skillID,
  selectedImages,
  setSelectedImages,
  isAiResponding
}) => (
  <div className="full flex justify-center items-end z-50">
    <MessageInput
      onSendMessage={onSendMessage}
      skillID={skillID}
      selectedImages={selectedImages}
      setSelectedImages={setSelectedImages}
      isAiResponding={isAiResponding}
    />
  </div>
);

export default ChatInputBar;
