import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import WorkSpace from "@/modules/workspace/workspace";
import { useWorkspaceStore, Workspace } from "@/@logic/workspaceStore";
import { useParams } from "react-router-dom";
import { useNavigation } from "@/hooks/navigationHook";

export default function WorkspaceCategoryTabs() {
  const { workspaces = [] } = useWorkspaceStore();
  const { navigateTo } = useNavigation();
  const { workspacecategory } = useParams();    
  const activeTab = workspacecategory || 'my-workspace'
  
  function groupWorkspaceByCategory(workspaces: Workspace[]) {
    const groupedWorkspaces: { [category: string]: Workspace[] } = {};
    if(!workspaces) return groupedWorkspaces;
    workspaces.forEach((workspace) => {
      const category = workspace.category;
      if (!groupedWorkspaces[category as string]) {
        groupedWorkspaces[category as string] = [];
      }
      groupedWorkspaces[category as string].push(workspace);
    });
    return groupedWorkspaces;
  }

  const data = groupWorkspaceByCategory(workspaces);
  const handleTabChange = (value: string) =>{
    if(value === 'my-workspace')
    {
      navigateTo({ path: '/workspace/my-workspace' })
    }
    else{
      navigateTo({ path: `/workspace/${value}` })
    }
  }


  return (
    <Tabs defaultValue="my-workspace" value={activeTab} onValueChange={handleTabChange} className="flex w-full h-full max-w-[var(--max-content-width)] mx-auto">
      <TabsList className="h-[36px] bg-white">
        <TabsTrigger value="my-workspace" className="cursor-pointer !text-[clamp(10px,12px,14px)]">My AI Workspace</TabsTrigger>
        {
          Object.keys(data).map((category) => {
            if(category.toLowerCase() === "private") return null;
            return <TabsTrigger key={category} value={category} className="cursor-pointer !text-[clamp(10px,12px,14px)]">
              {category}
            </TabsTrigger>
        })
        }
      </TabsList>
      <TabsContent value="my-workspace" className="overflow-auto">
        {workspaces && <WorkSpace workspacesData={data["Private"]} isLoading={false} selectedCategory="Private"/>}
      </TabsContent>
      {
        Object.keys(data).map((category) => {
          if(category === "private") return null;
          return <TabsContent key={category} value={category} className="overflow-auto">
            {data[category] && <WorkSpace workspacesData={data[category]} isLoading={false} selectedCategory={category}/>}
          </TabsContent>
        })
      }
    </Tabs>
);
}
