import React, { useState, useEffect } from "react";
import WorkspaceCard from "./workspace-card";
import WorkspaceDetails from "./workspace-details";
import { useWorkspaceStore, Workspace } from "@/@logic/workspaceStore";
import { Plus, Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import WorkspaceCreateModal from "./dynamic-form/components/WorkspaceCreate";
import { useForm } from "react-hook-form";
import { formConfigs, WorkspaceFormData } from "./dynamic-form/formtypes";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigation } from "@/hooks/navigationHook";
import { DropdownMenuCheckboxes } from "@/shared/DropdownMenuCheckboxes";
import nodata from "@/assets/images/noworkspace.png";
import WorkspaceTab from "./tab/workspace-tab";

interface WorkspaceProp {
  workspacesData: Workspace[];
  isLoading: boolean;
  selectedCategory: string;
}

export default function WorkSpace({
  workspacesData,
  selectedCategory,
}: WorkspaceProp) {
  const isLoading = useWorkspaceStore((state) => state.isLoading);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [columnCount, setColumnCount] = useState(3);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sortedWorkspaces, setSortedWorkspaces] = useState<Workspace[]>([]);
  const [currentSort, setCurrentSort] = useState("A-Z");
  const [activeTab, setActiveTab] = useState("created-by-me");
  const [filteredWorkspaces, setFilteredWorkspaces] = useState<Workspace[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  
  const queryClient = useQueryClient();
  const { navigateTo } = useNavigation();
  const config = formConfigs["workspace"];
  const formMethods = useForm<WorkspaceFormData>({
    defaultValues: config.defaultValues,
  });

  useEffect(() => {
    const updateColumnCount = () => {
      if (window.innerWidth >= 1280) {
        setColumnCount(3);
      } else {
        setColumnCount(2);
      }
    };
    updateColumnCount();
    window.addEventListener("resize", updateColumnCount);
    return () => window.removeEventListener("resize", updateColumnCount);
  }, []);

  useEffect(() => {
    if (workspacesData) {
      const filtered = filterWorkspaces(workspacesData, activeTab);
      setFilteredWorkspaces(filtered);
      handleSort(currentSort, filtered);
    }
  }, [workspacesData, activeTab, selectedCategory]);

  const filterWorkspaces = (workspaces: Workspace[], tab: string) => {
    if (!workspaces || !selectedCategory || selectedCategory !== "Private") {
      return workspaces;
    }
    return workspaces.filter((workspace) =>
      tab === "created-by-me"
        ? workspace.created_by_me
        : !workspace.created_by_me
    );
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const handleSort = (
    sortType: string,
    workspacesToSort = filteredWorkspaces
  ) => {
    let sorted = [...workspacesToSort];
    sorted.sort((a, b) => {
      if (a.is_favorited && !b.is_favorited) return -1;
      if (!a.is_favorited && b.is_favorited) return 1;

      switch (sortType) {
        case "A-Z":
          return a.name.localeCompare(b.name);
        case "Z-A":
          return b.name.localeCompare(a.name);
        default:
          return 0;
      }
    });
    setSortedWorkspaces(sorted);
    setCurrentSort(sortType);
  };

  const handleSelectCard = (idx: number) => {
    setSelectedIndex(selectedIndex === idx ? null : idx);
  };

  const getRowNumber = (index: number) => {
    return Math.floor(index / columnCount);
  };

  const renderCards = (visibleWorkspaces:Workspace[]) => {
    if (!visibleWorkspaces) return null;
    let content: React.ReactNode[] = [];
    const rows: Workspace[][] = [];
    for (let i = 0; i < visibleWorkspaces.length; i += columnCount) {
      rows.push(visibleWorkspaces.slice(i, i + columnCount));
    }
    rows.forEach((row, rowIndex) => {
      const rowCards = row.map((workspace, colIndex) => {
        const globalIndex = rowIndex * columnCount + colIndex;
        return (
          <div key={globalIndex} className="w-full h-full">
            <div
              className="cursor-pointer transition-all duration-300 ease-in-out h-full"
              onClick={() => handleSelectCard(globalIndex)}
            >
              <WorkspaceCard
                data={workspace as unknown as Workspace}
                isSelected={selectedIndex === globalIndex}
              />
            </div>
          </div>
        );
      });

      content.push(
        <div
          key={`row-${rowIndex}`}
          className="col-span-1 md:col-span-2 lg:col-span-2 xl:col-span-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4 auto-rows-fr"
        >
          {rowCards}
        </div>
      );

      const selectedInThisRow =
        selectedIndex !== null &&
        Math.floor(selectedIndex / columnCount) === rowIndex;
      if (selectedInThisRow) {
        content.push(
          <div
            key={`details-${rowIndex}`}
            className="col-span-1 md:col-span-2 lg:col-span-2 xl:col-span-3 w-full"
          >
            <WorkspaceDetails
              workspace={visibleWorkspaces[selectedIndex]}
            />
          </div>
        );
      }
    });

    return content;
  };

  const renderNoData = () => {
    return (
      <div className="col-span-full flex flex-col items-center justify-center w-full">
        <img
          src={nodata}
          alt="No workspace data present"
          className="w-96 xl:w-1/2 h-auto object-contain"
        />
        <p className="text-black mt-4 text-md font-unilever-medium">
          No workspaces
        </p>
        <p className="text-gray-500 mt-4 text-sm font-unilever">
          To get started, create a new workspace
        </p>
      </div>
    );
  };

  const renderSkeleton = () => {
    return Array(6)
      .fill(0)
      .map((_, index) => (
        <div key={`skeleton-${index}`} className="w-full">
          <Skeleton className="h-[170px] w-full rounded-lg" />
        </div>
      ));
  };


  const visibleWorkspaces = sortedWorkspaces.filter((workspace) => {
    const name = workspace.name?.toLowerCase() || "";
    const desc = workspace.description?.toLowerCase() || "";
    const q = searchQuery.toLowerCase();
    const matchesSearch = name.includes(q) || desc.includes(q);

    return matchesSearch 
  })
  


  return (
    <div className="p-3 rounded-xl h-full max-w-[var(--max-content-width)] mx-auto flex flex-col shadow-md overflow-y-auto custom-scrollbar font-unilever bg-white/60">
      <div className="flex justify-between">
        <p className="font-semibold mb-3 font-unilever-medium text-[14px] text-[#4B4B53]">
          AI Workspaces and Skills
        </p>
        <div className="flex flex-row gap-2">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              aria-label="Search Workspaces"
              placeholder="Search Workspaces"
              className="h-8.5 pl-6 pr-4 py-1 border-b border-gray-600 text-xs outline-none w-[260px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-0 top-2.5 h-4 w-4 text-gray-700 pointer-events-none" />
          </div>
          {selectedCategory === "Private" && (
            <WorkspaceTab
              workspaces={workspacesData}
              onTabChange={handleTabChange}
              value={activeTab}
            />
          )}
          <DropdownMenuCheckboxes onSort={handleSort} currentSort={currentSort} isWorkspace={true} />
          
          <button
            className="mb-3 cursor-pointer font-unilever text-xs flex flex-row gap-1 justify-center items-center text-white bg-[var(--workspace-color-highlight)] px-2 py-2 rounded-sm"
            onClick={() => setIsModalOpen(true)}
          >
            <Plus size={18} />
            Add Workspace
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4 overflow-y-auto">
        {isLoading ? renderSkeleton() : visibleWorkspaces.length > 0 ? (renderCards(visibleWorkspaces)) : (renderNoData())}
      </div>

      <WorkspaceCreateModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        config={config}
        selectedCategory={selectedCategory}
      />
    </div>
  );
}
