import React, { useEffect, useState, useMemo } from "react";
import {
  ChartLine,
  PencilLine,
  Trash2,
  UserRound,
  Eye,
  LoaderCircle,
  Pin,
} from "lucide-react";
import {
  Skill as StoreSkill,
  useWorkspaceStore,
} from "@/@logic/workspaceStore";
import { useFetchHandler } from "@/@logic/getHandlers";
import { useNavigation } from "@/hooks/navigationHook";
import Dot from "@/shared/dot/dot";
import { ProcessingStatus } from "../workspace-details";
import { toast } from "react-hot-toast";
import { generateReadableTimeStamp } from "@/utils/generateReadableTimeStamp";
import { cn } from "@/lib/utils";
import axiosInstance from "@/utils/axiosInstance";
import { Skeleton } from "@/components/ui/skeleton";
import FallbackLogo from "../../../assets/icons/artificial-intelligence-brain_svgrepo.com.svg";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import { useQueryClient } from "@tanstack/react-query";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import Strokepin from "@/assets/icons/Stroke Pin.svg";
import Filledpin from "@/assets/icons/Filled pin.svg";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import BigTrash from "@/assets/icons/CheckCircle.svg";
import DeleteDialog from "@/shared/DeleteDialog";
import { useChatSessionStore } from "@/modules/chat/store/chatSessionStore";
import { usageLoggerConstants } from "@/constant/usageLogger";
import { useUsageLogger } from "@/utils/usageLogger";
import { access } from "fs";

type Skill = StoreSkill & {
  is_favorited?: boolean;
};

interface WorkspaceSkillCardProps {
  skill: Skill;
  workspaceId: number;
}

function WorkspaceSkillCard({
  skill: initialSkill,
  workspaceId,
}: WorkspaceSkillCardProps) {
  const { navigateTo } = useNavigation();
  const [isFavoriteLoading, setIsFavoriteLoading] = useState<boolean>(false);
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const usageLogger = useUsageLogger();
  const queryClient = useQueryClient();
  const [isLoading, setIsLoading] = useState({
    status: false,
    message: "",
  });
  const [forceUpdate, setForceUpdate] = useState(0);

  // logo fetch
  const { data: skillLogo, isLoading: logoIsLoading } = useFetchHandler(
    `/skills/logo/${initialSkill.id}/download`,
    `${initialSkill.id}-logo-${initialSkill.updated_at}`,
    true,
    true,
    false,
    0
  );
  const logoUrl = skillLogo ? URL.createObjectURL(skillLogo) : FallbackLogo;
  const isSkill = true;
  const {
    workspaces,
    setSelectedSkillId,
    setSelectedWorkspaceId,
    updateSkillStatus,
    isLoading: isWorkspaceLoading,
    favoriteSkill,
    deleteSkill,
  } = useWorkspaceStore();

  const { startNewChatSession } = useChatSessionStore();

  const deleteMutation = useMutateHandler({
    endUrl: "skills/delete",
    method: HTTPMethod.POST,
  });

  const latestSkill = useMemo(() => {
    for (const workspace of workspaces) {
      const foundSkill = workspace.skills.find((s) => s.id === initialSkill.id);
      if (foundSkill) return foundSkill;
    }
    return initialSkill;
  }, [workspaces, initialSkill.id, forceUpdate]);

  const skill = latestSkill;

  const currentSkillStatus = useWorkspaceStore((state) => {
    for (const workspace of state.workspaces) {
      const skill = workspace.skills.find((s) => s.id === initialSkill.id);
      if (skill) return skill.processing_status;
    }
    return initialSkill.processing_status;
  });

  const favoriteMutation = useMutateHandler({
    endUrl: "skills/favorite",
    method: HTTPMethod.POST,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workspace"] });
      favoriteSkill(skill.id, !skill.is_favorited);
      setIsFavoriteLoading(false);
      usageLogger(
        `${skill.is_favorited ? "UnFavorited" : "Favorited"} the Skill`,
        "skill",
        skill.id
      );
    },
    onError: () => {
      setIsFavoriteLoading(false);
    },
  });

  const handleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFavoriteLoading(true);
    favoriteMutation.mutate({
      resource_id: skill.id,
      resource_type: "skill",
      is_favorite: !skill.is_favorited,
    });
  };
  useEffect(() => setForceUpdate((prev) => prev + 1), [currentSkillStatus]);

  useEffect(
    () => setIsFavoriteLoading(isWorkspaceLoading),
    [isWorkspaceLoading]
  );

  const isSuccess = currentSkillStatus;
  const isCompleted = currentSkillStatus === "Completed";
  const isFailed = currentSkillStatus === "Failed";
  const isProcessing =
    currentSkillStatus === "Pending" || currentSkillStatus === "Inprogress";

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigateTo({
      path: `/workspace/skill/edit/${skill.id}`,
      state: {
        skill,
        type: "skill",
        workspaceId: skill.workspace?.toString() || "",
        accessLevel: skill.access_level,
        // workspaceAccessLevel: workspace
      },
    });
  };
  const handleViewClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigateTo({
      path: `/workspace/skill/view/${skill.id}`,
      state: {
        skill,
        viewAccess: true,
      },
    });
  };

  const handleAnalyticsClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigateTo({
      path: `/analytics/workspace/${workspaceId}/skill/${skill.id}`,
      state: {
        skill_id: skill.id,
        workspace_id: workspaceId,
        accessLevel: skill.access_level,
        workspaceAccessLevel: workspaces.find(
          (items) => workspaceId === items.id
        )?.access_level,
      },
    });
  };

  const handleCheckStatus = async (e: React.MouseEvent): Promise<boolean> => {
    e.preventDefault();
    setIsLoading({
      status: true,
      message: "Checking skill status...",
    });

    try {
      const response = await axiosInstance.get(
        `/skills/${skill.id}/rag-status`
      );
      if (response.status !== 200) {
        throw new Error("Network response was not ok");
      }

      const data = response.data.data;

      if (
        data &&
        data.processing_status.toLowerCase() === "completed" &&
        data.is_processed_for_rag
      ) {
        updateSkillStatus(
          skill.id,
          data.processing_status as ProcessingStatus,
          !!data.is_processed_for_rag,
          data.updated_at
        );
        setForceUpdate((prev) => prev + 1);
        return true;
      } else if (
        data &&
        data.processing_status.toLowerCase() === "inprogress"
      ) {
        toast("Skill is still processing. Please try again later.", {
          duration: 3000,
          style: {
            borderLeft: `4px solid #FEBE10`,
            fontFamily: "var(--font-unilever)",
            fontSize: "14px",
          },
        });
        return false;
      } else if (data && data.processing_status.toLowerCase() === "failed") {
        toast("Skill processing failed. Please try again later.", {
          duration: 3000,
          style: {
            borderLeft: `4px solid red`,
            fontFamily: "var(--font-unilever)",
            fontSize: "14px",
          },
        });
        return false;
      }
      return false;
    } catch (err: any) {
      toast(`Error: ${err.response?.data?.message || err.message}`, {
        duration: 3000,
        style: {
          borderLeft: `4px solid red`,
          fontFamily: "var(--font-unilever)",
          fontSize: "14px",
        },
      });
      return false;
    } finally {
      setIsLoading({
        status: false,
        message: "",
      });
    }
  };

  const handleCardClick = async (e: any) => {
    const ragStatus = await handleCheckStatus(e);

    if (ragStatus) {
      setSelectedWorkspaceId(workspaceId);
      setSelectedSkillId(skill.id);
      startNewChatSession();
      navigateTo({
        path: `/chat`,
        state: {
          rag_status: ragStatus,
        },
      });
    }
  };

  const handleDelete = (id: string | number) => {
    if (!id) return;
    deleteMutation.mutate(
      {
        skill_id: id,
      },
      {
        onSuccess: (data) => {
          queryClient.invalidateQueries({ queryKey: ["workspace"] });
          toast.success("Skill deleted successfully.", {
            duration: 3000,
            style: {
              borderLeft: `4px solid green`,
              fontFamily: "var(--font-unilever)",
              fontSize: "14px",
            },
          });
          deleteSkill(Number(id));
          usageLogger(`${usageLoggerConstants.delete.skill} ${Number(id)}`);
        },
        onError: (error) => {
          toast.success("Error deleting skill. Please try again." + error, {
            duration: 3000,
            style: {
              borderLeft: `4px solid red`,
              fontFamily: "var(--font-unilever)",
              fontSize: "14px",
            },
          });
        },
      }
    );
  };

  return (
    <div
      className={cn(
        "relative transition-all h-full border border-[#CBE0FF] rounded-lg p-3 cursor-default group flex flex-row gap-4 items-center bg-[#F4F8FF] hover:shadow-lg"
      )}
      onClick={handleCardClick}
    >
      {/* Loading overlay */}
      {isLoading.status && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/70 rounded-lg border border-blue-200">
          <span className="text-sm font-semibold text-[var(--workspace-color-highlight)] px-4 py-1 rounded-lg border border-[var(--workspace-color-highlight)] bg-white shadow">
            {isLoading.message}
          </span>
        </div>
      )}

      {/* Left: Main content */}
      <div
        className={cn(
          "flex flex-col flex-1 min-w-0 h-full cursor-pointer",
          isLoading.status && "blur-[2px] pointer-events-none select-none"
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-start gap-2">
            <h3
              className={cn(
                "font-semibold text-sm text-[var(--workspace-color-highlight)] mt-0.5 font-unilever-medium max-w-[160px] truncate"
              )}
              title={skill.name}
            >
              {skill.name}
            </h3>

            <button
              onClick={handleFavorite}
              className={`text-xs  cursor-pointer ${
                !skill.is_favorited
                  ? " opacity-0 transition delay-100  group-hover:opacity-100"
                  : "opacity-100"
              }`}
            >
              {isFavoriteLoading ? (
                <LoaderCircle
                  color="var(--workspace-color-highlight)"
                  className="animate-spin w-3"
                />
              ) : skill.is_favorited ? (
                <Pin fill="var(--workspace-color-highlight)" className="w-4" />
              ) : (
                <Pin color="var(--workspace-color-highlight)" className="w-4" />
              )}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <div
            className={cn(
              "flex items-center gap-1 px-2 py-1 rounded-full text-[clamp(10px,11px,14px)] text-[var(--workspace-color-highlight)] bg-[var(--workspace-color-bg-light)]"
            )}
            title={skill.created_by}
          >
            <UserRound size={14} />
            {skill.created_by?.length > 12
              ? `${skill.created_by.substring(0, 12)}...`
              : skill.created_by}
          </div>
          <div className="flex items-center gap-1 px-2 py-1 rounded-full text-[clamp(10px,11px,14px)] bg-[var(--workspace-color-bg-light)] text-[var(--workspace-color-highlight)]">
            <Dot bgcolor="bg-[var(--workspace-color-highlight)]" />
            {skill.chat_sessions_count ?? 0} Chats
          </div>
        </div>
        <p className="text-[clamp(10px,12px,14px)] text-gray-500 flex-grow mb-1 line-clamp-3 overflow-hidden max-h-[4.6em] leading-[1.5em]">
          {skill.description}
        </p>

        <div className="flex items-center gap-4 mt-auto pt-2">
          {skill.access_level === "owner" ? (
            <div className="absolute top-3 right-5">
              <Tooltip>
                <TooltipTrigger>
                  <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="bg-white rounded-sm border border-blue-200 p-1 text-xs text-red-500 opacity-0 group-hover:opacity-100 transition cursor-pointer"
                        aria-label="Delete skill"
                      >
                        <Trash2 size={16} />
                      </div>
                    </DialogTrigger>
                    <DialogContent
                      className="sm:max-w-[480px] bg-white"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <DeleteDialog
                        setIsDialogOpen={setIsDialogOpen}
                        handleDelete={handleDelete}
                        itemType="skill"
                        skill={skill}
                        isSkill={isSkill}
                      />
                    </DialogContent>
                  </Dialog>
                </TooltipTrigger>
                <TooltipContent side="bottom" sideOffset={2} disableArrow>
                  <p>Delete</p>
                </TooltipContent>
              </Tooltip>
            </div>
          ) : null}
          {skill.updated_at && (
            <span
              className={cn(
                "text-[clamp(10px,12px,14px)] text-[var(--workspace-color-highlight)] flex-grow"
              )}
            >
              Last Modified on:
              {` ${generateReadableTimeStamp(skill.updated_at)}`}
            </span>
          )}
        </div>
      </div>

      {/* Right: Logo */}
      <div className="flex-shrink-0 w-[90px] h-full flex flex-col items-center justify-start rounded-md  ml-2">
        {/* {isSuccess && ( */}
        <div className="absolute right-5 top-4 mt-[-0.5rem] flex flex-row rounded-sm border border-blue-200 bg-white opacity-0 group-hover:opacity-100 transition">
          {(skill.access_level === "owner" ||
            skill.access_level === "editor") && (
            <Tooltip>
              <TooltipTrigger>
                <div
                  onClick={handleEditClick}
                  className="p-1 text-xs text-[var(--workspace-color-highlight)] rounded-l-sm  cursor-pointer"
                  aria-label="Edit skill"
                >
                  <PencilLine size={16} />
                </div>
              </TooltipTrigger>
              <TooltipContent side="bottom" sideOffset={2} disableArrow>
                <p>Edit</p>
              </TooltipContent>
            </Tooltip>
          )}
          {(skill.access_level === "owner" ||
            skill.access_level === "editor") && (
            <Tooltip>
              <TooltipTrigger>
                <div
                  onClick={handleViewClick}
                  className="p-1 text-[var(--workspace-color-highlight)]  cursor-pointer"
                  aria-label="Skill Stats"
                  tabIndex={-1}
                >
                  <Eye size={16} />
                </div>
              </TooltipTrigger>
              <TooltipContent side="bottom" sideOffset={2} disableArrow>
                <p>View</p>
              </TooltipContent>
            </Tooltip>
          )}
          <Tooltip>
            <TooltipTrigger>
              <div
                onClick={handleAnalyticsClick}
                className="p-1 text-[var(--workspace-color-highlight)]  cursor-pointer"
                aria-label="Skill Stats"
                tabIndex={-1}
              >
                <ChartLine size={16} />
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" sideOffset={2} disableArrow>
              <p>Analytics</p>
            </TooltipContent>
          </Tooltip>
          {skill.access_level === "owner" && (
            <Tooltip>
              <TooltipTrigger>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <div
                      onClick={(e) => e.stopPropagation()}
                      className="p-1 text-xs text-red-500 rounded-r-sm cursor-pointer"
                      aria-label="Delete skill"
                    >
                      <Trash2 size={16} />
                    </div>
                  </DialogTrigger>
                  <DialogContent
                    className="sm:max-w-[480px] bg-white"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <DeleteDialog
                      setIsDialogOpen={setIsDialogOpen}
                      handleDelete={handleDelete}
                      itemType="skill"
                      skill={skill}
                      isSkill={isSkill}
                    />
                  </DialogContent>
                </Dialog>
              </TooltipTrigger>
              <TooltipContent side="bottom" sideOffset={2} disableArrow>
                <p>Delete</p>
              </TooltipContent>
            </Tooltip>
          )}
        </div>
        {/* )} */}

        {logoIsLoading ? (
          <Skeleton
            className={`w-[75px] h-[75px] rounded-md bg-gray-200  ${
              isSuccess ? "mt-3" : "mt-7"
            }`}
          />
        ) : (
          <img
            src={logoUrl}
            alt="Skill Logo"
            className={`w-[75px] ${
              isSuccess ? "mt-2" : "mt-5"
            } h-[75px] bg-white  border border-[#eaeff5] p-2 object-contain rounded-md`}
            loading="lazy"
          />
        )}
      </div>

      <span className="absolute bottom-0 right-0 text-[10px] py-[1px] px-2 bg-[var(--workspace-color-highlight)] text-white rounded-tl-xl rounded-br-lg opacity-0 group-hover:opacity-100 transition">
        Start a chat with this skill
      </span>
    </div>
  );
}

export default WorkspaceSkillCard;
