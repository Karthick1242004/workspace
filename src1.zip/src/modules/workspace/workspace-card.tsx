import React, { useEffect, useState } from "react";
import { LoaderCircle, PencilLine, Pin, Trash2, UserRound } from "lucide-react";
import { useWorkspaceStore, Workspace } from "@/@logic/workspaceStore";
import Dot from "../../shared/dot/dot";
import { useFetchHandler } from "@/@logic/getHandlers";
import { Skeleton } from "@/components/ui/skeleton";
import FallbackLogo from "../../assets/icons/ai-platform-svgrepo-com 1.svg";
import { useNavigate } from "react-router-dom";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import { useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import DeleteDialog from "@/shared/DeleteDialog";
import toast from "react-hot-toast";
import { AxiosError } from "axios";
import { usageLoggerConstants } from "@/constant/usageLogger";
import { useUsageLogger } from "@/utils/usageLogger";
import workspaceCardSvg from "@/assets/icons/Frame-2106257085-copy.svg";
import { cn } from "@/lib/utils";

interface Props {
  data: Workspace;
  isSelected: boolean;
}

export default function WorkspaceCard({ data, isSelected }: Props) {
  const usageLogger = useUsageLogger();
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const isSkill = false;
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [workspaceLoading, setWorkspaceLoading] = useState<boolean>(false);
  const { favoriteWorkspace, deleteWorkspace } = useWorkspaceStore();

  useEffect(() => {
    if (isSelected === true) {
      usageLogger(
        `${usageLoggerConstants.click.workspace}`,
        "workspace",
        data.id
      );
    }
  }, [isSelected]);

  const { data: workspaceLogo, isLoading } = useFetchHandler(
    `/workspaces/logo/${data.id}/download`,
    `${data.id}-logo-${data.updated_at}`,
    true,
    true,
    false,
    0
  );
  const imgUrl = workspaceLogo
    ? URL.createObjectURL(workspaceLogo)
    : FallbackLogo;

  const deleteMutation = useMutateHandler({
    endUrl: `workspaces/delete-workspace/${data.id}`,
    method: HTTPMethod.POST,
    onSuccess: () => {
      setIsDialogOpen(false);
      usageLogger(`${usageLoggerConstants.delete.workspace} ${Number(data.id)}`)
      navigate("/workspace/my-workspace");
      deleteWorkspace(data.id);
      queryClient.invalidateQueries({ queryKey: ["workspace"] });
      toast.success("Workspace deleted successfully!");
    },
    onError: (error: AxiosError<any>) => {
      console.error("Error deleting workspace:", error);
      const err = error as AxiosError<any>;
      const errorMessage =
        err?.response?.data?.message || err?.message || "Unknown error";
      toast.error(errorMessage);
    },
  });

  const handleDelete = () => {
    if (!data.id) return;
    deleteMutation.mutate({
      workspace_id: data.id,
    });
  };

  const favoriteMutation = useMutateHandler({
    endUrl: "workspaces/favorite-workspace",
    method: HTTPMethod.POST,
    onSuccess: () => {
      
      queryClient.invalidateQueries({ queryKey: ["workspace"] });
      favoriteWorkspace(data.id, !data.is_favorited);
      setWorkspaceLoading(false);
      usageLogger(`${data.is_favorited? 'UnFavorited':'Favorited'} the Workspace`,'workspace',data.id)
    },
    onError: () => {
      setWorkspaceLoading(false);
    },
  });

  const handleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setWorkspaceLoading(true);
    favoriteMutation.mutate({
      resource_id: data.id,
      resource_type: "workspace",
      is_favorite: !data.is_favorited,
    });
  };

  return (
    <div
      className={cn(
        "group border rounded-lg p-4 relative transition-all h-full duration-300 hover:border-[var(--workspace-color-highlight)] hover:shadow-[0_0_10px_rgba(96,165,250,0.5)]",
        isSelected
          ? "border-[var(--workspace-color-highlight)] bg-[var(--workspace-color-highlight)] text-white"
          : "bg-white border-[#b5d3ff] text-gray-600"
      )}
      style={{
        background: `url(${workspaceCardSvg})`,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "bottom",
        backgroundBlendMode: isSelected ? "soft-light" : "normal",
        backgroundSize: "100px",
      }}
    >
      {(data.access_level === "owner" || data.access_level === "editor") && (
        <div className="absolute right-4 mt-[-0.5rem] flex flex-row rounded-sm border border-blue-200 bg-white opacity-0 group-hover:opacity-100 transition">
          <Tooltip>
            <TooltipTrigger>
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/workspace/edit/${data.id}`, {
                    state: { workspace: data },
                  });
                }}
                className="p-1 text-xs text-[var(--workspace-color-highlight)] cursor-pointer rounded-none"
                aria-label="Edit workspace"
              >
                <PencilLine size={16} />
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" sideOffset={2} disableArrow>
              <p>Edit</p>
            </TooltipContent>
          </Tooltip>
          {data.access_level === "owner" && (
            <Tooltip>
              <TooltipTrigger>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <div
                      onClick={(e) => e.stopPropagation()}
                      className="p-1 text-xs text-red-500 cursor-pointer rounded-none"
                      aria-label="Delete workspace"
                    >
                      <Trash2 size={16} />
                    </div>
                  </DialogTrigger>

                  <DialogContent
                    className="sm:max-w-[480px] bg-white"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <DeleteDialog
                      setIsDialogOpen={setIsDialogOpen}
                      handleDelete={handleDelete}
                      itemType="workspace"
                      itemName={data.name || "this workspace"}
                      id={data.id}
                      isSkill={isSkill}
                    />
                  </DialogContent>
                </Dialog>
              </TooltipTrigger>
              <TooltipContent side="bottom" sideOffset={2} disableArrow>
                <p>Delete</p>
              </TooltipContent>
            </Tooltip>
          )}
        </div>
      )}

      <div className="flex gap-4 h-full">
        <div className="flex-1 min-w-0 flex flex-col h-full">
          <div className="flex items-center gap-2 mb-1">
            <h2
              className={cn(
                "font-unilever-medium text-sm truncate",
                isSelected
                  ? "text-white"
                  : "text-[var(--workspace-color-highlight)]"
              )}
              title={data.name}
            >
              {data.name}
            </h2>
            <div
              onClick={handleFavorite}
              className={cn(
                "cursor-pointer",
                !data.is_favorited
                  ? " opacity-0 transition delay-100  group-hover:opacity-100"
                  : "opacity-100"
              )}
            >
              {workspaceLoading ? (
                <LoaderCircle
                  color={
                    isSelected ? "white" : "var(--workspace-color-highlight)"
                  }
                  className="animate-spin w-3"
                />
              ) : isSelected ? (
                data.is_favorited ? (
                  <Pin fill="white" className="w-4" />
                ) : (
                  <Pin
                    fill="var(--workspace-color-highlight)"
                    className="w-4"
                  />
                )
              ) : data.is_favorited ? (
                <Pin fill="var(--workspace-color-highlight)" className="w-4" />
              ) : (
                <Pin color="var(--workspace-color-highlight)" className="w-4" />
              )}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-1 mb-3">
            <p
              className={cn(
                "flex items-center gap-1 px-2 py-0.5 rounded-full text-[clamp(10px,11px,14px)]",
                isSelected
                  ? "bg-[#004EC7]"
                  : "bg-[#ECF4FD] text-[var(--workspace-color-highlight)]"
              )}
              title={data.created_by}
            >
              <UserRound size={14} />
              {data.created_by?.length > 9
                ? `${data.created_by.substring(0, 9)}...`
                : data.created_by}
            </p>
            <div
              className={cn(
                "flex items-center gap-1 px-2 py-0.5 rounded-full text-[clamp(10px,11px,14px)]",
                isSelected
                  ? "bg-[#004EC7]"
                  : "bg-[#ECF4FD] text-[var(--workspace-color-highlight)]"
              )}
            >
              <Dot
                bgcolor={
                  isSelected
                    ? "bg-white"
                    : "bg-[var(--workspace-color-highlight)]"
                }
              />
              {data.skills?.length ?? 0} Skills
            </div>
          </div>
          <p className="text-[clamp(10px,12px,14px)] max-h-[50px] font-unilever line-clamp-3">
            {data.description}
          </p>
        </div>
        {/* Logo or Skeleton */}
        <div className="flex-shrink-0 w-[80px] h-[80px] flex items-center justify-center border border-[#eaeff5] rounded-sm bg-white ml-2">
          {isLoading ? (
            <Skeleton className="w-[64px] h-[64px] rounded-sm bg-gray-200" />
          ) : (
            <img
              src={imgUrl}
              alt="Workspace Logo"
              className="w-[64px] h-[64px] p-1 object-contain rounded-sm"
              loading="lazy"
            />
          )}
        </div>
      </div>
    </div>
  );
}
