// import React, { useState, useEffect } from "react";
// import { useNavigate, useParams, useLocation } from "react-router-dom";
// import { baseURL, HTTPMethod } from "@/@logic";
// import { useQueryClient } from "@tanstack/react-query";
// import { useForm } from "react-hook-form";
// import "@uppy/core/dist/style.css";
// import "@uppy/drag-drop/dist/style.css";
// import { FormConfigs, formConfigs, SkillFormData } from "./formtypes";
// import { ModalForm } from "./components/ModalForm";
// import { RegularForm } from "./components/RegularForm";
// import RegularFormSkeleton from "./components/RegularFormSkeleton";
// import { useFetchHandler } from "@/@logic/getHandlers";
// import { useMutateHandler, Payload } from "@/@logic/mutateHandlers";
// import { useNavigation } from "@/hooks/navigationHook";
// import axiosInstance from "@/utils/axiosInstance";
// import { Option } from "@/components/ui/multiselect";
// import { toast } from "react-hot-toast";

// interface SkillAttachment {
//   id: number;
//   name: string;
//   source_type: string;
//   path_url: string;
//   source_info: string;
//   uploaded_by_id: number;
//   uploaded_at: string;
// }

// interface SkillResponse {
//   data: {
//     id: number;
//     name: string;
//     description: string;
//     workspace_id: number;
//     system_prompt: string;
//     is_processed_for_rag: boolean;
//     processing_status: string;
//     logo_path: string;
//     created_by_id: number;
//     created_at: string;
//     updated_at: string;
//     attachments: SkillAttachment[];
//   };
//   message: string;
// }

// interface FormProps {
//   type: keyof FormConfigs;
//   isModal?: boolean;
//   isOpen?: boolean;
//   onClose?: () => void;
//   workspaceId?: number;
//   userId?: string;
//   workspaceName?: string;
// }

// // export const formTypes = ["pdf","word","ppt","images","excel","csv"].map((x:string)=>({label:x,value:x}))

// export function UnifiedForm({ type, isModal = false, isOpen, onClose, workspaceId, workspaceName, userId = "1" }: FormProps) 
// {
//   const { id } = useParams();
//   const { navigateTo } = useNavigation();
//   const location = useLocation();
//   const queryClient = useQueryClient();
//   const [error, setError] = useState<string | null>(null);
//   const [item, setItem] = useState<any>(location.state?.[type] || null);
//   const [isGeneratingPrompt, setIsGeneratingPrompt] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);
//   const [skillData, setSkillData] = useState<SkillResponse["data"] | null>(null);
//   const [isSubmitting, setIsSubmitting] = useState(false)
//   const [selectedFormats, setSelectedFormats] = React.useState<Option[]>([]);
//   const [formTypes, setFormTypes] = useState<Option[]>([]);
  

//   const { data: fileOptionsData, isLoading: isLoadingFileOptions } = useFetchHandler(
//     "skills/file-options",
//     "fileOptions"
//   );

//   useEffect(() => {
//     if (fileOptionsData && Array.isArray(fileOptionsData.file_format_options)) {
//       const mappedOptions = fileOptionsData.file_format_options.map((x: string) => ({ label: x, value: x }));
//       setFormTypes(mappedOptions);

//       // Initialize selectedFormats to the first option if not already set
//       if (mappedOptions.length > 0 && selectedFormats.length === 0) {
//         setSelectedFormats([mappedOptions[0]]);
//       }
//     }
//   }, [fileOptionsData]);

//   useEffect(()=>{
//     if(type==='skill' && id && !isModal)
//     {
//       queryClient.invalidateQueries({queryKey: ["skillData",`skills/${id}`]})

//     }
//   },[queryClient,type,id,isModal])
//   const config = formConfigs[type];
//   const formMethods = useForm({
//     defaultValues: { 
//       ...config.defaultValues, 
//       ...(type === 'skill' ? {
//         systemPrompt: "",
//         publicURL: "",
//         sharePointURL: "",
//       } : {}),
//     },
//   });

//   const { setValue, watch } = formMethods;
//   const skillName = watch("name");
//   const skillDescription = watch("description");
//   const dataSourceType = watch("category");
//   const shouldShowFileUploader = type === 'skill' && dataSourceType === 'File upload';
//   const shouldShowSharePointInput = type === 'skill' && dataSourceType === 'Sharepoint URL';
//   const shouldShowPublicURLInput = type === 'skill' && dataSourceType === 'Public URL';

//   const { data: fetchedSkillData, isLoading: isFetchingSkill } = useFetchHandler(
//     type === 'skill' && id && !isModal ? `skills/${id}` : '',
//     'skillData'
//   );

//   useEffect(() => {
//     if (fetchedSkillData) {
//       setSkillData(fetchedSkillData);
//       setValue('name', fetchedSkillData.name);
//       setValue('description', fetchedSkillData.description);
//       const systemPrompt = fetchedSkillData.system_prompt || "";
//       setValue('systemPrompt',systemPrompt);
//       if (fetchedSkillData.attachments && fetchedSkillData.attachments.length > 0) {
//         if (fetchedSkillData.attachments[0].source_type === 'ADLS') {
//           setValue('category', 'File upload');
//         } else if (fetchedSkillData.attachments[0].source_type === 'SharePoint') {
//           setValue('category', 'Sharepoint URL');
//         } else if (fetchedSkillData.attachments[0].source_type === 'URL') {
//           setValue('category', 'Public URL');
//         }
//       }
//     }
//   }, [fetchedSkillData, setValue]);

//   useEffect(() => {
//     setIsLoading(isFetchingSkill);
//   }, [isFetchingSkill]);

//   useEffect(() => {
//     if (item) {
//       (Object.keys(config.defaultValues) as Array<keyof typeof config.defaultValues>).forEach((key) => {
//         if( item[key] || config.defaultValues[key]){
//           setValue(key, item[key] || config.defaultValues[key]);
//         }
//       });
//     }
//   }, [item, setValue, config.defaultValues]);

//   const systemPromptMutation = useMutateHandler({
//     endUrl: 'skills/system-prompt',
//     method: HTTPMethod.POST,
//     onSuccess: (data) => {
//       if (data && data.data) {
//         setValue('systemPrompt', data.data);
//       }
//       setIsGeneratingPrompt(false)
//     }
//   });

//   const submitFormMutation = useMutateHandler({
//     endUrl: id 
//       ? `${config.apiEndpoints.update}?${type}Id=${id}${workspaceId ? `&workspaceId=${workspaceId}` : ''}&userId=${userId}`
//       : `${config.apiEndpoints.create}${workspaceId ? `?workspaceId=${workspaceId}` : ''}`,
//     method: HTTPMethod.POST,
//     onSuccess: () => {
//       queryClient.invalidateQueries({ queryKey: ["workspace"] });
//       if (workspaceId && workspaceName) {
//         queryClient.invalidateQueries({ queryKey: [`${workspaceId}-${workspaceName}`] });
//       }

//       if (isModal && onClose) {
//         onClose();
//       } else {
//         navigateTo({path :"/workspace/my-workspace"});
//       }
//     }
//   });

//   const resetForm = () =>{
//     formMethods.reset({
//       ...config.defaultValues,
//       ...(type === 'skill' ?{
//         systemPrompt: "",
//         publicURL:"",
//         sharePointURL:"",
//       }:{})
//     });
//     setSkillData(null);
//   };

//   useEffect(()=>{
//     if(isModal&& !isOpen){
//       resetForm();
//     }
//   },[isOpen,isModal]);

//   const onSubmit = async (data: typeof config.defaultValues) => {
//     try {
//       setIsSubmitting(true);
//       if (type === "skill") {
//         const formData = new FormData();
//         const skillData = data as SkillFormData;
//         formData.append("skill_name", skillData.name);
//         formData.append("description", skillData.description);
//         formData.append("system_prompt", skillData.systemPrompt || "");
      
//         if (workspaceId) {
//           formData.append("workspaceId", workspaceId.toString());
//         }

//         let dataSource = "";
//         if (dataSourceType === "File upload") {
//           dataSource = "ADLS";
//           const fileInputs = document.querySelectorAll('input[name="fileInput"]');
//           if (fileInputs && fileInputs.length > 0) {
//             const fileInput = fileInputs[0] as HTMLInputElement;
//             if (fileInput.files && fileInput.files.length > 0) {
//               for (let i = 0; i < fileInput.files.length; i++) {
//                 formData.append("fileInput", fileInput.files[i]);
//               }
//             }
//           }
//         } else if (dataSourceType === "Sharepoint URL") {
//           dataSource = "SharePoint";
//           formData.append("sharePointURL", skillData.sharePointURL || "");
//         } else if (dataSourceType === "Public URL") {
//           dataSource = "URL";
//           formData.append("publicURL", skillData.publicURL || "");
//         }
        
//         formData.append("dataSource", dataSource);
//         const logoInputs = document.querySelectorAll('input[name="logoFile"]');
//         if (logoInputs && logoInputs.length > 0) {
//           const logoInput = logoInputs[0] as HTMLInputElement;
//           if (logoInput.files && logoInput.files.length > 0) {
//             formData.append("logoFile", logoInput.files[0]);
//           }
//         }
//         const url = id 
//           ? `${baseURL}/skills/update?skillId=${id}&userId=${userId}${workspaceId ? `&workspaceId=${workspaceId}` : ''}`
//           : `${baseURL}/skills/create-skill?userId=${userId}${workspaceId ? `&workspaceId=${workspaceId}` : ''}`;
        
//         if (dataSourceType === "File upload" || dataSourceType === "Sharepoint URL") {
//           formData.append('fileFormats', selectedFormats.map((x: Option) => x.value).join(','))
//         }
//         const response = await axiosInstance.post(url, formData, {
//           headers: { 'Content-Type': 'multipart/form-data' },
//         });

//         if (!response) {
//           throw new Error(`Failed to ${id ? "update" : "create"} ${type}`);
//         }
        
//         queryClient.invalidateQueries({ queryKey: ["workspace"] });
//         if (isModal && onClose) {
//           resetForm();
//           onClose();
//         } else {
//           navigateTo({path:"/workspace/my-workspace"});
//         }
//       } else {
//         const payload = {
//           ...data,
//           id: id || undefined,
//           workspaceId: workspaceId || undefined,
//         };
        
//         submitFormMutation.mutate(payload as Payload,{
//           onSuccess: () => {
//             if(isModal && onClose){
//               resetForm();
//               onClose();
//             }
//             else{
//               navigateTo({path: "/workspace/my-workspace"});
//             }
//           },
//           onError:(error) =>{
//             console.log(`Error ${id ? 'updating': 'creating'}${type}:`,error)
//             toast(`Error ${id ? 'updating':"creating "} ${type}`, {
//               position: "top-right",
//               duration: 5000,
//               style: {
//                 borderLeft: "4px solid red",
//                 fontFamily: "var(--font-unilever)",
//                 fontSize: "14px",
//               },
//             });
//           }
//         });
//       }
//     } catch (error) {
//       toast(`Error ${id ? 'Update':"Create"} ${type}:`, {
//         position: "top-right",
//         duration: 5000,
//         style: {
//           borderLeft: "4px solid red",
//           fontFamily: "var(--font-unilever)",
//           fontSize: "14px",
//         },
//       });
//       setIsSubmitting(false);
      
      
//     }
//   };

//   const generateSystemPrompt = async () => {
//     if (!skillName || !skillDescription) return;
//     setIsGeneratingPrompt(true);
    
//     try {
//       await systemPromptMutation.mutateAsync({
//         name: skillName,
//         description: skillDescription
//       });
//     } catch (error) {
//       console.error('Error generating system prompt:', error);
//       setIsGeneratingPrompt(false);
//     }
//   };

//   if (isLoading) {
//     return (
//       <RegularFormSkeleton />
//     );
//   }
//   if (isModal && !isOpen) return null;
//   if (!isModal && !item && !skillData && type !== 'skill') return null;
  
//   if (isModal) {
//     return (
//       <ModalForm
//         isOpen={!!isOpen}
//         onClose={onClose || (() => {})}
//         type={type}
//         id={id}
//         config={config}
//         formMethods={formMethods}
//         onSubmit={onSubmit}
//         shouldShowFileUploader={shouldShowFileUploader}
//         shouldShowSharePointInput={shouldShowSharePointInput}
//         shouldShowPublicURLInput={shouldShowPublicURLInput}
//         isGeneratingPrompt={isGeneratingPrompt}
//         generateSystemPrompt={generateSystemPrompt}
//         skillName={skillName}
//         skillDescription={skillDescription}
//         setSelectedFormats={setSelectedFormats}
//         selectedFormats={selectedFormats}   
//         formTypes={formTypes}               
//         isSubmitting={isSubmitting}
//       />
//     );
//   }

//   return (
//     <RegularForm
//       type={type}
//       id={id}
//       config={config}
//       formMethods={formMethods}
//       onSubmit={onSubmit}
//       isGeneratingPrompt={isGeneratingPrompt}
//       generateSystemPrompt={generateSystemPrompt}
//       skillName={skillName}
//       skillDescription={skillDescription}
//       skillData={skillData}
//       isSubmitting={isSubmitting}
//       />
//   );
// }