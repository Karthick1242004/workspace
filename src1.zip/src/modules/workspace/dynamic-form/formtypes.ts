import { FieldValues } from "react-hook-form";

export interface WorkspaceFormData {
  id?: string;
  name: string;
  description: string;
  category: string;
  icc: string;
  cost_center: string;
  responsible_wl3: string;
  notes: string;
  personas: string[];
}

export interface SkillFormData {
  id?: string;
  name: string;
  description: string;
  category: string;
  systemPrompt: string;
  workspaceId?: string;
  publicURL?: string,
  sharePointURL?: string,
  adlsURL?: string,
  dataSource?: 'ADLS' | 'URL' | 'SharePoint' | 'ADLS Endpoint';
  link?: string;
  aiModelID?: string;
}

export type FormField = {
  name: string;
  label: string;
  type: "input" | "textarea" | "select" | "uploader" | "multiselect";
  required?: boolean;
  placeholder?: string;
  rows?: number;
  options?: string[];
  isMandatory?: boolean
  column?: "left" | "right";
  uploaderType?: "logo" | "files";
  disabled?:boolean;
  isLoading?: boolean;
};

export type FormConfig<T extends FieldValues> = {
  title: string;
  defaultValues: T;
  fields: FormField[];
  apiEndpoints: {
    create: string;
    update: string;
    delete?: string;
  };
};

export type FormConfigs = {
  workspace: FormConfig<WorkspaceFormData>;
  skill: FormConfig<SkillFormData>;
};

export const formConfigs: FormConfigs = {
  workspace: {
    title: "Workspace",
    defaultValues: {
      name: "",
      description: "",
      category: "Business Group",
      icc: "ICC",
      cost_center: "Cost Center name",
      responsible_wl3: "WL3",
      notes: "",
      personas: [],
    },
    fields: [
      {
        name: "name",
        label: "Workspace Name",
        type: "input",
        required: true,
        isMandatory: true,
        placeholder: "Enter workspace name",
      },
      {
        name: "description",
        label: "Description",
        type: "textarea",
        required: true,
        isMandatory: true,
        placeholder: "Enter workspace description",
        rows: 4,
      },
      {
        name: "category",
        label: "Category",
        type: "select",
        isMandatory: true,
        required: true,
      },
      {
        name: "personas",
        label: "Personas",
        type: "multiselect",
        required: false,
        isMandatory: false,
        options: [],
      },
      {
        name: "icc",
        label: "ICC",
        required: true,
        isMandatory: true,
        type: "input",
      },
      {
        name: "cost_center",
        label: "Cost Center",
        required: true,
        isMandatory: true,
        type: "input",
      },
      {
        name: "responsible_wl3",
        label: "Responsible WL3",
        required: true,
        isMandatory: true,
        type: "input",
      },
      {
        name: "notes",
        label: "Note",
        type: "textarea",
        rows: 4,
        placeholder: "Add Note",
      },
      {
        name: "icon",
        label: "Update Logo",
        type: "uploader",
        uploaderType: "logo"
      },
      
    ],
    apiEndpoints: {
      create: "workspaces/",
      update: "workspaces/update-and-delete/",
    },
  },
  skill: {
    title: "Skill",
    defaultValues: {
      name: "",
      description: "",
      category: "File upload",
      systemPrompt: "",
      aiModelID: ""
    },
    fields: [
      {
        name: "name",
        label: "Skill Name",
        type: "input",
        required: true,
        isMandatory: true,
        placeholder: "Enter skill name",
        column: "left"
      },
      {
        name: "description",
        label: "Description",
        type: "textarea",
        required: true,
        isMandatory: true,
        placeholder: "Enter skill description",
        rows: 4,
        column: "left"
      },
      {
        name: "category",
        label: "Data source type",
        type: "select",
        options: ["File upload", "Sharepoint URL", "Public URL", "ADLS Endpoint"],
        column: "right",
      },
      {
        name: "systemPrompt",
        label: "System Prompt",
        type: "textarea",
        required: true,
        isMandatory: true,
        rows: 4,
        column: "left",
        placeholder: "Enter system prompt"
      },
      {
        name: "aiModelID",
        label: "AI Models",
        type: "select",
        required: true,
        isMandatory: true,
        column: "left",
        options: []
      },
      {
        name: "files",
        label: "Upload File",
        type: "uploader",
        column: "right",
        uploaderType: "files"
      },
      
      {
        name: "icon",
        label: "Upload Logo",
        type: "uploader",
        column: "left",
        uploaderType: "logo"
      }
    ],
    apiEndpoints: {
      create: "skills/create-skill",
      update: "skills/edit-skill/",
    },
  },
};