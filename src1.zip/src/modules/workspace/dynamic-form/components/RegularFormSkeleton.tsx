import { Skeleton } from '@/components/ui/skeleton'
import React from 'react'

export default function RegularFormSkeleton() {
  return (
    <div className="font-unilever h-[var(--edit-content-height)] bg-[#F4FAFC] shadow-lg overflow-y-auto mt-2 rounded-xl w-full p-5">
        <div className="space-y-4">
          <Skeleton className="h-8 w-[250px]" /> 
          <div className="flex justify-between">
            <Skeleton className="h-10 w-[220px]" />
            <Skeleton className="h-10 w-[180px]" />
          </div>
          <Skeleton className="h-5 w-[100px] mt-6" />
          <Skeleton className="h-10 w-full" /> 
          <Skeleton className="h-5 w-[100px] mt-4" />
          <Skeleton className="h-24 w-full" /> 
          <div className="flex flex-row gap-4 mt-6">
            <div className="flex-1">
              <Skeleton className="h-5 w-[100px] mb-2" />
              <Skeleton className="h-[120px] w-full" /> 
            </div>
            <div className="flex-1">
              <Skeleton className="h-5 w-[100px] mb-2" />
              <Skeleton className="h-[120px] w-full" /> 
            </div>
          </div>
          <Skeleton className="h-5 w-[120px] mt-6" />
          <Skeleton className="h-[150px] w-full rounded-md" /> 
        </div>
      </div>
  )
}
