import React, { useEffect, useMemo, useState } from "react";
import { Pencil, Trash2, Save, CircleArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FormFieldWithLabel } from "./FormField";
import { UseFormReturn, useForm } from "react-hook-form";
import { useNavigation } from "@/hooks/navigationHook";
import { useQueryClient } from "@tanstack/react-query";
import axiosInstance from "@/utils/axiosInstance";
import toast from "react-hot-toast";
import { HTTPMethod } from "@/@logic";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { useFetchHandler } from "@/@logic/getHandlers";
import { AxiosError } from "axios";
import { FormConfig, FormField as FormFieldType } from "../formtypes";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import DeleteDialog from "@/shared/DeleteDialog";
import RegularFormSkeleton from "@/modules/workspace/dynamic-form/components/RegularFormSkeleton";
import { useLocation } from "react-router-dom";
import { useMsal } from "@azure/msal-react";
import { useUsageLogger } from "@/utils/usageLogger";
import { usageLoggerConstants } from "@/constant/usageLogger";


interface WorkspaceEditProps {
  id: string;
  config: FormConfig<any>;
  initialData: any;
}

async function fetchWorkspace(id: string, setLocalWorkspaceData: React.Dispatch<React.SetStateAction<any>>, reset: UseFormReturn<any>['reset']) {
  try {
    const response = await axiosInstance.get(`workspaces/${id}`);
    const workspace = response.data.data;
    setLocalWorkspaceData(workspace);
    reset({
      name: workspace.name,
      description: workspace.description,
      category: workspace.category,
      icc: workspace.icc,
      cost_center: workspace.cost_center,
      responsible_wl3: workspace.responsible_wl3,
      notes: workspace.notes,
      personas: [], 
    });
  } catch (error) {
    const err = error as AxiosError<any>;
    const errorMessage =
      err?.response?.data?.message ||
      err?.message ||
      "Unknown error";
    toast.error(errorMessage);
  }
}

const WorkspaceEdit: React.FC<WorkspaceEditProps> = ({ id, config, initialData }) => {
  const { navigateTo } = useNavigation();
  const queryClient = useQueryClient();
  const usageLogger = useUsageLogger();
  const [localWorkspaceData, setLocalWorkspaceData] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { data: categories = [] } = useFetchHandler('workspaces/categories', 'workspace-categories', true, false, true);
  const { data: aiModels = [], isLoading: isLoadingAiModels } = useFetchHandler('personas/', 'personas', true, false, true);
  const formMethods = useForm({ defaultValues: initialData });
  const { control, handleSubmit, formState: { errors, isSubmitting }, reset, setValue } = formMethods;
  const location = useLocation();
  const workspaceDataFromState = location.state?.workspace;
  const isSkill = false;
  const { accounts } = useMsal(); 
  const roles = accounts[0].idTokenClaims?.roles;
  const isSuperAdmin = roles?.includes("MSB_SUPER_ADMINS");

  const categoryOptions = useMemo(() => {
    if (!categories) return [];
    const options = categories.map((cat: any) => {
      const value = typeof cat === 'object' ? cat.name : cat;
      return value?.toLowerCase();
    });
    return options;
  }, [categories]);

  const aiModelOptions = useMemo(() => {
    if (!aiModels) return [];
    return aiModels.map((model: any) => ({
      label: model.name,
      value: model.id
    }));
  }, [aiModels]);

  const getSelectedPersonas = React.useMemo(() => {
    if (!localWorkspaceData?.personas || !aiModels || aiModels.length === 0) {
      return [];
    }
    return localWorkspaceData.personas
      .map((existingPersona: any) => {
        const matchingPersona = aiModels.find((model: any) => 
          model.name === existingPersona.name
        );
        
        if (matchingPersona) {
          return {
            label: matchingPersona.name,
            value: matchingPersona.id
          };
        }
        return null;
      })
      .filter(Boolean); 
  }, [localWorkspaceData, aiModels]);

  useEffect(() => {
    if (workspaceDataFromState) {
      setLocalWorkspaceData(workspaceDataFromState);
      reset({
        name: workspaceDataFromState.name,
        description: workspaceDataFromState.description,
        category: workspaceDataFromState.category?.toLowerCase(),
        icc: workspaceDataFromState.icc,
        cost_center: workspaceDataFromState.cost_center,
        responsible_wl3: workspaceDataFromState.responsible_wl3,
        note: workspaceDataFromState.note,
        persona_ids: [], 
      });
    } else if (id) {
      fetchWorkspace(id, setLocalWorkspaceData, reset);
    }
  }, [id, reset, workspaceDataFromState]);

  useEffect(() => {
    if (localWorkspaceData && categoryOptions.length > 0) {
      const normalizedCategory = localWorkspaceData.category?.toLowerCase();
      if (categoryOptions.includes(normalizedCategory)) {
        setValue('category', normalizedCategory);
      } else {
        toast.error(`Workspace category not found in options: ${normalizedCategory}`);
      }
    }
  }, [localWorkspaceData, categoryOptions, setValue]);

  useEffect(() => {
    if (localWorkspaceData && aiModels && aiModels.length > 0) {
      const selectedPersonas = getSelectedPersonas;
      setValue('personas', selectedPersonas);
    }
  }, [localWorkspaceData, aiModels, getSelectedPersonas, setValue]);

  const onSubmit = async (data: any) => {
    const formData = new FormData();
    formData.append("name", data.name);
    formData.append("description", data.description);
    formData.append("category", data.category);
    formData.append("icc", data.icc);
    formData.append("cost_center", data.cost_center);
    formData.append("responsible_wl3", data.responsible_wl3);
    formData.append("notes", data.notes);
    if (data.personas) {
      const personaIds = data.personas.map((p: any) => parseInt(p.value, 10));
      formData.append("persona_ids", (personaIds));
    }

    const logoInput = document.querySelector('input[name="logoFile"]') as HTMLInputElement;
    if (logoInput && logoInput.files && logoInput.files.length > 0) {
      formData.append('icon', logoInput.files[0]);
    }

    try {
      await axiosInstance.post(`workspaces/edit-workspace/${id}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      queryClient.invalidateQueries({ queryKey: ["workspace"] });
      toast.success("Workspace updated successfully!");
      usageLogger(`${usageLoggerConstants.edit.workspace}`,'workspace',Number(id))
      navigateTo({ path: "/workspace/my-workspace" });
    } catch (error) {
      const err = error as AxiosError<any>;
      const errorMessage =
        err?.response?.data?.message ||
        err?.message ||
        "Unknown error";
      toast.error(errorMessage);
    }
  };

  const deleteMutation = useMutateHandler({
    endUrl: `workspaces/delete-workspace/${id}`,
    method: HTTPMethod.POST,
    onSuccess: () => {
      setIsDialogOpen(false);
      navigateTo({ path: "/workspace/my-workspace" });
      queryClient.invalidateQueries({ queryKey: ["workspace"] });
      toast.success("Workspace deleted successfully!");
    },
    onError: (error: AxiosError<any>) => {
      console.error('Error deleting workspace:', error);
      const err = error as AxiosError<any>;
      const errorMessage =
        err?.response?.data?.message ||
        err?.message ||
        "Unknown error";
      toast.error(errorMessage);
    }
  });

  const handleDelete = () => {
    if (!id) return;
    deleteMutation.mutate({
      workspace_id: id
    });
      };

  if (!workspaceDataFromState && id && !localWorkspaceData) {
    return <RegularFormSkeleton />;
  }

  return (
    <div className="font-unilever bg-white/60 shadow-lg overflow-y-auto rounded-xl w-full">
      <div className="max-w-full mx-auto px-5 py-2">
        <Button
          variant="ghost"
          size="sm"
          className="text-gray-400 ml-[-1%] text-[12px] cursor-pointer"
          onClick={() => navigateTo({ path: "/workspace/my-workspace" })}
        >
          <CircleArrowLeft size={12} className="mt-1" />
          Back
        </Button>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-4">
              <h1 className="text-md font-unilever-medium flex items-center">
                <Pencil className="h-5 w-5 mr-2" /> Edit {config.title}
              </h1>
            </div>
            <div className="flex items-center space-x-2">
              {(id && localWorkspaceData?.access_level==='owner') && (
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="border-red-500 cursor-pointer text-xs text-red-500 !px-2 hover:bg-red-50"
                      type="button"
                    >
                      Delete {config.title}
                      <Trash2 className="h-4 w-4 ml-2" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[480px] bg-white">
                    <DeleteDialog
                      setIsDialogOpen={setIsDialogOpen}
                      handleDelete={handleDelete}
                      itemType="workspace"
                      itemName={localWorkspaceData?.name || "this workspace"}
                      id={id}
                      isSkill={isSkill}
                    />
                  </DialogContent>
                </Dialog>
              )}

              <Button
                className="bg-blue-600 text-xs text-white cursor-pointer hover:bg-blue-700"
                type="submit"
                disabled={isSubmitting}
              >
                Save Changes
                <Save className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
          <div className="space-y-4">
            {config.fields
              .filter((field: FormFieldType) => {
                if (field.name === "category" && !isSuperAdmin) {
                  return false
                }
                return true;
              }).map((field: FormFieldType) => (
                <FormFieldWithLabel
                  key={field.name}
                  field={{
                    ...field,
                    options: field.name === 'category' 
                    ? categoryOptions
                     : field.name === 'personas'
                     ? aiModelOptions
                     : field.options,
                    isLoading: field.name === 'personas' ? isLoadingAiModels : false,
                  }}
                  control={control}
                  errors={errors}
                  isModal={false}
                  type="workspace"
                  id={id}
                />
              ))}
          </div>
        </form>
      </div>
    </div>
  );
};

export default WorkspaceEdit;