import React, { useState } from "react";
import { Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Workspace } from "@/@logic/workspaceStore";
import WorkspaceSkillCard from "./skill/workspace-skill-card";
import SkillCreate from "./dynamic-form/components/SkillCreate";

export type ProcessingStatus =
  | "Pending"
  | "Inprogress"
  | "Completed"
  | "Failed";

export default function WorkspaceDetails({
  workspace,
}: {
  workspace: Workspace;
}) {
  const [isSkillModalOpen, setIsSkillModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentSort, setCurrentSort] = useState<ProcessingStatus | "All">(
    "All"
  );

  const handleSort = (sortType: ProcessingStatus | "All") => {
    setCurrentSort(sortType);
  };

  const filteredSkills =
    workspace.skills
      ?.filter((skill) => {
        const name = skill.name?.toLowerCase() || "";
        const desc = skill.description?.toLowerCase() || "";
        const q = searchQuery.toLowerCase();
        const matchesSearch = name.includes(q) || desc.includes(q);

        const matchesStatus =
          currentSort === "All" || skill.processing_status === currentSort;

        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => {
        if (a.is_favorited && !b.is_favorited) return -1;
        if (!a.is_favorited && b.is_favorited) return 1;
        return 0;
      }) || [];

  return (
    <div
      className="w-full rounded-xl p-3 bg-white"
      style={{
        border: "1.5px solid #005EEE",

        background:
          "linear-gradient(15deg, rgba(31, 54, 199, 0.15) 26.3%, rgba(105, 125, 255, 0.15) 86.4%), rgba(255, 255, 255, 0.50)",
      }}
    >
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-sm font-unilever-medium text-black pb-2">
          Skills of {workspace.name}
        </h2>
        <div className="flex items-center gap-3">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              aria-label="Search Skills"
              placeholder="Search Skills"
              className="pl-6 pr-4 py-1.5 border-b border-gray-400  text-xs focus:outline-none focus:border-[var(--workspace-color-highlight)] w-[260px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-0 top-1.5 h-4.5 w-4.5 text-gray-700 pointer-events-none" />
          </div>
          <Button
            className="bg-[var(--workspace-color-highlight)] cursor-pointer text-white text-[clamp(10px,12px,14px)] h-8 rounded-md px-3 flex items-center gap-1"
            onClick={() => setIsSkillModalOpen(true)}
          >
            <Plus className="h-4 w-4" /> Add Skill
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-1 mt-2 md:grid-cols-2 xl:grid-cols-3 lg:grid-cols-2 gap-3 overflow-y-auto min-h-[10vh] max-h-[50vh] ">
        {filteredSkills.length > 0 ? (
          filteredSkills.map((skill) => (
            <WorkspaceSkillCard
              key={skill.id}
              skill={skill}
              workspaceId={workspace.id}
            />
          ))
        ) : (
          <div className="col-span-full text-center py-4 text-gray-500">
            {searchQuery
              ? "No skills match your search"
              : "No skills available"}
          </div>
        )}
      </div>
      <SkillCreate
        isOpen={isSkillModalOpen}
        onClose={() => setIsSkillModalOpen(false)}
        workspaceId={workspace.id}
      />
    </div>
  );
}