import React from "react";
import { useFetchHandler } from "@/@logic/getHandlers";
import Vid from "@/assets/images/sample-5s.mp4";
import { Skeleton } from "@/components/ui/skeleton";

interface VideoApiProp {
  title: string;
  video_link: string;
  is_visible: boolean;
  sequence_order: number;
  id: number;
}

const VideoItem = ({ video }: { video: VideoApiProp }) => {
  const { data: videoStream, isLoading: streamLoading } = useFetchHandler(
    `help-section/video/${video.id}/stream`,
    `${video.id}`,
    true,
    true
  );

  const videoUrl = videoStream ? URL.createObjectURL(videoStream) : "Vid";

  return (
    <div className="flex flex-col gap-2 flex-shrink-0">
      {streamLoading ? (
        <div className="w-64 h-36 bg-gray-200 animate-pulse rounded-md" />
      ) : (
        <video src={videoUrl} className="w-64 h-auto rounded-md" controls />
      )}
      <p className="text-gray-700 text-sm">{video.title}</p>
    </div>
  );
};

export default function VideoGuide() {
  const { data: videoData, isLoading } = useFetchHandler(
    "help-section/video-guides",
    "video-data"
  );

  return (
    <div className="w-full font-unilever flex flex-1 flex-row gap-3 overflow-x-scroll scrollbar-hide">
      {isLoading &&
        <div className="flex flex-row gap-3">
          <div className="flex flex-col gap-2">
          <Skeleton className="h-38 w-60" />
          <Skeleton className="h-5 w-24"/>
          </div>
          <div className="flex flex-col gap-2">
          <Skeleton className="h-38 w-60" />
          <Skeleton className="h-5 w-24"/>
          </div>
        </div>}
      {videoData?.map((item: VideoApiProp) => (
        <VideoItem key={item.id} video={item} />
      ))}
    </div>
  )
}