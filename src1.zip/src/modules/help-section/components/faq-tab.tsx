import React from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Faq from "./faq";
import { useFetchHandler } from "@/@logic/getHandlers";
import { Skeleton } from "@/components/ui/skeleton";

type FaqItem = {
  category: string;
  question: string;
  answer: string;
  sequence_order: number;
  is_visible: boolean;
};

export default function FaqTab() {
  const { data, isLoading } = useFetchHandler(
    "help-section/faqs",
    "faq-questions"
  );
  const apiData = data ?? [];

  const faqByCategory = apiData.reduce(
    (acc: Record<string, FaqItem[]>, item: FaqItem) => {
      if (!item.is_visible) return acc;
      const category = item.category;
      if (!acc[category]) acc[category] = [];
      acc[category].push(item);
      return acc;
    },
    {}
  );

  Object.keys(faqByCategory).forEach((cat) => {
    faqByCategory[cat].sort(
      (a: { sequence_order: number }, b: { sequence_order: number }) =>
        a.sequence_order - b.sequence_order
    );
  });

  const categories = Object.keys(faqByCategory);

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex flex-row gap-1">
          <Skeleton className="w-30 h-8 animate-pulse" />
          <Skeleton className="w-30 h-8 animate-pulse" />
        </div>
        <div className="flex flex-col gap-3">
          <Skeleton className="w-full h-14 animate-pulse" />
          <Skeleton className="w-full h-14 animate-pulse" />
        </div>
      </div>
    );
  }

  if (categories.length === 0) {
    return <div className="text-gray-500 text-sm">No FAQs available.</div>;
  }

  return (
    <Tabs defaultValue={categories[0]}>
      <TabsList className="h-[38px] border border-gray-200">
        {categories.map((category) => (
          <TabsTrigger
            key={category}
            value={category}
            className="cursor-pointer text-[clamp(10px,12px,14px)]"
          >
            {category}
          </TabsTrigger>
        ))}
      </TabsList>

      {categories.map((category) => (
        <TabsContent key={category} value={category} className="mt-3">
          <Faq data={faqByCategory[category] || []} isLoading={isLoading} />
        </TabsContent>
      ))}
    </Tabs>
  );
}
