import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Skeleton } from "@/components/ui/skeleton";

type FaqItem = {
  category: string;
  question: string;
  answer: string;
  sequence_order: number;
  is_visible: boolean;
};

export default function Faq({
  data,
  isLoading,
}: {
  data: FaqItem[];
  isLoading: boolean;
}) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-20 w-full rounded-md" />
        ))}
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <p className="text-sm text-gray-500">
        No FAQs available for this category.
      </p>
    );
  }

  return (
    <Accordion
      type="single"
      collapsible
      className="w-full bg-[#F2F2F2] rounded-md"
      defaultValue={data[0]?.question}
    >
      {data.map((item, index) => (
        <AccordionItem
          key={index}
          className="shadow-sm cursor-pointer px-8 border-[1px] border-[#F2F2F2]"
          value={item.question}
          style={{
            background:
              "linear-gradient(0deg, rgba(255, 255, 255, 0.60) 0%, rgba(255, 255, 255, 0.60) 100%), linear-gradient(109deg, #F5F9FF 0.15%, rgba(186, 208, 230, 0.90) 165.55%)",
            boxShadow: 'none'
          }}
        >
          <div className="flex flex-row items-center gap-10">
            <span className="text-xl text-gray-400 font-unilever-medium duration-200">
              {String(index + 1).padStart(2, "0")}
            </span>
            <div className="w-full">
              <AccordionTrigger className="cursor-pointer text-xs data-[state=open]:text-blue-800 duration-100 py-5">
                {item.question}
              </AccordionTrigger>
            </div>
          </div>
          <AccordionContent className="flex flex-col gap-4 text-balance">
            <p className="ml-16 text-gray-500 text-xs">{item.answer}</p>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
