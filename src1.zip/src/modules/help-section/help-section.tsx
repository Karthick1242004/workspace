import { Button } from "@/components/ui/button";
import { useNavigation } from "@/hooks/navigationHook";
import { CircleArrowLeft } from "lucide-react";
import React from "react";
import FaqTab from "./components/faq-tab";
import VideoGuide from "./components/video-guide";
import supportImage from "@/assets/images/image 24.png";

export default function HelpSection() {
  const { navigateTo } = useNavigation();

  return (
    <div className="py-3 px-6 rounded-xl max-w-[var(--max-content-width)] w-full mx-auto flex flex-col justify-between shadow-md overflow-y-auto custom-scrollbar font-unilever bg-white/60">
      <div className="flex flex-col">
        <div className="ml-0">
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-600 ml-[-1.5%] text-[12px] cursor-pointer"
            onClick={() => navigateTo({ path: "/workspace/my-workspace" })}
          >
            <CircleArrowLeft className="relative left-1.5 mt-[2px]" size={12} />
            Back
          </Button>
        </div>
        <div className="flex flex-col gap-2 ">
          <div className="flex flex-col gap-2 text-center">
            <h1 className="text-xl bg-gradient-to-b from-blue-600 via-blue-700 to-blue-800 bg-clip-text text-transparent">
              Need Help? We Got You Covered
            </h1>
            <p className="text-gray-500 text-xs">
              Explore guides, FAQs and support to get the most out of Ally
            </p>
          </div>
          <div className="flex flex-col gap-3">
            <h1 className="font-unilever-medium text-lg">Video Guide</h1>
            <VideoGuide />
          </div>
          <div className="flex flex-col gap-4 mt-6">
            <h1 className="font-unilever-medium text-lg">
              Frequently Asked Questions
            </h1>
            <FaqTab />
          </div>
        </div>
      </div>
      <div className="flex w-full justify-center items-center bg-white/60 rounded-xl border border-[#EAEAEA] py-3 gap-2 mt2">
        <div className="flex flex-col items-center gap-2">
          <h1 className="text-xl bg-gradient-to-b from-blue-600 via-blue-700 to-blue-800 bg-clip-text text-transparent">
            Need More Support?
          </h1>
          <p className="text-xs text-gray-500">
            Our team is ready to assist you.
          </p>
          <button className="bg-blue-600 text-white px-7 py-2 rounded-sm border-none text-xs">
            Contact Ally Support
          </button>
        </div>
        <img src={supportImage} alt="" />
      </div>
    </div>
  );
}
