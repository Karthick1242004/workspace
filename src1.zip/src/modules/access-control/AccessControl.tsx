import React, { useState } from "react";
import TabsWrapper from "./TabsWrapper";
import AccessControlTable from "./AccessControlTable";
import { dummyData } from "./dummyData";
import AdminContolImg from "../../assets/icons/AdminControl.svg";
import { RotateCw } from "lucide-react";
import { useFetchHandler } from "@/@logic/getHandlers";
import { TAB_API_MAP } from "./TabAPIEndpoints";
import PersonaTable, { Persona } from "./PersonaTable";
import SeperatorLine from "../../assets/icons/Seperator.svg";
import { Plus } from "lucide-react";
import ControlSidePanel from "./ControlSidePanel";
import PersonaSidePanel from "./PersonaSidePanel";
import axiosInstance from "@/utils/axiosInstance";
import { Skeleton } from "@/components/ui/skeleton";
import { Search } from "lucide-react";

export default function AccessControlTabs() {

  const [selectedTab, setSelectedTab] = useState("my-ai-workspace");
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<Persona | null>(null);
  const [personaType, setPersonaType] = useState<"Persona" | "Category">("Persona");
  const [selectedPersonaIds, setSelectedPersonaIds] = useState<number[]>([]);
  const [resetSelectionCounter, setResetSelectionCounter] = useState(0);

  const openAddPanel = (type: "Persona" | "Category") => {
    setSelectedPersona(null);
    setPersonaType(type);
    setIsPanelOpen(true);
  };

  const handleSubmit = () => {
    setIsPanelOpen(false);
  };

  const { data, isLoading, refetch } = useFetchHandler(
    TAB_API_MAP[selectedTab],
    selectedTab,
    !!selectedTab
  );

  const renderContent = (columns : string[]) => isLoading ? <Skeleton className="w-full min-h-[calc(100vh-198px)] rounded-sm bg-gray-300"><p>Loading...</p></Skeleton> : <AccessControlTable workspaces={data || []} columns={columns} refetchWorkspaces={refetch}/>;
  const personaContent = (type: "Persona" | "Category") => isLoading ? <Skeleton className="w-full min-h-[calc(100vh-198px)] rounded-sm bg-gray-300"><p>Loading...</p></Skeleton> : <PersonaTable personas={data || []} types={type} onSelectionChange={(ids)=>setSelectedPersonaIds(ids)} resetSelectionTrigger={resetSelectionCounter} refetch={refetch}/>

  const tabs = [
    { label: "My AI Workspace", value: "my-ai-workspace", content: renderContent(["My AI Workspace","Owners","Editors","Viewers"]) },
    { label: "Workspace Permissions", value: "workplace-permission", content: renderContent(["Workspace Name","Owners","Editors","Viewers"]) },
    { label: "Skill Permissions", value: "skill-permission", content: renderContent(["Skill Name","Workspace Name","Owners","Editors","Viewers"]) },
    { label: "Persona", value: "persona", content: personaContent("Persona") },
    { label: "Category", value: "category", content: personaContent("Category") },
  ];

  const handleRemove = async () => {
    if (selectedPersonaIds.length === 0) return;
  
    try {
      await Promise.all(
        selectedPersonaIds.map((id) => {
          const url = `${TAB_API_MAP["delete-" + selectedTab]}${id}`;
          return axiosInstance.post(url);
        })
      );
  
      refetch();
      setSelectedPersonaIds([]);
      setResetSelectionCounter((prev) => prev + 1);
    } catch (error) {
      console.error("Delete failed:", error);
    }
  };

  const headerRight = (
    <>
    <div className="flex items-center space-x-2 bg-white/50 border border-gray-300 rounded-md px-3 py-1">
      <Search className="h-4 w-4 text-gray-400" />
      <input
        type="text"
        placeholder="Search"
        className="flex-1 text-sm focus:outline-none font-unilever bg-transparent"
      />
    </div>
      { 
        (selectedTab === "persona" || selectedTab === "category") && (
          <button 
            className="text-sm cursor-pointer font-unilever flex gap-2 pt-1"
            onClick={() => openAddPanel(selectedTab === "persona" ? "Persona" : "Category")}
          >
            <Plus className="h-4 w-4 mt-1 text-blue-600" /> 
            {selectedTab.charAt(0).toUpperCase() + selectedTab.slice(1)}
          </button>
        )
      }
      <button className="text-sm cursor-pointer font-unilever flex gap-2 pt-1">
        <RotateCw className="h-4 w-4 mt-1 text-blue-600" /> Refresh
      </button>
      <img src={SeperatorLine} alt="seperator-line"/>
      <button className="text-sm text-gray-500 cursor-pointer font-unilever" onClick={handleRemove}>
        ✖ Remove
      </button>
    </>
  );

  return (
    <>
      <div className="w-full max-w-[1300px] mx-auto px-4">
        <h2 className="text-lg font-semibold mt-6 mb-4 flex items-center gap-2 font-unilever">
          <img src={AdminContolImg} className="text-gray-700 text-2xl" />
          Admin Controls
        </h2>
        <TabsWrapper defaultValue="my-ai-workspace" value={selectedTab} onValueChange={setSelectedTab} tabs={tabs} rightHeader={headerRight} />
      </div>
      <ControlSidePanel
      isOpen={isPanelOpen}
      onClose={() => setIsPanelOpen(false)}
      title={`Add ${personaType}`}
    >
      <PersonaSidePanel
        persona={selectedPersona}
        onClosePanel={() => setIsPanelOpen(false)}
        refetch={refetch}
        types={personaType}
      />
    </ControlSidePanel>
  </>
  );
}