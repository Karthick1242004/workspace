import React from "react";
import PageHeader from "./components/PageHeader";
import TabContent from "./components/TabContent";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { useAccessControlStore } from "./lib/store";
import PersonaSidePanel from "./components/panels/PersonaSidePanel";
import SidePanelContent from "./components/panels/SidePanelContent";
import { X } from "lucide-react";

export default function AccessControlPage() {
  const { isPanelOpen, panelType, panelItem, closePanel } =
    useAccessControlStore();

  const renderPanelContent = () => {
    switch (panelType) {
      case "Persona":
      case "Category":
        return (
          <PersonaSidePanel persona={panelItem as any} types={panelType} />
        );
      case "Permissions":
        return <SidePanelContent workspace={panelItem as any} />;
      default:
        return null;
    }
  };
  return (
    <>
      <div className="flex flex-col max-w-[var(--max-content-width)] mx-auto w-full h-full bg-white/60 p-3 rounded-2xl">
        <PageHeader />
        <TabContent />
        <Drawer
          direction="right"
          open={isPanelOpen}
          onOpenChange={(open) => {
            if (!open) closePanel();
          }}
        >
          <DrawerContent className="bg-white p-3 font-unilever">
            <DrawerHeader className="px-0">
              <div className="flex justify-between">
                <DrawerTitle className="font-unilever">Manage {panelType}</DrawerTitle>
                <button
                  onClick={() => closePanel()}
                  aria-label="Close drawer"
                  className="text-gray-500 hover:text-gray-700 cursor-pointer"
                >
                  <X size={24} />
                </button>
              </div>
            </DrawerHeader>
            {renderPanelContent()}
          </DrawerContent>
        </Drawer>
      </div>
    </>
  );
}
