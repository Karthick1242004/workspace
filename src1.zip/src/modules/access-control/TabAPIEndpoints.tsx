export const TAB_API_MAP: Record<string, string> = {
    "my-ai-workspace": "/access-control/get-access?scope=my_ai_workspace",
    "workplace-permission": "/access-control/get-access?scope=workspace",
    "skill-permission": "/access-control/get-access?scope=skill",
    "persona": "/personas/",
    "category": "/workspaces/categories",
    "edit-Persona": "personas/edit-persona/",
    "edit-Category": "/workspaces/edit-workspace-category/",
    "add-Category": "/workspaces/create-workspace-category",
    "add-Persona": "/personas/create-persona",
    "delete-persona": "personas/delete-persona/",
    "delete-category": "workspaces/delete-workspace-category/"
};