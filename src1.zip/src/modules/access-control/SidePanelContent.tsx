import React, { useState } from "react";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import { Trash } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

interface GroupMember {
  principal_name: string;
  principal_type: "ad_group" | "user";
}

interface Workspace {
  resource_id: number;
  resource_name: string;
  owners?: GroupMember[];
  editors?: GroupMember[];
  viewers?: GroupMember[];
}

type Props = {
  workspace: Workspace | null;
  groupType: "owners" | "editors" | "viewers";
  resource_type: string;
  setWorkspace: (ws: Workspace | null) => void;
  refetchWorkspaces: () => void;
};

export default function SidePanelContent({ workspace, groupType, resource_type, setWorkspace, refetchWorkspaces }: Props) {
  const [inputValue, setInputValue] = useState("");
  const [selectedType, setSelectedType] = useState<"AD Group" | "User ID">("AD Group");
  const [error, setError] = useState<string | null>(null);
  const queryClient = useQueryClient();

  if (!workspace) return null;

  const currentGroup = workspace[groupType] || [];

  const { mutate, isPending } = useMutateHandler({
    endUrl: "access-control/assign",
    method: HTTPMethod.POST,
    onSuccess: async(_data, variables) => {
      const { action, principal_name, principal_type }:any = variables;
      queryClient.invalidateQueries({ queryKey: ["workspace"] });
      if(_data.data !== "unchanged"){
        const updatedGroup =
        action === "add"
          ? [...currentGroup, { principal_name, principal_type }]
          : currentGroup.filter((u) => u.principal_name !== principal_name);

        setWorkspace({
          ...workspace,
          [groupType]: updatedGroup,
        });
        await refetchWorkspaces();
      }

      setInputValue("");
    },
  });

  const handleAdd = () => {
    if (!inputValue.trim()) {
      setError("Input cannot be empty");
      return;
    }
  
    if (
      selectedType === "User ID" &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inputValue.trim())
    ) {
      setError("Please enter a valid email address");
      return;
    }
  
    setError(null);  

    mutate({
      resource_type: resource_type === "Skill Name" ? "skill" : "workspace",
      resource_id: workspace.resource_id,
      access_type: groupType.slice(0, -1),
      principal_type: selectedType === "AD Group" ? "ad_group" : "user",
      principal_name: inputValue.trim(),
      action: "add",
    });
  };

  const handleRemove = (name: string, type: string) => {
    mutate({
      resource_type: resource_type === "Skill Name" ? "skill" : "workspace",
      resource_id: workspace.resource_id,
      access_type: groupType.slice(0, -1),
      principal_type: type,
      principal_name: name,
      action: "deactivate",
    });
  };

  return (
    <div className="text-sm text-gray-800">
      <div className="mb-5">
        <p className="text-gray-600 mb-1">Selected Workspace</p>
        <input
          type="text"
          readOnly
          value={workspace.resource_name}
          className="rounded px-3 py-2 w-full text-sm bg-gray-100 text-blue-600 cursor-not-allowed"
        />
      </div>

      {/* <div className="mb-5">
        <p className="text-gray-600 mb-1">Selected Skills</p>
        <input
          type="text"
          readOnly
          value={workspace.name}
          className="rounded px-3 py-2 w-full text-sm bg-gray-100 text-blue-600 cursor-not-allowed"
        />
      </div> */}
      <div className="mb-7">
        <p className="text-gray-600 mb-2">Add {groupType.slice(0, -1)}</p>
        <div className="flex gap-2 items-top">
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as "AD Group" | "User ID")}
            className="border rounded px-1 py-2 mb-5 text-xs text-blue-600 bg-white"
          >
            <option value="AD Group">AD Group</option>
            <option value="User ID">User ID</option>
          </select>
          <div className="w-70">
            <input
              type="text"
              placeholder={`Enter ${selectedType}`}
              value={inputValue}
              onChange={(e) => {
                setInputValue(e.target.value);
                setError(null); // Clear error on change
              }}
              className={`border rounded px-1 py-2 w-full text-xs ${
                error ? "border-red-500" : "border-gray-300"
              }`}
            />
            {error && <p className="text-red-500 text-xs mt-0.5">{error}</p>}
          </div>
          <div className="mb-5"> 
            <button onClick={handleAdd} disabled={isPending} className="bg-blue-600 text-white px-2.5 py-1.5 rounded hover:bg-blue-700 text-sm flex disabled:opacity-50">
              + <span className="pl-2">Add</span>
            </button>
          </div>
          
        </div>
      </div>

      <div>
        <p className="text-gray-600 mb-2">Current {groupType.charAt(0).toUpperCase() + groupType.slice(1)}</p>
        <table className="w-full text-sm border-separate border-spacing-y-3">
          <thead className="text-left bg-[#EBEDFB] text-gray-700">
            <tr>
              <th className="pr-4 p-3">S.No</th>
              <th>{groupType.slice(0, -1).charAt(0).toUpperCase() + groupType.slice(1, -1)}</th>
              <th>Type</th>
              <th className="text-right pr-4">Action</th>
            </tr>
          </thead>
          <tbody>
            {currentGroup.map((user, idx) => (
              <tr key={idx} className="text-gray-900">
                <td className="pr-4 pl-4">{idx + 1}.</td>
                <td>{user.principal_name}</td>
                <td>{user.principal_type === "user" ? "User ID" : "AD Group"}</td>
                <td className="pr-1">
                  <div className="flex justify-center items-center h-full">
                    <Trash
                      onClick={() => handleRemove(user.principal_name, user.principal_type)}
                      className="text-red-600 hover:text-red-800 cursor-pointer size-[18px]"
                    />
                  </div>
                </td>
              </tr>
            ))}
            {currentGroup.length === 0 && (
              <tr>
                <td colSpan={4} className="text-center text-gray-500 py-4">
                  No members found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}