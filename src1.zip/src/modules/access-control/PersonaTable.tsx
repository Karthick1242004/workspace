import React, { useState, useEffect } from "react";
import { Pencil } from "lucide-react";
import ControlSidePanel from "./ControlSidePanel";
import PersonaSidePanel from "./PersonaSidePanel";

export interface Persona {
  id: number;
  name: string;
  description: string;
}

type Props = {
  personas: Persona[] | null;
  types: "Persona" | "Category";
  onSelectionChange?: (selectedIds: number[]) => void;
  resetSelectionTrigger?: number;
  refetch: ()=>void;
};

export default function PersonaTable({ personas: initialPersonas, types, onSelectionChange, resetSelectionTrigger, refetch }: Props) {
  const personas = initialPersonas;
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<Persona | null>(null);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [selectAll, setSelectAll] = useState(false);


  useEffect(() => {
    onSelectionChange?.(selectedIds);
  }, [selectedIds]);

  useEffect(() => {
    setSelectedIds([]);
    setSelectAll(false);
  }, [resetSelectionTrigger]);

  const toggleSelectAll = () => {
    if (!personas) return;
    if (selectAll) {
      setSelectedIds([]);
    } else {
      setSelectedIds(personas.map((p) => p.id));
    }
    setSelectAll(!selectAll);
  };

  const toggleRowSelection = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const openPanel = (persona?: Persona) => {
    setSelectedPersona(persona ?? null);
    setIsPanelOpen(true);
  };


  return (
    <div className="relative">
      <div className="rounded-md bg-white overflow-hidden h-[calc(100vh-198px)] font-unilever">
        <div className="bg-gray-100 flex text-[14px] font-bold text-gray-700 border-b border-gray-200">
          <div className="w-[5%] p-3 flex items-center whitespace-nowrap">
            <input
              type="checkbox"
              className="h-4 w-4 mr-2 my-1"
              checked={selectAll}
              onChange={toggleSelectAll}
            />
          </div>
          <div className="w-[30%] p-3 flex items-center gap-2 whitespace-nowrap">
            {types} Name
          </div>
          <div className="w-[60%] p-3 flex items-center gap-2 whitespace-nowrap">
            Description
          </div>
        </div>

        <div className="overflow-y-auto h-full">
          {personas?.map((persona) => (
            <div
              key={persona.id}
              className="flex text-[13px] text-gray-800 hover:bg-gray-50 transition-colors border-b border-gray-100 items-center"
            >
              <div className="w-[5%] p-3 flex items-center font-light whitespace-nowrap overflow-hidden text-ellipsis">
                <input
                  type="checkbox"
                  className="h-4 w-4 mr-2"
                  checked={selectedIds.includes(persona.id)}
                  onChange={() => toggleRowSelection(persona.id)}
                />
              </div>
              <div className="w-[30%] p-3 font-light whitespace-nowrap overflow-hidden text-ellipsis">
                {persona.name}
              </div>
              <div className="w-[60%] p-3 font-light whitespace-nowrap overflow-hidden text-ellipsis">
                {persona.description}
              </div>
              <div className="w-[5%] p-3 flex justify-end">
                <Pencil
                  className="w-4 h-4 text-gray-500 hover:text-gray-700 cursor-pointer"
                  onClick={() => openPanel(persona)}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <ControlSidePanel
        isOpen={isPanelOpen}
        onClose={() => setIsPanelOpen(false)}
        title={"Edit " + types}
      >
        <PersonaSidePanel
          persona={selectedPersona}
          onClosePanel={() => setIsPanelOpen(false)}
          refetch={refetch}
          types={types}
        />
      </ControlSidePanel>
    </div>
  );
}