import React, { useEffect, useState } from "react";
import { useMutateHandler } from "@/@logic/mutateHandlers";
import { HTTPMethod } from "@/@logic";
import { Trash, Loader2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAccessControlStore } from "../../lib/store";
import { WorkspacePermission } from "../../lib/types";
import toast from "react-hot-toast";
import { useUsageLogger } from "@/utils/usageLogger";

type Props = {
  workspace: WorkspacePermission | null;
};

export default function SidePanelContent({ workspace }: Props) {
  const { activeTab } = useAccessControlStore();
  const queryClient = useQueryClient();
const usageLogger = useUsageLogger();
  const [inputValue, setInputValue] = useState("");
  const [selectedType, setSelectedType] = useState<"ad_group" | "user">(
    "ad_group"
  );
  const [error, setError] = useState<string | null>(null);
  const [currentWorkspace, setCurrentWorkspace] =
    useState<WorkspacePermission | null>(workspace);
  const [isLoading, setIsLoading] = useState<{
    [key: string]: boolean;
  }>({});

  useEffect(() => {
    setCurrentWorkspace(workspace);
  }, [workspace]);

  const { mutate, isPending } = useMutateHandler({
    endUrl: "access-control/assign",
    method: HTTPMethod.POST,
    onSuccess: (_data, variables) => {
      const { action, principal_name, principal_type, access_type, resource_type,resource_id } =
        variables as any;
      const groupKey = `${access_type}s` as "owners" | "editors" | "viewers";
      const actionText = action === "add" ? "added" : "removed";
      toast.success(`Successfully ${actionText} access as ${access_type}`);
      queryClient.invalidateQueries({ queryKey: [activeTab] });
      queryClient.invalidateQueries({ queryKey: ["workspace"] });
      setInputValue("");


      usageLogger(
        `action=${actionText}, principal_type=${principal_type}, principal_name=${principal_name}, resource_type=${resource_type}, resource_id=${resource_id}, access=${access_type}`, resource_type,resource_id
      );
      
    },
  });

  if (!currentWorkspace) return null;

  const handleAdd = (groupType: "owners" | "editors" | "viewers") => {
    if (!inputValue.trim()) {
      setError("Input cannot be empty");
      return;
    }
    if (
      selectedType === "user" &&
      !/^[a-zA-Z0-9][a-zA-Z0-9._+-]{2,}$/.test(inputValue.trim())
    ) {
      setError("Please enter a valid user");
      return;
    }
    let normalizedInput = inputValue.trim().toLowerCase();
    if (selectedType === "user" && !normalizedInput.endsWith("@unilever.com")) {
      normalizedInput += "@unilever.com";
    }

    const currentGroup = currentWorkspace?.[groupType] || [];
    const userExists = currentGroup.some(
      (user) => user.principal_name.toLowerCase() === normalizedInput
    );

    if (userExists) {
      if (selectedType === 'user') {
        setError("User already exists");
      }
      else {
        setError("AD Group already exists");
      }
      return;
    }
    setError(null);

    setCurrentWorkspace((prev) => {
      if (!prev) return prev;
      const updatedGroup = [
        ...prev[groupType] || [],
        {
          principal_name: normalizedInput,
          principal_type: selectedType,
        },
      ];
      return {
        ...prev,
        [groupType]: updatedGroup,
      };
    });

    const variables = {
      resource_type: activeTab.includes("skill") ? "skill" : "workspace",
      resource_id: currentWorkspace.resource_id,
      access_type: groupType.slice(0, -1),
      principal_type: selectedType,
      principal_name: inputValue.trim(),
      action: "add",
    };

    mutate(variables, {
      onError: () => {
        toast.error(`Error adding access as ${variables.access_type}`);
      },
    });
  };

  const handleRemove = (
    groupType: "owners" | "editors" | "viewers",
    principalName: string,
    type: string
  ) => {
    let name = principalName;

    setIsLoading((prev) => ({
      ...prev,
      [`${groupType}-${principalName}`]: true,
    }));

    if (type === "user") {
      if (!name.trim().endsWith("@unilever.com")) {
        name = `${name}@unilever.com`;
      }
    }

    const variables = {
      resource_type: activeTab.includes("skill") ? "skill" : "workspace",
      resource_id: currentWorkspace.resource_id,
      access_type: groupType.slice(0, -1),
      principal_type: type,
      principal_name: name,
      action: "deactivate",
    };

    mutate(variables, {
      onError: () => {
        toast.error(`Error removing access as ${variables.access_type}`);
        setIsLoading((prev) => ({
          ...prev,
          [`${groupType}-${principalName}`]: false,
        }));
      },
      onSettled: () => {
        setIsLoading((prev) => ({
          ...prev,
          [`${groupType}-${principalName}`]: false,
        }));
        setCurrentWorkspace((prev) => {
          if (!prev) return prev; // safeguard for null
          const currentGroup = prev[groupType] || [];
          const updatedGroup = currentGroup.filter(
            (u) => u.principal_name !== principalName
          );
          return {
            ...prev,
            [groupType]: updatedGroup,
          };
        })
      },
    });
  };

  return (
    <div className="text-sm text-gray-800">
      <div className="mb-5">
        <p className="text-gray-600 mb-1">Selected Workspace</p>
        <input
          type="text"
          readOnly
          value={currentWorkspace.resource_name}
          className="rounded px-3 py-2 w-full text-sm bg-gray-100 text-blue-600 cursor-not-allowed"
        />
      </div>

      <div>
        <p className="text-gray-600 mb-2 font-medium">Add new member</p>
        <div className="flex gap-2 items-start">
          <select
            value={selectedType}
            onChange={(e) =>
              setSelectedType(e.target.value as "ad_group" | "user")
            }
            className="border rounded cursor-pointer px-1 py-1.5 mb-5 text-xs text-blue-600 bg-white"
          >
            <option value="ad_group">AD Group</option>
            <option value="user">User ID</option>
          </select>
          <div className="flex-1">
            <div className="flex gap-2">
              <div className="relative w-full">
                <input
                  id="inputField"
                  type="text"
                  value={inputValue}
                  onChange={(e) => {
                    setInputValue(e.target.value);
                    setError(null);
                  }}
                  className={`border rounded px-1 py-2 pr-25 w-full text-xs ${
                    error ? "border-red-500" : "border-gray-300"
                  }`}
                />
                {selectedType === "user" && (
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-gray-500 pointer-events-none">
                    @unilever.com
                  </span>
                )}
              </div>

              <button
                onClick={() =>
                  handleAdd(currentWorkspace.selectedGroup || "owners")
                }
                disabled={isPending || !inputValue.trim()}
                className="bg-blue-600 cursor-pointer text-white px-2.5 py-1.5 rounded hover:bg-blue-700 text-sm flex disabled:opacity-50"
              >
                + <span className="pl-2">Add</span>
              </button>
            </div>
            {error && <p className="text-red-500 text-xs mt-0.5">{error}</p>}
          </div>
        </div>
      </div>

      {currentWorkspace.selectedGroup && (
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <p className="text-gray-600 font-medium">
              Current{" "}
              {currentWorkspace.selectedGroup.charAt(0).toUpperCase() +
                currentWorkspace.selectedGroup.slice(1)}
            </p>
          </div>
          <table className="w-full text-sm border-separate border-spacing-y-3 bg-gray-50 rounded-md">
            <thead className="text-left bg-[#EBEDFB] text-gray-700 rounded-t-md">
              <tr>
                <th className="pr-4 p-3">S.No</th>
                <th>
                  {currentWorkspace.selectedGroup
                    .slice(0, -1)
                    .charAt(0)
                    .toUpperCase() +
                    currentWorkspace.selectedGroup.slice(1, -1)}
                </th>
                <th>Type</th>
                <th className="text-right pr-4">Action</th>
              </tr>
            </thead>
            <tbody>
              {(currentWorkspace[currentWorkspace.selectedGroup] || []).length >
              0 ? (
                (currentWorkspace[currentWorkspace.selectedGroup] || []).map(
                  (user, idx) => (
                    <tr key={idx} className="text-gray-900">
                      <td className="pr-4 pl-4">{idx + 1}.</td>
                      <td>
                        {user.principal_type === "user"
                          ? user.principal_name.includes("@unilever.com")
                            ? user.principal_name
                            : user.principal_name + "@unilever.com"
                          : user.principal_name}
                      </td>
                      <td>
                        {user.principal_type === "user"
                          ? "User ID"
                          : "AD Group"}
                      </td>
                      <td className="pr-1">
                        <div className="flex justify-center items-center h-full">
                          {isLoading[
                            `${currentWorkspace.selectedGroup}-${user.principal_name}`
                          ] ? (
                            <Loader2 className="w-4 h-4 animate-spin text-gray-500" />
                          ) : (
                            <Trash
                              className="w-4 h-4 text-red-500 cursor-pointer hover:text-red-700"
                              onClick={() =>
                                handleRemove(
                                  currentWorkspace.selectedGroup!,
                                  user.principal_name,
                                  user.principal_type
                                )
                              }
                            />
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                )
              ) : (
                <tr>
                  <td colSpan={4} className="text-center text-gray-500 py-4">
                    No members found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
