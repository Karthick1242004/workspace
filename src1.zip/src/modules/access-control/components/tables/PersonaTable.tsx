import React, { useState, useEffect } from "react";
import { Pencil } from "lucide-react";
import { useAccessControlStore } from "../../lib/store";
import { Persona } from "../../lib/types";

type Props = {
  personas: Persona[];
  type: "Persona" | "Category";
};

export default function PersonaTable({ personas, type }: Props) {
  const { setSelectedIds, resetSelectionCounter, openPanel } = useAccessControlStore();
  const [localSelectedIds, setLocalSelectedIds] = useState<number[]>([]);
  const [selectAll, setSelectAll] = useState(false);

  useEffect(() => {
    setSelectedIds(localSelectedIds);
  }, [localSelectedIds, setSelectedIds]);

  useEffect(() => {
    setLocalSelectedIds([]);
    setSelectAll(false);
  }, [resetSelectionCounter]);

  const toggleSelectAll = () => {
    if (selectAll) {
      setLocalSelectedIds([]);
    } else {
      setLocalSelectedIds(personas.map((p) => p.id));
    }
    setSelectAll(!selectAll);
  };

  const toggleRowSelection = (id: number) => {
    setLocalSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id],
    );
  };

  return (
    <div className="rounded-md bg-white font-unilever">
      {/* Table Header */}
      <div className="bg-gray-100 flex text-sm font-bold text-gray-700 border-b border-gray-200">
        <div className="w-[5%] p-3 flex items-center">
          <input
            type="checkbox"
            className="h-4 w-4 cursor-pointer"
            checked={selectAll}
            onChange={toggleSelectAll}
          />
        </div>
        <div className="w-[30%] p-3">{type} Name</div>
        <div className="w-[60%] p-3">Description</div>
        <div className="w-[5%] p-3"></div>
      </div>

      {/* Table Body */}
      <div className="overflow-auto custom-scrollbar">
        {personas?.map((persona) => (
          <div
            key={persona.id}
            className="flex text-[13px] text-gray-800 hover:bg-gray-50 transition-colors border-b border-gray-100 items-center"
          >
            <div className="w-[5%] p-3 flex items-center">
              <input
                type="checkbox"
                className="h-4 w-4 cursor-pointer"
                checked={localSelectedIds.includes(persona.id)}
                onChange={() => toggleRowSelection(persona.id)}
              />
            </div>
            <div className="w-[30%] p-3 truncate">{persona.name}</div>
            <div className="w-[60%] p-3 truncate">{persona.description}</div>
            <div className="w-[5%] p-3 flex justify-end">
              <Pencil
                className="w-4 h-4 text-gray-500 hover:text-gray-700 cursor-pointer"
                onClick={() => openPanel(type, persona)}
              />
            </div>
          </div>
        ))}
        {(!personas || personas.length === 0) && (
          <div className="flex items-center justify-center h-48 text-gray-500">
            No {type.toLowerCase()==='persona'?'Personas':'Categories'} found.
          </div>
        )}
      </div>
    </div>
  );
}