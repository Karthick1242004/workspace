import React, { useEffect, useState } from "react";
import { InfoIcon, PanelRight, PencilIcon } from "lucide-react";
import { useAccessControlStore } from "../../lib/store";
import { WorkspacePermission } from "../../lib/types";

type Props = {
  workspaces: WorkspacePermission[];
  columns: string[];
};

export default function AccessControlTable({ workspaces, columns }: Props) {
  const { setSelectedIds, resetSelectionCounter, openPanel } =
    useAccessControlStore();
  const [localSelectedIds, setLocalSelectedIds] = useState<number[]>([]);
  const [selectAll, setSelectAll] = useState(false);

  useEffect(() => {
    setSelectedIds(localSelectedIds);
  }, [localSelectedIds, setSelectedIds]);

  useEffect(() => {
    setLocalSelectedIds([]);
    setSelectAll(false);
  }, [resetSelectionCounter]);

  const toggleSelectAll = () => {
    if (selectAll) {
      setLocalSelectedIds([]);
    } else {
      setLocalSelectedIds(workspaces.map((p) => p.resource_id));
    }
    setSelectAll(!selectAll);
  };

  const toggleRowSelection = (id: number) => {
    setLocalSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="rounded-md w-full bg-white font-unilever overflow-x-auto custom-scrollbar">
      <table className="w-full">
        {/* Table Header */}
        <thead className="bg-gray-100">
          <tr className="text-[14px] font-bold text-gray-700 border-b border-gray-200">
            <th className="p-3 text-left">
              <div className="flex items-center gap-2 whitespace-nowrap">
                <input
                  type="checkbox"
                  className="h-4 w-4 shrink-0 cursor-pointer"
                  checked={selectAll}
                  onChange={toggleSelectAll}
                />
                <p className="text-xs">{columns[0]}</p>
              </div>
            </th>
            {columns.slice(1).map((label) => (
              <th key={label} className="w-[200px] p-3 text-left">
                <div className="flex items-center gap-2 whitespace-nowrap">
                  <p className="text-xs">{label}</p>
                  {label !== "Workspace Name" && (
                    <span title={`${label} Info`}>
                      <InfoIcon className="h-4 w-4" />
                    </span>
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>

        {/* Table Body */}
        <tbody className="divide-y divide-gray-100">
          {!workspaces || workspaces.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length}
                className="p-12 text-center text-gray-500"
              >
                No Permissions found.
              </td>
            </tr>
          ) : (
            workspaces?.map((ws) => (
              <tr
                key={ws.resource_id}
                className="text-[13px] text-gray-800 hover:bg-gray-50 transition-colors"
              >
                <td className="p-3  w-[100px] truncate">
                  <div className="flex items-center gap-2 font-light">
                    <input
                      type="checkbox"
                      className="h-4 w-4 shrink-0 cursor-pointer"
                      checked={localSelectedIds.includes(ws.resource_id)}
                      onChange={() => toggleRowSelection(ws.resource_id)}
                    />
                    <span className="truncate" title={ws.resource_name}>
                      {ws.resource_name}
                    </span>
                  </div>
                </td>

                {columns.includes("Skill Name") && (
                  <td
                    className="p-3 w-[100px] truncate"
                    title={ws.workspace_name}
                  >
                    {ws.workspace_name}
                  </td>
                )}

                {(["owners", "editors", "viewers"] as const).map(
                  (groupType) => (
                    <td key={groupType} className="p-3">
                      <div className="font-light group flex items-center gap-x-2">
                        <div className="flex items-center gap-1 min-w-0 flex-1">
                          {(ws[groupType] || [])
                            .slice(0, 1)
                            .map((member, i) => (
                              <span
                                key={i}
                                className="text-blue-500 hover:underline cursor-pointer bg-[#005EEF0F] px-2 py-1 rounded-lg whitespace-nowrap truncate max-w-[120px]"
                                title={member.principal_name}
                              >
                                {member.principal_name}
                              </span>
                            ))}

                          {(ws[groupType]?.length || 0) > 1 && (
                            <span
                              className="text-blue-500 hover:underline cursor-pointer bg-[#005EEF0F] px-2 py-1 rounded-lg whitespace-nowrap"
                              title={`${ws[groupType]!.length - 1} more`}
                            >
                              +{ws[groupType]!.length - 1}
                            </span>
                          )}
                        </div>

                        <div
                          className="opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shrink-0"
                          onClick={() =>
                            openPanel("Permissions", {
                              ...ws,
                              selectedGroup: groupType,
                            })
                          }
                        >
                          <PencilIcon className="h-4 w-4 text-blue-600" />
                        </div>
                      </div>
                    </td>
                  )
                )}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
