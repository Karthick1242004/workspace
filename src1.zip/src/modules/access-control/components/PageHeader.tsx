import React, { useState, useMemo } from "react";
import { useAccessControlStore } from "../lib/store";
import { useQueryClient } from "@tanstack/react-query";
import { RotateCw, Search, Plus, X, Loader2, UserLock } from "lucide-react";
import { TABS_CONFIG } from "../lib/constants";
import axiosInstance from "@/utils/axiosInstance";
import TabsWrapper from "@/components/ui/tabs-wrapper";
import { useMsal } from "@azure/msal-react";
import toast from "react-hot-toast";

export default function PageHeader() {
  const {
    activeTab,
    searchText,
    selectedIds,
    setSearchText,
    setActiveTab,
    openPanel,
    resetSelections,
  } = useAccessControlStore();

  const queryClient = useQueryClient();
  const [isRemoving, setIsRemoving] = useState(false);
  const currentTabConfig = TABS_CONFIG.find((t) => t.value === activeTab);

  const { accounts } = useMsal();
  const roles = accounts[0].idTokenClaims?.roles;
  const isSuperAdmin = roles?.includes("MSB_SUPER_ADMINS");

  const filteredTabs = useMemo(() => {
    return isSuperAdmin
      ? TABS_CONFIG
      : TABS_CONFIG.filter((tab) => tab.value === "my-ai-workspace");
  }, [isSuperAdmin]);

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({ queryKey: [activeTab] });
  };

  const handleRemove = async () => {
    if (selectedIds.length === 0) return;
    try {
      setIsRemoving(true);
      if (activeTab === "persona") {
        await axiosInstance.post("personas/delete-persona", {
          persona_ids: selectedIds,
        });
        // toast.success('Successfully removed persona!', { position: 'top-right' });
      } else if (activeTab === "category") {
        await axiosInstance.post("workspaces/delete-workspace-category", {
          category_ids: selectedIds,
        });
        // toast.success('Successfully removed category!', { position: 'top-right' });
      }

      await queryClient.invalidateQueries({ queryKey: [activeTab] });
      await queryClient.invalidateQueries({ queryKey: ["workspace"] });
      resetSelections();
    } catch (error) {
      console.error("Error removing items:", error);
      toast.error("Failed to remove items. Please try again.");
    } finally {
      setIsRemoving(false);
    }
  };

  return (
    <>
      <div className="flex gap-2 items-center">
        <UserLock className="h-4 w-4" />
        <h2 className="text-sm xl:text-md font-semibold flex items-center gap-2 font-unilever">
          Admin Controls
        </h2>
      </div>

      <div className="flex flex-row justify-between items-center flex-wrap">
        <TabsWrapper
          tabs={filteredTabs}
          value={activeTab}
          onValueChange={setActiveTab}
        />
        <div className="flex items-center justify-end gap-4 relative my-3">
          <div className="flex  items-center border-b border-gray-500 space-x-2 px-0.5 py-1.5">
            <Search className="h-4 w-4 text-gray-800 " />
            <input
              type="text"
              placeholder="Search..."
              className="flex-1 text-sm  focus:outline-none !bg-transparent"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
          </div>

          {currentTabConfig?.canAdd && (
            <button
              className="text-sm font-medium flex items-center gap-2 cursor-pointer"
              onClick={() => openPanel(currentTabConfig.label as any, null)}
            >
              <Plus className="h-4 w-4 text-blue-600" />
              {currentTabConfig.label}
            </button>
          )}

          <button
            className="text-sm font-medium flex items-center gap-2 cursor-pointer disabled:opacity-50"
            onClick={handleRefresh}
          >
            <RotateCw className="h-4 w-4 text-blue-600" />
            Refresh
          </button>

          <div className="h-6 w-px bg-gray-300" />

          <button
            className="text-sm cursor-pointer font-medium flex items-center gap-2 text-black disabled:text-gray-300 disabled:cursor-not-allowed"
            onClick={handleRemove}
            disabled={selectedIds.length === 0 || isRemoving}
          >
            {isRemoving ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <X className="h-4 w-4 text-red-500" />
            )}
            Remove
          </button>
        </div>
      </div>
    </>
  );
}
