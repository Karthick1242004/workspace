import React, { useEffect, useMemo } from "react";
import { useAccessControlStore } from "../lib/store";
import { useFetchHandler } from "@/@logic/getHandlers";
import { TAB_API_MAP, TABS_CONFIG } from "../lib/constants";
import { Skeleton } from "@/components/ui/skeleton";
import AccessControlTable from "./tables/AccessControlTable";
import PersonaTable from "./tables/PersonaTable";
import { useMsal } from "@azure/msal-react";

export default function TabContent() {
  const { activeTab, searchText, setActiveTab } = useAccessControlStore();
  const { accounts } = useMsal();
  const roles = accounts[0].idTokenClaims?.roles;
  const isSuperAdmin = roles?.includes("MSB_SUPER_ADMINS");

  useEffect(() => {
    if (!isSuperAdmin && activeTab !== "my-ai-workspace") {
      setActiveTab("my-ai-workspace");
    }
  }, [isSuperAdmin, activeTab, setActiveTab]);

  const { data, isLoading } = useFetchHandler(
    TAB_API_MAP[activeTab],
    activeTab,
    !!activeTab,
    false,
    true
  );

  const filteredData = useMemo(() => {
    if (!data) return [];
    if (!searchText.trim()) return data;
    const search = searchText.toLowerCase();
    return (data as any[]).filter((item) =>
      JSON.stringify(item).toLowerCase().includes(search)
    );
  }, [data, searchText]);

  const currentTabConfig = TABS_CONFIG.find((t) => t.value === activeTab);

  const renderTable = () => {
    if (!currentTabConfig) return null;

    if (currentTabConfig.type === "permissions") {
      return (
        <AccessControlTable
          workspaces={filteredData as any}
          columns={currentTabConfig.columns!}
        />
      );
    }

    if (currentTabConfig.type === "persona") {
      return (
        <PersonaTable
          personas={filteredData as any}
          type={currentTabConfig.label as "Persona" | "Category"}
        />
      );
    }

    return null;
  };

  return (
    <div className="flex-grow overflow-auto custom-scrollbar font-unilever bg-transparent">
      {isLoading ? (
        <Skeleton className="w-full h-full rounded-md bg-gray-200" />
      ) : (
        renderTable()
      )}
    </div>
  );
}
