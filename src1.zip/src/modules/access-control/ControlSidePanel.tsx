// components/SidePanel.tsx
import React from "react";
import { X } from "lucide-react";

type Props = {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
};

export default function ControlSidePanel({ isOpen, onClose, title, children }: Props) {
  return (
    <div
      className={`fixed inset-0 z-50 flex transition-transform duration-800 ${
        isOpen ? "translate-x-0" : "translate-x-full"
      }`}
    >
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-[#49494A]/25"
        onClick={onClose}
      ></div>

      {/* Panel */}
      <div className="ml-auto h-full w-[500px] bg-white shadow-lg p-6 overflow-y-auto relative z-50">
        <div className="flex items-center justify-between pb-2">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button onClick={onClose}>
            <X className="h-5 w-5 text-gray-600 hover:text-gray-900" />
          </button>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </div>
  );
}