import type { Workspace } from "./AccessControlTable";

export const dummyData: Workspace[] = [ 

    {
      "resource_id": 1,
      "resource_name": "Governance AI Lab",
      "owners": [
        {"principal_type": "ad_group","principal_name": "SG-Developers-TeamEpsilon"}
      ],
      "editors": [
        {"principal_type": "ad_group","principal_name": "SG-Global-Admins"},
        {"principal_type": "user", "principal_name": "clark@unilever.com"}
      ],
      "viewers": [
        {"principal_type": "ad_group", "principal_name": "DG-External-Collaborators"}
      ]
    },
    {
      "resource_id": 2,
      "resource_name": "MLI Analyst Deck",
      "owners": [
        {"principal_type": "user",  "principal_name": "steve@unilever.com"}
      ],
      "editors": [
        {"principal_type": "ad_group","principal_name": "SG-Developers-TeamBeta"}
      ],
      "viewers": [
        {"principal_type": "user", "principal_name": "guest@company.com"},
        {"principal_type": "ad_group","principal_name": "M365-Project-Alpha"}
      ]
    },
    {
      "resource_id": 3,
      "resource_name": "Insight Studio",
      "owners": [
        {"principal_type": "ad_group",  "principal_name": "DG-All-Remote-Users"}
      ],
      "editors": [
        {"principal_type": "ad_group","principal_name": "SG-Global-Admins"}
      ],
      "viewers": [
        {"principal_type": "user", "principal_name": "riya@unilever.com"},
        {"principal_type": "ad_group","principal_name": "SG-Helpdesk-Level5"}
      ]
    }
  ]