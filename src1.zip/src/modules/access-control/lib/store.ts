import { create } from "zustand";
import { Persona, WorkspacePermission } from "./types";

type PanelType = "Permissions" | "Persona" | "Category";
type PanelItem = WorkspacePermission | Persona | null;

interface AccessControlState {
  activeTab: string;
  searchText: string;
  selectedIds: (number | string)[];
  isPanelOpen: boolean;
  panelType: PanelType;
  panelItem: PanelItem;
  resetSelectionCounter: number;
}

interface AccessControlActions {
  setActiveTab: (tab: string) => void;
  setSearchText: (text: string) => void;
  setSelectedIds: (ids: (number | string)[]) => void;
  openPanel: (type: PanelType, item: PanelItem) => void;
  closePanel: () => void;
  resetSelections: () => void;
}

export const useAccessControlStore = create<
  AccessControlState & AccessControlActions
>((set) => ({
  activeTab: "my-ai-workspace",
  searchText: "",
  selectedIds: [],
  isPanelOpen: false,
  panelType: "Permissions",
  panelItem: null,
  resetSelectionCounter: 0,

  setActiveTab: (tab) =>
    set({
      activeTab: tab,
      searchText: "",
      selectedIds: [],
      resetSelectionCounter: Math.random(),
    }),
  setSearchText: (text) => set({ searchText: text }),
  setSelectedIds: (ids) => set({ selectedIds: ids }),
  openPanel: (type, item) =>
    set({ isPanelOpen: true, panelType: type, panelItem: item }),
  closePanel: () => set({ isPanelOpen: false, panelItem: null }),
  resetSelections: () =>
    set({
      selectedIds: [],
      resetSelectionCounter: Math.random(),
    }),
}));
