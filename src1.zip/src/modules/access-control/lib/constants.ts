export const TAB_API_MAP: Record<string, string> = {
    "my-ai-workspace": "/access-control/get-access?scope=my_ai_workspace",
    "workplace-permission": "/access-control/get-access?scope=workspace",
    "skill-permission": "/access-control/get-access?scope=skill",
    persona: "/personas/",
    category: "/workspaces/categories",
    "edit-Persona": "personas/edit-persona/",
    "edit-Category": "/workspaces/edit-workspace-category/",
    "add-Category": "/workspaces/create-workspace-category",
    "add-Persona": "/personas/create-persona",
    "delete-persona": "personas/delete-persona/",
    "delete-category": "workspaces/delete-workspace-category/",
  };
  
  export const TABS_CONFIG = [
    {
      label: "My AI Workspace",
      value: "my-ai-workspace",
      type: "permissions",
      columns: ["My AI Workspace", "Owners", "Editors", "Viewers"],
    },
    {
      label: "Workspace Permissions",
      value: "workplace-permission",
      type: "permissions",
      columns: ["Workspace Name", "Owners", "Editors", "Viewers"],
    },
    {
      label: "Skill Permissions",
      value: "skill-permission",
      type: "permissions",
      columns: ["Skill Name", "Workspace Name", "Owners", "Editors", "Viewers"],
    },
    {
      label: "Persona",
      value: "persona",
      type: "persona",
      canAdd: true,
    },
    {
      label: "Category",
      value: "category",
      type: "persona",
      canAdd: true,
    },
  ];