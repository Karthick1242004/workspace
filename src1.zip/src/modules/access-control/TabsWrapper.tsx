import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

interface TabItem {
  label: string;
  value: string;
  content: React.ReactNode;
}

interface TabsWrapperProps {
  defaultValue: string;
  tabs: TabItem[];
  rightHeader?: React.ReactNode;
  value?: string;
  onValueChange?: (value: string) => void;
}

const TabsWrapper: React.FC<TabsWrapperProps> = ({ defaultValue, tabs, rightHeader, value, onValueChange }) => {
  return (
    <Tabs defaultValue={defaultValue} value={value} onValueChange={onValueChange} className="w-full">
      <div className="flex items-center justify-between">
        <TabsList className="bg-white">
          {tabs.map((tab) => (
            <TabsTrigger key={tab.value} value={tab.value} className="mx-1">
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>
        {rightHeader && <div className="flex gap-4 ml-4">{rightHeader}</div>}
      </div>

      {tabs.map((tab) => (
        <TabsContent key={tab.value} value={tab.value}>
          {tab.content}
        </TabsContent>
      ))}
    </Tabs>
  );
};

export default TabsWrapper;