import React, { useEffect } from "react";
import { RouterProvider } from "react-router-dom";
import { InteractionType } from "@azure/msal-browser";
import { AuthenticatedTemplate, useMsalAuthentication } from "@azure/msal-react";
import { loginRequest, msalInstance } from "./authConfig";
import router from "./route";
import { Toaster } from 'react-hot-toast';

export default function App() {

  const { login, error } = useMsalAuthentication(
    InteractionType.Silent,
    loginRequest
  );

  useEffect(() => {
    if (error) {
      console.error('Authentication error:', error);
      login(InteractionType.Redirect, loginRequest);
    }  
  }, [error]);
  
  return (
    <>
      <AuthenticatedTemplate>
        <RouterProvider router={router} />
        <Toaster />
      </AuthenticatedTemplate>
    </>
  );
}
