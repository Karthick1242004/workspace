import React from "react";
import {
  Navigate,
  createBrowserRouter,
  useParams,
  type RouteObject,
} from "react-router-dom";
import Layout from "./shared/layout/layout";
import NewVersionPrompt from "./shared/NewVersionPrompt";

const lazyRoute =
  (
    importer: () => Promise<{ default: React.ComponentType<any> }>
  ): RouteObject["lazy"] =>
  async () => {
    try {
      const { default: Cmp } = await importer();
      return { Component: Cmp };
    } catch (err) {
      if (
        err instanceof Error &&
        err.message.includes("Failed to fetch dynamically imported module")
      ) {
        return { Component: NewVersionPrompt };
      }
      return { Component: () => <p>Error loading chunk</p> };
    }
  };

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Layout />,
    children: [
      { index: true, element: <Navigate to="/chat" /> },

      {
        path: "access-control",
        lazy: lazyRoute(() => import("./modules/access-control/AccessControl")),
      },
      {
        path: "help-section",
        lazy: lazyRoute(() => import("./modules/help-section/help-section")),
      },
      {
        path: "analytics",
        children: [
          {
            index: true,
            lazy: lazyRoute(() => import("./modules/analytics/Analytics")),
          },
          {
            path: "workspace/:workspaceId/skill/:skillId",
            lazy: lazyRoute(() => import("./modules/analytics/Analytics")),
          },
        ],
      },
      {
        path: "workspace",
        children: [
          { index: true, element: <Navigate to="my-workspace" /> },
          {
            path: "my-workspace",
            lazy: lazyRoute(() => import("./modules/workspace/tab/tab")),
          },
          {
            path: ":workspacecategory",
            lazy: lazyRoute(() => import("./modules/workspace/tab/tab")),
          },

          {
            path: "edit/:id",
            lazy: async () => {
              const { default: WorkspaceEdit } = await import(
                "./modules/workspace/dynamic-form/components/WorkspaceEdit"
              );
              const { formConfigs } = await import(
                "./modules/workspace/dynamic-form/formtypes"
              );
              const Component = () => {
                const { id } = useParams();
                if (!id) return <Navigate to="/workspace" />;
                return (
                  <WorkspaceEdit
                    id={id}
                    config={formConfigs.workspace}
                    initialData={{}}
                  />
                );
              };
              return { Component };
            },
          },

          {
            path: "skill/edit/:id",
            lazy: async () => {
              const { default: SkillEdit } = await import(
                "./modules/workspace/dynamic-form/components/SkillEdit"
              );
              const { formConfigs } = await import(
                "./modules/workspace/dynamic-form/formtypes"
              );
              const Component = () => {
                const { id } = useParams();
                if (!id) return <Navigate to="/workspace" />;
                return (
                  <SkillEdit
                    id={id}
                    config={formConfigs.skill}
                    initialData={{}}
                  />
                );
              };
              return { Component };
            },
          },
          {
            path: "skill/view/:id",
            lazy: async () => {
              const { default: SkillEdit } = await import(
                "./modules/workspace/dynamic-form/components/SkillEdit"
              );
              const { formConfigs } = await import(
                "./modules/workspace/dynamic-form/formtypes"
              );
              const Component = () => {
                const { id } = useParams();
                if (!id) return <Navigate to="/workspace" />;
                return (
                  <SkillEdit
                    id={id}
                    config={formConfigs.skill}
                    initialData={{}}
                  />
                );
              };
              return { Component };
            },
          },
        ],
      },

      { path: "chat", lazy: lazyRoute(() => import("./modules/chat/Chat")) },
      {
        path: "chat/:workspaceName/:skillName",
        lazy: lazyRoute(() => import("./modules/chat/Chat")),
      },
      {
        path: "chat/:chatId",
        lazy: lazyRoute(() => import("./modules/chat/Chat")),
      },
    ],
  },

  { path: "/auth", element: <Navigate to="/" /> },
  { path: "*", element: <Navigate to="/" /> },
];

export default createBrowserRouter(routes);
