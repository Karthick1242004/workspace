import { PublicClientApplication } from "@azure/msal-browser";
import { ENVIRONEMENTAL_VARS } from "./env";

export const configuration = {
  tenant: ENVIRONEMENTAL_VARS.VITE_TENANT_ID,
  auth: {
    clientId: ENVIRONEMENTAL_VARS.VITE_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${
      ENVIRONEMENTAL_VARS.VITE_TENANT_ID
    }`,
    redirectUri: ENVIRONEMENTAL_VARS.VITE_REDIRECT_URL,
  },
};

export const msalInstance = new PublicClientApplication(configuration);

export const loginRequest = {
  scopes: [ENVIRONEMENTAL_VARS.USER_READ_SCOPES],
};

export const powerBiScopes = {
    scopes: [
        ENVIRONEMENTAL_VARS.VITE_PBI_DASHBOARD_SCOPE,
        ENVIRONEMENTAL_VARS.VITE_PBI_DATASET_SCOPE,
        ENVIRONEMENTAL_VARS.VITE_PBI_REPORT_SCOPE
    ]
}
