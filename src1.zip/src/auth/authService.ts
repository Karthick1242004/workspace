import { ENVIRONEMENTAL_VARS } from "@/env";
import { msalInstance } from "../authConfig";
import { InteractionRequiredAuthError } from "@azure/msal-common";

export const getAccessToken = async (): Promise<string | null> => {
  try {
    const accountObj = msalInstance.getAllAccounts()[0];
    if (!accountObj) throw new Error("No account found. User not logged in.");

    const tokenResponse = await msalInstance.acquireTokenSilent({
      account: accountObj,
      scopes: [ENVIRONEMENTAL_VARS.READ_WRITE_SCOPES],
    });

    return tokenResponse.accessToken;
  } catch (error) {
    console.error("Error fetching access token:", error);

    if (error instanceof InteractionRequiredAuthError) {
      console.warn("Interaction required. Redirecting to login...");
      await msalInstance.acquireTokenRedirect({
        scopes: ["User.Read"],
      });
    }
    return null;
  }
};
