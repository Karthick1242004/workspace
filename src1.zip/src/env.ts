export const ENVIRONEMENTAL_VARS = {
    "VITE_API_BASE_URL" : import.meta.env.VITE_API_BASE_URL,
    "VITE_TENANT_ID" : import.meta.env.VITE_TENANT_ID,
    "VITE_CLIENT_ID" : import.meta.env.VITE_CLIENT_ID,
    "VITE_REDIRECT_URL" : import.meta.env.VITE_REDIRECT_URL,
    "READ_WRITE_SCOPES": `api://${import.meta.env.VITE_CLIENT_ID}/api.readwrite`,
    "USER_READ_SCOPES": `User.Read`,
    // "VITE_REDIRECT_URL" : "http://localhost:5173/auth"
}

// export const ENVIRONEMENTAL_VARS = {
//     "VITE_API_BASE_URL" : "https://bpace-ai04-d-930708-webapi-05.azurewebsites.net/api/",
//     "VITE_TENANT_ID" : "f66fae02-5d36-495b-bfe0-78a6ff9f8e6e",
//     "VITE_CLIENT_ID" : "e623ccf9-daaa-4869-b408-6d145713aa0e",
//     "VITE_REDIRECT_URL" : "https://agreeable-sea-0e7901b03.6.azurestaticapps.net/auth",
//     // "VITE_REDIRECT_URL" : "http://localhost:5173/auth"
// }