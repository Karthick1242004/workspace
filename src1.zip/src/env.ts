export const ENVIRONEMENTAL_VARS = {
    "VITE_API_BASE_URL" : import.meta.env.VITE_API_BASE_URL,
    "VITE_TENANT_ID" : import.meta.env.VITE_TENANT_ID,
    "VITE_CLIENT_ID" : import.meta.env.VITE_CLIENT_ID,
    "VITE_REDIRECT_URL" : import.meta.env.VITE_REDIRECT_URL,
    "READ_WRITE_SCOPES": `api://${import.meta.env.VITE_CLIENT_ID}/api.readwrite`,
    "USER_READ_SCOPES": `User.Read`,
    "VITE_PBI_DASHBOARD_SCOPE": 'https://analysis.windows.net/powerbi/api/Dashboard.Read.All',
    "VITE_PBI_DATASET_SCOPE": 'https://analysis.windows.net/powerbi/api/Dataset.Read.All',
    "VITE_PBI_REPORT_SCOPE": 'https://analysis.windows.net/powerbi/api/Report.Read.All',
    "PBI_URLS": {
        SUPER_ADMIN: import.meta.env.VITE_SUPER_ADMIN_PBI_URL,
        WORKSPACE_AMDIN: import.meta.env.VITE_WORKSPACE_AMDIN_PBI_URL,
        SKILL_ADMIN: import.meta.env.VITE_SKILL_ADMIN_PBI_URL
    }
}

