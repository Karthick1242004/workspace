  export const generateReadableTimeStamp = (timeStamp:string) =>{
      const date = new Date(timeStamp);
      const day = date.getDate();
      function getDayWithSuffix() {
        if (day > 3 && day < 21) return day + 'th';
        switch (day % 10) {
          case 1: return day + 'st';
          case 2: return day + 'nd';
          case 3: return day + 'rd';
          default: return day + 'th';
        }
      }
      const readableDate = `${getDayWithSuffix()} ${date.toLocaleString('en-US', { month: 'short' })}`;
      return readableDate
  }