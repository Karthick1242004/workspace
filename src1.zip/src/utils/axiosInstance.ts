import axios from "axios";
import { baseURL, requestHeaders } from "../@logic";
import { getAccessToken } from "../auth/authService";

const axiosInstance = axios.create({
  baseURL,
  headers: requestHeaders,
});

// Request Interceptor: Automatically attach token
axiosInstance.interceptors.request.use(
  async (config) => {
    const token = await getAccessToken();


    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor: Handle errors globally
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error("API Error:", error);
    return Promise.reject(error);
  }
);

export default axiosInstance;
