import axios from "axios";
import { msalInstance, powerBiScopes } from "../authConfig";

const getPBIAccessToken = async () => {
    try {
        const account = msalInstance?.getAllAccounts()[0];

        if (account) {
            const response = await msalInstance.acquireTokenSilent({
                scopes: powerBiScopes.scopes,
                account: account
            });

            return response.accessToken;
        } else {
            return '';
        }
    } catch (err: any) {
        throw new Error(err?.message);
    }
};

export const getPbiReportDetails = async (reportId:string) => {

    const url = `https://api.powerbi.com/v1.0/myorg/reports/${reportId}`
    try {
        const token = await getPBIAccessToken();
        const response = await axios.get(url, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        return {
            ...response.data,
            token
        }
    } catch (err: any) {
        throw new Error(err?.message);
    }
}