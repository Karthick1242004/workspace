import { HTTPMethod } from "@/@logic";
import { useMutateHandler } from "@/@logic/mutateHandlers";

export const useUsageLogger = () => {

    const { mutate } = useMutateHandler({
      endUrl: "access-control/log-activity",
      method: HTTPMethod.POST,
    });
  
    return (activity: string, resource_type?: string, resource_id?: number) => {
          const page = window.location.pathname
      const payload = {
        resource_type: resource_type??null ,
        resource_id: resource_id??null ,
        activity,
        page,
      };
  
      mutate(payload);
    };

  };
  