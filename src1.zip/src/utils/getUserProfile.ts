import { msalInstance } from "@/authConfig";
import { AccountInfo } from "@azure/msal-browser";
import axios from "axios";

export async function getUserProfile(accountObj: AccountInfo) {
  const tokenResponse = await msalInstance.acquireTokenSilent({
    account: accountObj,
    scopes: ["User.Read"],
  });

  try {
    const response = await axios.get(
      "https://graph.microsoft.com/beta/me/photo/$value",
      {
        headers: {
          Authorization: `Bearer ${tokenResponse.accessToken}`,
        },
        responseType: "blob",
        validateStatus: () => true,
      }
    );

    if (response.status !== 200) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return URL.createObjectURL(response.data);
  } catch (error) {
    throw error;
  }
}
