import React, { useState } from "react";
import TabsWrapper from "./TabsWrapper";
import AccessControlTable from "./AccessControlTable";
import { dummyData } from "./dummyData";
import AdminContolImg from "../../assets/icons/AdminControl.svg";
import { RotateCw } from "lucide-react";
import { useFetchHandler } from "@/@logic/getHandlers";
import { TAB_API_MAP } from "./TabAPIEndpoints";

export default function AccessControlTabs() {

  const [selectedTab, setSelectedTab] = useState("my-ai-workspace");

  const { data, isLoading, refetch } = useFetchHandler(
    TAB_API_MAP[selectedTab],
    selectedTab,
    !!selectedTab
  );

  const renderContent = () => isLoading ? <>Loading...</> : <AccessControlTable workspaces={data || []} />;

  const tabs = [
    { label: "My AI Workspace", value: "my-ai-workspace", content: renderContent() },
    { label: "Workspace Permission", value: "workplace-permission", content: renderContent() },
    { label: "Skill Permission", value: "skill-permission", content: renderContent() },
    { label: "Persona", value: "persona", content: <>Persona</> },
    { label: "Category", value: "category", content: <>Category</> },
  ];

  const headerRight = (
    <>
      <input
        type="text"
        placeholder="Search"
        className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-unilever"
      />
      <button className="text-sm hover:underline font-unilever flex gap-2 pt-1">
        <RotateCw className="h-4 w-4 mt-1 text-blue-600" /> Refresh
      </button>
      <button className="text-sm text-gray-500 hover:underline font-unilever">
        ✖ Remove
      </button>
    </>
  );

  return (
    <div className="w-full max-w-[1300px] mx-auto px-4">
      <h2 className="text-lg font-semibold mt-6 mb-4 flex items-center gap-2 font-unilever">
        <img src={AdminContolImg} className="text-gray-700 text-2xl" />
        Admin Controls
      </h2>
      <TabsWrapper defaultValue="my-ai-workspace" value={selectedTab} onValueChange={setSelectedTab} tabs={tabs} rightHeader={headerRight} />
    </div>
  );
}