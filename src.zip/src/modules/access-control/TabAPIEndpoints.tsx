export const TAB_API_MAP: Record<string, string> = {
    "my-ai-workspace": "/access-control/get-access?scope=my_ai_workspace",
    "workplace-permission": "/access-control/get-access?scope=workspace",
    "skill-permission": "/access-control/get-access?scope=skill",
    "persona": "/personas",
    // "category": "/access-control/get-access",
};